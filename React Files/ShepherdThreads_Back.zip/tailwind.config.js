export default {content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#0A0A0A',
          800: '#1F1F1D',
          600: '#4A4945',
          500: '#696864',
        },
        stone: { DEFAULT: '#8C8C88' },
        cream: '#F7F5F0',
        canvas: '#FAFAFA',
        line: { DEFAULT: '#E8E6E1', strong: '#D6D3CC' },
        brass: {
          DEFAULT: '#B08D57',
          hover: '#9C7A47',
          soft: '#F5EFE4',
          text: '#7A5F33',
        },
        success: { DEFAULT: '#2F7A4D', soft: '#E7F2EB' },
        warning: { DEFAULT: '#95580A', soft: '#FBF0DF' },
        danger: { DEFAULT: '#B42318', soft: '#FBEAE8' },
        info: { DEFAULT: '#2D5B88', soft: '#E8EFF6' },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
      },
      boxShadow: {
        pop: '0 12px 32px -12px rgba(10,10,10,0.22), 0 2px 6px -2px rgba(10,10,10,0.08)',
      },
      transitionTimingFunction: {
        out: 'cubic-bezier(0.23, 1, 0.32, 1)',
      },
    },
  },
};
