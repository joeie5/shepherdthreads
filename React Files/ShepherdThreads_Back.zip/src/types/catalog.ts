export type ProductStatus = 'active' | 'draft' | 'archived';

export interface Product {
  id: string;
  name: string;
  handle: string;
  category: string;
  collections: string[];
  price: number;
  compareAtPrice?: number;
  cost: number;
  status: ProductStatus;
  image: string;
  gallery: string[];
  sizes: string[];
  colors: string[];
  stock: number;
  sku: string;
  description: string;
  seoTitle: string;
  seoDescription: string;
  updatedAt: string;
  sales30d: number;
}

export interface Collection {
  id: string;
  name: string;
  handle: string;
  description: string;
  image: string;
  productIds: string[];
  visible: boolean;
  updatedAt: string;
}

export interface InventoryItem {
  sku: string;
  productId: string;
  product: string;
  image: string;
  size: string;
  color: string;
  stock: number;
  committed: number;
  threshold: number;
}