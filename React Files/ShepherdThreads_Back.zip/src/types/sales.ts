export type PaymentStatus = 'paid' | 'pending' | 'refunded' | 'partially_refunded' | 'failed';
export type FulfillmentStatus = 'unfulfilled' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface Address {
  name: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  zip: string;
  country: string;
}

export interface LineItem {
  productId: string;
  name: string;
  variant: string;
  sku: string;
  qty: number;
  price: number;
  image: string;
}

export interface OrderNote {
  author: string;
  text: string;
  date: string;
}

export interface Order {
  id: string;
  number: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  date: string;
  subtotal: number;
  shipping: number;
  tax: number;
  discount: number;
  discountCode?: string;
  total: number;
  payment: PaymentStatus;
  fulfillment: FulfillmentStatus;
  channel: 'Web' | 'iOS' | 'Android';
  items: LineItem[];
  address: Address;
  paymentMethod: string;
  shippingMethod: string;
  tracking?: string;
  carrier?: string;
  notes: OrderNote[];
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  orders: number;
  spent: number;
  joined: string;
  lastOrder: string;
  marketingOptIn: boolean;
  smsOptIn: boolean;
  tags: string[];
  note: string;
}

export type DiscountType = 'percent' | 'fixed' | 'free_shipping';
export type DiscountStatus = 'active' | 'scheduled' | 'expired';

export interface Discount {
  id: string;
  code: string;
  type: DiscountType;
  value: number;
  status: DiscountStatus;
  uses: number;
  usageLimit: number | null;
  minSpend: number | null;
  appliesTo: string;
  startsAt: string;
  endsAt: string | null;
  oncePerCustomer: boolean;
}