export type Role = 'Admin' | 'Editor' | 'Support';

export interface StaffMember {
  id: string;
  name: string;
  email: string;
  role: Role;
  status: 'active' | 'invited';
  lastActive: string | null;
  twoFactor: boolean;
}

export interface PermissionSection {
  id: string;
  label: string;
  description: string;
}

export interface MenuLink {
  id: string;
  label: string;
  link: string;
  nested: boolean;
}

export interface AdminNotification {
  id: string;
  type: 'order' | 'stock' | 'review' | 'system';
  title: string;
  body: string;
  time: string;
  read: boolean;
  to: string;
}