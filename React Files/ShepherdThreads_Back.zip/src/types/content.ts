export type BlockType = 'hero' | 'productRow' | 'story' | 'testimonials' | 'newsletter' | 'text';

export interface HeroData {
  headline: string;
  subheadline: string;
  ctaLabel: string;
  ctaLink: string;
  image: string;
  align: 'left' | 'center';
}

export interface ProductRowData {
  title: string;
  subtitle: string;
  collection: string;
  count: number;
  showPrices: boolean;
}

export interface StoryData {
  eyebrow: string;
  title: string;
  body: string;
  image: string;
  ctaLabel: string;
  ctaLink: string;
  imageSide: 'left' | 'right';
}

export interface Testimonial {
  quote: string;
  name: string;
  detail: string;
  image: string;
}

export interface TestimonialsData {
  title: string;
  items: Testimonial[];
}

export interface NewsletterData {
  headline: string;
  body: string;
  buttonLabel: string;
  theme: 'cream' | 'black';
}

export interface TextData {
  heading: string;
  body: string;
  align: 'left' | 'center';
}

export type PageBlock =
{id: string;type: 'hero';visible: boolean;data: HeroData;} |
{id: string;type: 'productRow';visible: boolean;data: ProductRowData;} |
{id: string;type: 'story';visible: boolean;data: StoryData;} |
{id: string;type: 'testimonials';visible: boolean;data: TestimonialsData;} |
{id: string;type: 'newsletter';visible: boolean;data: NewsletterData;} |
{id: string;type: 'text';visible: boolean;data: TextData;};

export interface SitePage {
  id: string;
  name: string;
  path: string;
  lastPublished: string;
  blocks: PageBlock[];
}

export type PostStatus = 'published' | 'draft' | 'scheduled';

export interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  status: PostStatus;
  author: string;
  date: string;
  tags: string[];
  cover: string;
  readMinutes: number;
  body: string;
}

export interface MediaAsset {
  id: string;
  name: string;
  url: string;
  folder: 'Products' | 'Lifestyle' | 'Journal' | 'Brand';
  size: string;
  dimensions: string;
  uploadedAt: string;
  alt: string;
  usedIn: string[];
}