import type { InventoryItem } from '../types/catalog';
import { images } from './images';

export const inventory: InventoryItem[] = [
{ sku: 'ST-FT-BLK-S', productId: 'p-faithful-tee', product: 'Faithful Tee', image: images.teeBlack, size: 'S', color: 'Black', stock: 18, committed: 2, threshold: 10 },
{ sku: 'ST-FT-BLK-M', productId: 'p-faithful-tee', product: 'Faithful Tee', image: images.teeBlack, size: 'M', color: 'Black', stock: 31, committed: 4, threshold: 10 },
{ sku: 'ST-FT-BLK-L', productId: 'p-faithful-tee', product: 'Faithful Tee', image: images.teeBlack, size: 'L', color: 'Black', stock: 27, committed: 3, threshold: 10 },
{ sku: 'ST-FT-BLK-XL', productId: 'p-faithful-tee', product: 'Faithful Tee', image: images.teeBlack, size: 'XL', color: 'Black', stock: 14, committed: 1, threshold: 10 },
{ sku: 'ST-FT-BLK-XXL', productId: 'p-faithful-tee', product: 'Faithful Tee', image: images.teeBlack, size: 'XXL', color: 'Black', stock: 6, committed: 0, threshold: 8 },
{ sku: 'ST-FT-CRM-M', productId: 'p-faithful-tee', product: 'Faithful Tee', image: images.teeBlack, size: 'M', color: 'Cream', stock: 22, committed: 2, threshold: 10 },
{ sku: 'ST-FT-CRM-L', productId: 'p-faithful-tee', product: 'Faithful Tee', image: images.teeBlack, size: 'L', color: 'Cream', stock: 24, committed: 1, threshold: 10 },
{ sku: 'ST-GH-CRM-M', productId: 'p-grace-hoodie', product: 'Grace Hoodie', image: images.hoodieCream, size: 'M', color: 'Cream', stock: 12, committed: 3, threshold: 8 },
{ sku: 'ST-GH-CRM-L', productId: 'p-grace-hoodie', product: 'Grace Hoodie', image: images.hoodieCream, size: 'L', color: 'Cream', stock: 4, committed: 2, threshold: 8 },
{ sku: 'ST-GH-BLK-M', productId: 'p-grace-hoodie', product: 'Grace Hoodie', image: images.hoodieCream, size: 'M', color: 'Black', stock: 19, committed: 1, threshold: 8 },
{ sku: 'ST-GH-BLK-L', productId: 'p-grace-hoodie', product: 'Grace Hoodie', image: images.hoodieCream, size: 'L', color: 'Black', stock: 16, committed: 2, threshold: 8 },
{ sku: 'ST-GH-STN-XL', productId: 'p-grace-hoodie', product: 'Grace Hoodie', image: images.hoodieCream, size: 'XL', color: 'Stone', stock: 13, committed: 0, threshold: 8 },
{ sku: 'ST-SC-STN-M', productId: 'p-shepherds-crew', product: "Shepherd's Crewneck", image: images.crewneckStone, size: 'M', color: 'Stone', stock: 3, committed: 1, threshold: 6 },
{ sku: 'ST-SC-STN-L', productId: 'p-shepherds-crew', product: "Shepherd's Crewneck", image: images.crewneckStone, size: 'L', color: 'Stone', stock: 2, committed: 2, threshold: 6 },
{ sku: 'ST-SC-BLK-L', productId: 'p-shepherds-crew', product: "Shepherd's Crewneck", image: images.crewneckStone, size: 'L', color: 'Black', stock: 4, committed: 0, threshold: 6 },
{ sku: 'ST-P23-BLK-M', productId: 'p-psalm-23', product: 'Psalm 23 Tee', image: images.teeBlack, size: 'M', color: 'Black', stock: 29, committed: 2, threshold: 10 },
{ sku: 'ST-P23-WHT-L', productId: 'p-psalm-23', product: 'Psalm 23 Tee', image: images.teeBlack, size: 'L', color: 'White', stock: 21, committed: 1, threshold: 10 },
{ sku: 'ST-AOG-WHT-M', productId: 'p-armor-ls', product: 'Armor of God Long Sleeve', image: images.longsleeveWhite, size: 'M', color: 'White', stock: 0, committed: 0, threshold: 6 },
{ sku: 'ST-AOG-WHT-L', productId: 'p-armor-ls', product: 'Armor of God Long Sleeve', image: images.longsleeveWhite, size: 'L', color: 'White', stock: 0, committed: 0, threshold: 6 },
{ sku: 'ST-NPC-BLK-OS', productId: 'p-narrow-cap', product: 'Narrow Path Cap', image: images.capBlack, size: 'One size', color: 'Black', stock: 26, committed: 1, threshold: 10 },
{ sku: 'ST-NPC-STN-OS', productId: 'p-narrow-cap', product: 'Narrow Path Cap', image: images.capBlack, size: 'One size', color: 'Stone', stock: 15, committed: 0, threshold: 10 },
{ sku: 'ST-MST-NAT-OS', productId: 'p-mustard-tote', product: 'Mustard Seed Tote', image: images.toteCream, size: 'One size', color: 'Natural', stock: 6, committed: 1, threshold: 10 },
{ sku: 'ST-LQZ-CRM-M', productId: 'p-lamb-qz', product: 'Lamb Quarter-Zip', image: images.hoodieCream, size: 'M', color: 'Cream', stock: 7, committed: 0, threshold: 5 },
{ sku: 'ST-BHT-BLK-L', productId: 'p-beatitudes-tee', product: 'Beatitudes Heavyweight Tee', image: images.teeBlack, size: 'L', color: 'Black', stock: 2, committed: 1, threshold: 8 },
{ sku: 'ST-BHT-BLK-XL', productId: 'p-beatitudes-tee', product: 'Beatitudes Heavyweight Tee', image: images.teeBlack, size: 'XL', color: 'Black', stock: 1, committed: 0, threshold: 8 }];