export const images = {
  teeBlack: "/db4137d3-b5cc-4c15-ba57-44c664723b8d.jpg",
  hoodieCream: "/13b8d162-5676-48ca-bcc3-fcbbd0e1702a.jpg",
  crewneckStone: "/87a8227d-360f-4b34-9cbe-2f71de6ee810.jpg",
  capBlack: "/49825dfa-1a22-4ee4-bc4c-3c4392dee544.jpg",
  toteCream: "/ac5346d9-3d2d-4826-a0b7-016fe8b9cc70.jpg",
  longsleeveWhite: "/0f6cc9f7-483c-41d4-814e-640360a29105.jpg",
  hero: "/2f01c8cc-c61e-4833-8a6d-e2cd0974422f.jpg",
  story: "/11d71763-23c6-4b07-9d9f-e09615e39a8d.jpg",
  journal: "/1af9c7e7-917f-4fae-8348-7fa03f8b1101.jpg",
  ugc: "/828d025c-aaa6-4969-84a1-ebba17815174.jpg"
};