import type { Discount } from '../types/sales';

export const discounts: Discount[] = [
{ id: 'd-harvest10', code: 'HARVEST10', type: 'percent', value: 10, status: 'active', uses: 284, usageLimit: 1000, minSpend: 50, appliesTo: 'Fall 2026: Harvest', startsAt: '2026-10-01', endsAt: '2026-11-30', oncePerCustomer: true },
{ id: 'd-youth15', code: 'YOUTHGROUP15', type: 'percent', value: 15, status: 'active', uses: 41, usageLimit: null, minSpend: 150, appliesTo: 'All products', startsAt: '2026-08-15', endsAt: null, oncePerCustomer: false },
{ id: 'd-shipfree', code: 'SHIPFREE', type: 'free_shipping', value: 0, status: 'active', uses: 512, usageLimit: null, minSpend: 75, appliesTo: 'All products', startsAt: '2026-01-01', endsAt: null, oncePerCustomer: false },
{ id: 'd-grace15', code: 'GRACE15', type: 'percent', value: 15, status: 'active', uses: 18, usageLimit: 50, minSpend: null, appliesTo: 'All products', startsAt: '2026-09-01', endsAt: '2026-12-31', oncePerCustomer: true },
{ id: 'd-advent20', code: 'ADVENT20', type: 'fixed', value: 20, status: 'scheduled', uses: 0, usageLimit: 500, minSpend: 100, appliesTo: 'Advent Drop', startsAt: '2026-11-29', endsAt: '2026-12-24', oncePerCustomer: true },
{ id: 'd-easter', code: 'RISEN25', type: 'percent', value: 25, status: 'expired', uses: 736, usageLimit: 750, minSpend: null, appliesTo: 'Scripture Series', startsAt: '2026-03-29', endsAt: '2026-04-06', oncePerCustomer: true },
{ id: 'd-welcome', code: 'WELCOME5', type: 'fixed', value: 5, status: 'expired', uses: 1290, usageLimit: null, minSpend: 30, appliesTo: 'All products', startsAt: '2025-06-01', endsAt: '2026-06-01', oncePerCustomer: true }];