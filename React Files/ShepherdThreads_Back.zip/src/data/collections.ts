import type { Collection } from '../types/catalog';
import { images } from './images';

export const collections: Collection[] = [
{
  id: 'c-fall-26',
  name: 'Fall 2026: Harvest',
  handle: 'fall-2026-harvest',
  description: 'Heavyweight layers for the season of gathering. Earth tones, brushed fleece, and quiet embroidery.',
  image: images.hero,
  productIds: ['p-grace-hoodie', 'p-shepherds-crew', 'p-armor-ls', 'p-lamb-qz'],
  visible: true,
  updatedAt: '2026-10-29'
},
{
  id: 'c-best-sellers',
  name: 'Best Sellers',
  handle: 'best-sellers',
  description: 'The pieces our community reaches for most.',
  image: images.teeBlack,
  productIds: ['p-faithful-tee', 'p-grace-hoodie', 'p-beatitudes-tee'],
  visible: true,
  updatedAt: '2026-10-28'
},
{
  id: 'c-scripture',
  name: 'Scripture Series',
  handle: 'scripture-series',
  description: 'Verses set in type and thread. Each piece carries a passage worth remembering.',
  image: images.longsleeveWhite,
  productIds: ['p-psalm-23', 'p-armor-ls', 'p-light-tee', 'p-beatitudes-tee'],
  visible: true,
  updatedAt: '2026-10-24'
},
{
  id: 'c-essentials',
  name: 'Everyday Essentials',
  handle: 'essentials',
  description: 'Core tees and bottoms, always in stock.',
  image: images.crewneckStone,
  productIds: ['p-faithful-tee', 'p-psalm-23', 'p-redeemed-jogger'],
  visible: true,
  updatedAt: '2026-10-11'
},
{
  id: 'c-accessories',
  name: 'Accessories',
  handle: 'accessories',
  description: 'Caps, totes, and finishing pieces.',
  image: images.capBlack,
  productIds: ['p-narrow-cap', 'p-mustard-tote', 'p-covenant-beanie'],
  visible: true,
  updatedAt: '2026-10-05'
},
{
  id: 'c-advent',
  name: 'Advent Drop',
  handle: 'advent-drop',
  description: 'Limited pieces releasing the first Sunday of Advent.',
  image: images.journal,
  productIds: ['p-light-tee'],
  visible: false,
  updatedAt: '2026-10-31'
}];