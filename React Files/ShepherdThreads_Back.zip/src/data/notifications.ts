import type { AdminNotification } from '../types/admin';

export const notifications: AdminNotification[] = [
{ id: 'n1', type: 'order', title: 'New order #ST-10492', body: 'Ava Mitchell · $125.57 · iOS app', time: '8 min ago', read: false, to: '/orders/o-10492' },
{ id: 'n2', type: 'stock', title: 'Beatitudes Heavyweight Tee is almost out', body: '3 units left across 2 variants', time: '42 min ago', read: false, to: '/inventory' },
{ id: 'n3', type: 'order', title: 'Payment failed on #ST-10482', body: 'Noah Williams · card declined', time: '3 hours ago', read: false, to: '/orders/o-10482' },
{ id: 'n4', type: 'review', title: 'New 5-star review', body: '“Softest shirt I own” — Faithful Tee', time: 'Yesterday', read: true, to: '/products/p-faithful-tee' },
{ id: 'n5', type: 'system', title: 'Journal post scheduled', body: 'Preparing Room goes live Nov 29', time: 'Yesterday', read: true, to: '/journal/post-advent' }];