import type { MenuLink } from '../types/admin';

export const brandPalette = [
{ id: 'primary', label: 'Primary (text & buttons)', value: '#0A0A0A' },
{ id: 'background', label: 'Background', value: '#FFFFFF' },
{ id: 'surface', label: 'Surface (cream)', value: '#F7F5F0' },
{ id: 'muted', label: 'Muted (stone grey)', value: '#8C8C88' },
{ id: 'accent', label: 'Accent (brass)', value: '#B08D57' }];


export const fontOptions = [
{ value: 'Cormorant Garamond', label: 'Cormorant Garamond' },
{ value: 'Playfair Display', label: 'Playfair Display' },
{ value: 'Libre Baskerville', label: 'Libre Baskerville' },
{ value: 'Inter', label: 'Inter' },
{ value: 'DM Sans', label: 'DM Sans' },
{ value: 'Work Sans', label: 'Work Sans' }];


export const headerMenu: MenuLink[] = [
{ id: 'n-shop', label: 'Shop', link: '/shop', nested: false },
{ id: 'n-tees', label: 'Tees', link: '/collections/tees', nested: true },
{ id: 'n-hoodies', label: 'Hoodies & Crews', link: '/collections/hoodies', nested: true },
{ id: 'n-acc', label: 'Accessories', link: '/collections/accessories', nested: true },
{ id: 'n-harvest', label: 'Fall 2026: Harvest', link: '/collections/fall-2026-harvest', nested: false },
{ id: 'n-journal', label: 'Journal', link: '/journal', nested: false },
{ id: 'n-about', label: 'Our Story', link: '/about', nested: false }];


export const footerColumns = [
{
  id: 'f-shop',
  title: 'Shop',
  links: [
  { id: 'fl-1', label: 'All products', link: '/shop' },
  { id: 'fl-2', label: 'Best sellers', link: '/collections/best-sellers' },
  { id: 'fl-3', label: 'Gift cards', link: '/gift-cards' }]

},
{
  id: 'f-help',
  title: 'Help',
  links: [
  { id: 'fl-4', label: 'Shipping & returns', link: '/pages/shipping' },
  { id: 'fl-5', label: 'Size guide', link: '/pages/size-guide' },
  { id: 'fl-6', label: 'Contact us', link: '/pages/contact' }]

},
{
  id: 'f-about',
  title: 'About',
  links: [
  { id: 'fl-7', label: 'Our story', link: '/about' },
  { id: 'fl-8', label: 'Journal', link: '/journal' },
  { id: 'fl-9', label: 'Wholesale & churches', link: '/pages/wholesale' }]

}];


export const socialLinks = [
{ id: 'instagram', label: 'Instagram', url: 'https://instagram.com/shepherdsthread', enabled: true },
{ id: 'tiktok', label: 'TikTok', url: 'https://tiktok.com/@shepherdsthread', enabled: true },
{ id: 'youtube', label: 'YouTube', url: '', enabled: false },
{ id: 'pinterest', label: 'Pinterest', url: 'https://pinterest.com/shepherdsthread', enabled: true }];


export const shippingZones = [
{ id: 'z-us', name: 'United States', countries: '50 states', rates: [{ name: 'Standard (3–5 days)', price: 6.95, freeOver: 100 }, { name: 'Express (2-day)', price: 14.95, freeOver: null }] },
{ id: 'z-ca', name: 'Canada', countries: 'All provinces', rates: [{ name: 'International standard', price: 18, freeOver: 150 }] },
{ id: 'z-intl', name: 'Rest of world', countries: '38 countries', rates: [{ name: 'International tracked', price: 28, freeOver: null }] }];


export const paymentGateways = [
{ id: 'stripe', name: 'Stripe', description: 'Cards, Apple Pay, and Google Pay', connected: true, account: 'acct_••••8F2Q · Shepherds Thread LLC' },
{ id: 'paypal', name: 'PayPal', description: 'PayPal and Venmo checkout', connected: true, account: 'payments@shepherdsthread.co' },
{ id: 'shoppay', name: 'Afterpay', description: 'Buy now, pay in 4 installments', connected: false, account: '' },
{ id: 'manual', name: 'Bank transfer', description: 'Manual payment for wholesale and church orders', connected: true, account: 'Instructions shown at checkout' }];