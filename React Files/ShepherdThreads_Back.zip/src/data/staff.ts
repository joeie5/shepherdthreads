import type { PermissionSection, Role, StaffMember } from '../types/admin';

export const staff: StaffMember[] = [
{ id: 's-hannah', name: 'Hannah Brooks', email: 'hannah@shepherdsthread.co', role: 'Admin', status: 'active', lastActive: '2026-11-01T09:50:00', twoFactor: true },
{ id: 's-caleb', name: 'Caleb Morgan', email: 'caleb@shepherdsthread.co', role: 'Admin', status: 'active', lastActive: '2026-10-31T17:22:00', twoFactor: true },
{ id: 's-ruth', name: 'Ruth Adeyemi', email: 'ruth@shepherdsthread.co', role: 'Editor', status: 'active', lastActive: '2026-11-01T08:05:00', twoFactor: false },
{ id: 's-jordan', name: 'Jordan Hayes', email: 'jordan@shepherdsthread.co', role: 'Support', status: 'active', lastActive: '2026-11-01T09:12:00', twoFactor: true },
{ id: 's-mia', name: 'Mia Castillo', email: 'mia@shepherdsthread.co', role: 'Support', status: 'active', lastActive: '2026-10-29T14:40:00', twoFactor: false },
{ id: 's-ben', name: 'Ben Whitaker', email: 'ben.whitaker@gmail.com', role: 'Editor', status: 'invited', lastActive: null, twoFactor: false }];


export const permissionSections: PermissionSection[] = [
{ id: 'orders', label: 'Orders', description: 'View, fulfill, and refund orders' },
{ id: 'products', label: 'Products & inventory', description: 'Create and edit products, adjust stock' },
{ id: 'collections', label: 'Collections', description: 'Organize products into collections' },
{ id: 'customers', label: 'Customers', description: 'View customer profiles and notes' },
{ id: 'discounts', label: 'Discounts', description: 'Create and manage discount codes' },
{ id: 'content', label: 'Pages & journal', description: 'Edit homepage, pages, and journal posts' },
{ id: 'media', label: 'Media library', description: 'Upload and manage images' },
{ id: 'analytics', label: 'Analytics', description: 'View sales and traffic reports' },
{ id: 'settings', label: 'Site settings', description: 'Theme, navigation, shipping, and payments' },
{ id: 'staff', label: 'Staff & roles', description: 'Invite staff and change permissions' }];


export const rolePermissions: Record<Role, string[]> = {
  Admin: ['orders', 'products', 'collections', 'customers', 'discounts', 'content', 'media', 'analytics', 'settings', 'staff'],
  Editor: ['products', 'collections', 'content', 'media', 'analytics'],
  Support: ['orders', 'customers', 'discounts']
};

export const roleDescriptions: Record<Role, string> = {
  Admin: 'Full access to everything, including billing and staff.',
  Editor: 'Manages products, collections, and site content.',
  Support: 'Handles orders, refunds, and customer questions.'
};