import type { LucideIcon } from 'lucide-react';
import {
  BookOpenIcon,
  BoxesIcon,
  ChartLineIcon,
  ImagesIcon,
  LayersIcon,
  LayoutDashboardIcon,
  PanelsTopLeftIcon,
  SettingsIcon,
  ShieldCheckIcon,
  ShirtIcon,
  ShoppingBagIcon,
  TicketPercentIcon,
  UsersIcon } from
'lucide-react';

export interface AdminNavItem {
  label: string;
  to: string;
  icon: LucideIcon;
  badge?: number;
}

export interface AdminNavGroup {
  label: string;
  items: AdminNavItem[];
}

export const adminNav: AdminNavGroup[] = [
{
  label: 'Overview',
  items: [
  { label: 'Dashboard', to: '/', icon: LayoutDashboardIcon },
  { label: 'Analytics', to: '/analytics', icon: ChartLineIcon }]

},
{
  label: 'Store',
  items: [
  { label: 'Orders', to: '/orders', icon: ShoppingBagIcon, badge: 4 },
  { label: 'Products', to: '/products', icon: ShirtIcon },
  { label: 'Collections', to: '/collections', icon: LayersIcon },
  { label: 'Inventory', to: '/inventory', icon: BoxesIcon },
  { label: 'Customers', to: '/customers', icon: UsersIcon },
  { label: 'Discounts', to: '/discounts', icon: TicketPercentIcon }]

},
{
  label: 'Content',
  items: [
  { label: 'Pages', to: '/content', icon: PanelsTopLeftIcon },
  { label: 'Journal', to: '/journal', icon: BookOpenIcon },
  { label: 'Media library', to: '/media', icon: ImagesIcon }]

},
{
  label: 'Admin',
  items: [
  { label: 'Staff & roles', to: '/staff', icon: ShieldCheckIcon },
  { label: 'Settings', to: '/settings', icon: SettingsIcon }]

}];