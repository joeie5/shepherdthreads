export const kpis = {
  revenueToday: 2486.4,
  revenueYesterday: 2112.9,
  ordersToday: 31,
  ordersYesterday: 27,
  visitorsToday: 1842,
  visitorsYesterday: 1920,
  conversionToday: 1.68,
  conversionYesterday: 1.41
};

export const salesTrend = [
{ date: 'Oct 3', revenue: 1620, orders: 21 },
{ date: 'Oct 4', revenue: 1980, orders: 25 },
{ date: 'Oct 5', revenue: 1410, orders: 18 },
{ date: 'Oct 6', revenue: 1350, orders: 17 },
{ date: 'Oct 7', revenue: 1720, orders: 22 },
{ date: 'Oct 8', revenue: 2240, orders: 29 },
{ date: 'Oct 9', revenue: 1890, orders: 24 },
{ date: 'Oct 10', revenue: 2050, orders: 26 },
{ date: 'Oct 11', revenue: 2410, orders: 31 },
{ date: 'Oct 12', revenue: 1760, orders: 22 },
{ date: 'Oct 13', revenue: 1540, orders: 19 },
{ date: 'Oct 14', revenue: 1830, orders: 23 },
{ date: 'Oct 15', revenue: 2120, orders: 27 },
{ date: 'Oct 16', revenue: 2380, orders: 30 },
{ date: 'Oct 17', revenue: 2960, orders: 37 },
{ date: 'Oct 18', revenue: 3240, orders: 41 },
{ date: 'Oct 19', revenue: 2310, orders: 29 },
{ date: 'Oct 20', revenue: 1980, orders: 25 },
{ date: 'Oct 21', revenue: 2140, orders: 27 },
{ date: 'Oct 22', revenue: 2690, orders: 34 },
{ date: 'Oct 23', revenue: 2470, orders: 31 },
{ date: 'Oct 24', revenue: 2210, orders: 28 },
{ date: 'Oct 25', revenue: 2780, orders: 35 },
{ date: 'Oct 26', revenue: 2030, orders: 26 },
{ date: 'Oct 27', revenue: 1920, orders: 24 },
{ date: 'Oct 28', revenue: 2260, orders: 28 },
{ date: 'Oct 29', revenue: 2540, orders: 32 },
{ date: 'Oct 30', revenue: 2390, orders: 30 },
{ date: 'Oct 31', revenue: 2112, orders: 27 },
{ date: 'Nov 1', revenue: 2486, orders: 31 }];


export const salesByProduct = [
{ name: 'Faithful Tee', units: 312, revenue: 11856 },
{ name: 'Grace Hoodie', units: 188, revenue: 14664 },
{ name: 'Psalm 23 Tee', units: 143, revenue: 5434 },
{ name: 'Armor of God LS', units: 121, revenue: 5566 },
{ name: 'Beatitudes Tee', units: 102, revenue: 4284 },
{ name: "Shepherd's Crew", units: 96, revenue: 6528 },
{ name: 'Narrow Path Cap', units: 74, revenue: 2368 }];


export const salesByCollection = [
{ name: 'Fall 2026: Harvest', revenue: 24310, share: 36 },
{ name: 'Best Sellers', revenue: 18240, share: 27 },
{ name: 'Scripture Series', revenue: 12880, share: 19 },
{ name: 'Everyday Essentials', revenue: 8090, share: 12 },
{ name: 'Accessories', revenue: 4130, share: 6 }];


export const trafficSources = [
{ source: 'Instagram', sessions: 18420, conversion: 1.9 },
{ source: 'Direct / App', sessions: 14210, conversion: 2.6 },
{ source: 'Google search', sessions: 9860, conversion: 1.7 },
{ source: 'TikTok', sessions: 7340, conversion: 0.9 },
{ source: 'Email', sessions: 4120, conversion: 3.8 },
{ source: 'Referral', sessions: 1980, conversion: 1.4 }];


export const funnel = [
{ stage: 'Sessions', value: 55930 },
{ stage: 'Viewed product', value: 26840 },
{ stage: 'Added to cart', value: 5120 },
{ stage: 'Reached checkout', value: 1740 },
{ stage: 'Purchased', value: 812 }];


export const reports = [
{ id: 'r-sales', name: 'Sales summary', description: 'Gross, net, discounts, returns and taxes by day.' },
{ id: 'r-products', name: 'Product performance', description: 'Units, revenue and margin per product and variant.' },
{ id: 'r-customers', name: 'Customer cohort', description: 'New vs. returning customers and lifetime value.' },
{ id: 'r-discounts', name: 'Discount usage', description: 'Redemptions and revenue per discount code.' },
{ id: 'r-inventory', name: 'Inventory snapshot', description: 'Stock on hand and value across all variants.' }];