import type { Post } from '../types/content';
import { images } from './images';

export const postAuthors = ['Hannah Brooks', 'Caleb Morgan', 'Ruth Adeyemi'];

export const posts: Post[] = [
{
  id: 'post-harvest',
  title: 'The Season of Gathering: Behind Our Fall Collection',
  slug: 'season-of-gathering',
  excerpt: 'Why we designed Harvest around the idea of slowing down, and the verse stitched into every piece.',
  status: 'published',
  author: 'Hannah Brooks',
  date: '2026-10-22',
  tags: ['Collections', 'Behind the seams'],
  cover: images.hero,
  readMinutes: 6,
  body: '<p>Every fall we ask the same question in the studio: what does it look like to wear your faith quietly, but with conviction?</p><h2>Rooted in Ecclesiastes</h2><p>This year the answer came from Ecclesiastes 3 — a time to plant, and a time to gather. The Harvest collection is built from heavyweight fleece in earth tones that feel like a field at golden hour.</p><blockquote>“He has made everything beautiful in its time.” — Ecclesiastes 3:11</blockquote><p>Each piece carries a small embroidered mark and a woven label with the verse inside the collar, a reminder only you will see.</p>'
},
{
  id: 'post-thread',
  title: 'How a Single Thread Is Made: Our Embroidery Process',
  slug: 'how-a-thread-is-made',
  excerpt: 'A visit to the family-run workshop in North Carolina that embroiders every Shepherds Thread piece.',
  status: 'published',
  author: 'Caleb Morgan',
  date: '2026-10-08',
  tags: ['Craft', 'Behind the seams'],
  cover: images.story,
  readMinutes: 8,
  body: '<p>Our embroidery partners have been stitching in the same building since 1978.</p>'
},
{
  id: 'post-advent',
  title: 'Preparing Room: An Advent Reading Plan',
  slug: 'advent-reading-plan',
  excerpt: 'Twenty-four short readings to carry you from the first candle to Christmas morning.',
  status: 'scheduled',
  author: 'Ruth Adeyemi',
  date: '2026-11-29',
  tags: ['Devotional', 'Advent'],
  cover: images.journal,
  readMinutes: 5,
  body: '<p>Advent is a season of waiting. Here is a simple reading plan our team will be following together.</p>'
},
{
  id: 'post-community',
  title: 'Worn in Community: Stories From Your Youth Groups',
  slug: 'worn-in-community',
  excerpt: 'Photos and notes from youth pastors who outfitted their retreats in Shepherds Thread this summer.',
  status: 'draft',
  author: 'Hannah Brooks',
  date: '2026-10-30',
  tags: ['Community'],
  cover: images.ugc,
  readMinutes: 4,
  body: '<p>Draft — gathering photos from Olivia and the Phoenix youth team.</p>'
},
{
  id: 'post-care',
  title: 'Caring for Heavyweight Cotton So It Lasts for Years',
  slug: 'caring-for-heavyweight-cotton',
  excerpt: 'Wash cold, hang dry, and other small habits that keep your tees feeling new.',
  status: 'published',
  author: 'Caleb Morgan',
  date: '2026-09-18',
  tags: ['Guides'],
  cover: images.teeBlack,
  readMinutes: 3,
  body: '<p>Good garments are an act of stewardship.</p>'
},
{
  id: 'post-psalm',
  title: 'Psalm 23 and the Name Behind Our Brand',
  slug: 'psalm-23-and-our-name',
  excerpt: 'Where the name Shepherds Thread came from, and why it still guides what we make.',
  status: 'published',
  author: 'Hannah Brooks',
  date: '2026-08-30',
  tags: ['Our story', 'Devotional'],
  cover: images.crewneckStone,
  readMinutes: 5,
  body: '<p>The name came on a walk through a pasture outside Franklin, Tennessee.</p>'
}];