import type { Order } from '../types/sales';
import { images } from './images';

export const orders: Order[] = [
{
  id: 'o-10492', number: '#ST-10492', customerId: 'cu-ava', customerName: 'Ava Mitchell', customerEmail: 'ava.mitchell@gmail.com',
  date: '2026-11-01T09:42:00', subtotal: 116, shipping: 0, tax: 9.57, discount: 0, total: 125.57,
  payment: 'paid', fulfillment: 'unfulfilled', channel: 'iOS',
  items: [
  { productId: 'p-grace-hoodie', name: 'Grace Hoodie', variant: 'Cream / M', sku: 'ST-GH-CRM-M', qty: 1, price: 78, image: images.hoodieCream },
  { productId: 'p-faithful-tee', name: 'Faithful Tee', variant: 'Black / M', sku: 'ST-FT-BLK-M', qty: 1, price: 38, image: images.teeBlack }],

  address: { name: 'Ava Mitchell', line1: '2214 Magnolia Ave', city: 'Nashville', state: 'TN', zip: '37204', country: 'United States' },
  paymentMethod: 'Apple Pay · Visa •••• 4021', shippingMethod: 'Standard (free over $100)', notes: []
},
{
  id: 'o-10491', number: '#ST-10491', customerId: 'cu-marcus', customerName: 'Marcus Reid', customerEmail: 'marcus.reid@outlook.com',
  date: '2026-11-01T08:15:00', subtotal: 76, shipping: 6.95, tax: 6.84, discount: 7.6, discountCode: 'HARVEST10', total: 82.19,
  payment: 'paid', fulfillment: 'unfulfilled', channel: 'Web',
  items: [
  { productId: 'p-psalm-23', name: 'Psalm 23 Tee', variant: 'Black / L', sku: 'ST-P23-BLK-L', qty: 2, price: 38, image: images.teeBlack }],

  address: { name: 'Marcus Reid', line1: '88 Westview Dr', line2: 'Apt 4B', city: 'Atlanta', state: 'GA', zip: '30310', country: 'United States' },
  paymentMethod: 'Mastercard •••• 8812', shippingMethod: 'Standard', notes: []
},
{
  id: 'o-10490', number: '#ST-10490', customerId: 'cu-grace', customerName: 'Grace Okafor', customerEmail: 'grace.okafor@icloud.com',
  date: '2026-10-31T19:03:00', subtotal: 156, shipping: 0, tax: 12.87, discount: 0, total: 168.87,
  payment: 'paid', fulfillment: 'processing', channel: 'Android',
  items: [
  { productId: 'p-lamb-qz', name: 'Lamb Quarter-Zip', variant: 'Cream / M', sku: 'ST-LQZ-CRM-M', qty: 1, price: 88, image: images.hoodieCream },
  { productId: 'p-shepherds-crew', name: "Shepherd's Crewneck", variant: 'Stone / M', sku: 'ST-SC-STN-M', qty: 1, price: 68, image: images.crewneckStone }],

  address: { name: 'Grace Okafor', line1: '410 Lakeshore Blvd', city: 'Chicago', state: 'IL', zip: '60611', country: 'United States' },
  paymentMethod: 'Google Pay · Visa •••• 0193', shippingMethod: 'Express (2-day)', notes: [{ author: 'Jordan Hayes', text: 'Customer asked for gift note: "Happy birthday, Mom — Psalm 121."', date: '2026-10-31T19:20:00' }]
},
{
  id: 'o-10489', number: '#ST-10489', customerId: 'cu-elijah', customerName: 'Elijah Brooks', customerEmail: 'elijah.brooks@gmail.com',
  date: '2026-10-31T14:27:00', subtotal: 38, shipping: 6.95, tax: 3.13, discount: 0, total: 48.08,
  payment: 'pending', fulfillment: 'unfulfilled', channel: 'Web',
  items: [
  { productId: 'p-faithful-tee', name: 'Faithful Tee', variant: 'Cream / L', sku: 'ST-FT-CRM-L', qty: 1, price: 38, image: images.teeBlack }],

  address: { name: 'Elijah Brooks', line1: '19 Cedar Ln', city: 'Franklin', state: 'TN', zip: '37064', country: 'United States' },
  paymentMethod: 'Bank transfer (awaiting)', shippingMethod: 'Standard', notes: []
},
{
  id: 'o-10488', number: '#ST-10488', customerId: 'cu-sophia', customerName: 'Sophia Turner', customerEmail: 'sophia.t@yahoo.com',
  date: '2026-10-31T10:51:00', subtotal: 142, shipping: 0, tax: 11.72, discount: 14.2, discountCode: 'HARVEST10', total: 139.52,
  payment: 'paid', fulfillment: 'shipped', channel: 'iOS', tracking: '1Z84F2E10392847561', carrier: 'UPS',
  items: [
  { productId: 'p-grace-hoodie', name: 'Grace Hoodie', variant: 'Black / L', sku: 'ST-GH-BLK-L', qty: 1, price: 78, image: images.hoodieCream },
  { productId: 'p-redeemed-jogger', name: 'Redeemed Joggers', variant: 'Black / M', sku: 'ST-RJ-BLK-M', qty: 1, price: 64, image: images.crewneckStone }],

  address: { name: 'Sophia Turner', line1: '702 Oak Hollow Rd', city: 'Dallas', state: 'TX', zip: '75201', country: 'United States' },
  paymentMethod: 'Apple Pay · Amex •••• 3005', shippingMethod: 'Standard (free over $100)', notes: []
},
{
  id: 'o-10487', number: '#ST-10487', customerId: 'cu-daniel', customerName: 'Daniel Kim', customerEmail: 'dkim.design@gmail.com',
  date: '2026-10-30T21:10:00', subtotal: 60, shipping: 6.95, tax: 4.95, discount: 0, total: 71.9,
  payment: 'paid', fulfillment: 'shipped', channel: 'Web', tracking: '9400111899223847561029', carrier: 'USPS',
  items: [
  { productId: 'p-narrow-cap', name: 'Narrow Path Cap', variant: 'Black', sku: 'ST-NPC-BLK-OS', qty: 1, price: 32, image: images.capBlack },
  { productId: 'p-mustard-tote', name: 'Mustard Seed Tote', variant: 'Natural', sku: 'ST-MST-NAT-OS', qty: 1, price: 28, image: images.toteCream }],

  address: { name: 'Daniel Kim', line1: '1550 Pine St', city: 'Seattle', state: 'WA', zip: '98101', country: 'United States' },
  paymentMethod: 'Visa •••• 7720', shippingMethod: 'Standard', notes: []
},
{
  id: 'o-10486', number: '#ST-10486', customerId: 'cu-hannah', customerName: 'Hannah Lee', customerEmail: 'hannahlee@gmail.com',
  date: '2026-10-30T16:44:00', subtotal: 84, shipping: 6.95, tax: 6.93, discount: 0, total: 97.88,
  payment: 'paid', fulfillment: 'delivered', channel: 'Android', tracking: '1Z84F2E10392841177', carrier: 'UPS',
  items: [
  { productId: 'p-beatitudes-tee', name: 'Beatitudes Heavyweight Tee', variant: 'Black / L', sku: 'ST-BHT-BLK-L', qty: 2, price: 42, image: images.teeBlack }],

  address: { name: 'Hannah Lee', line1: '33 Harbor View', city: 'San Diego', state: 'CA', zip: '92101', country: 'United States' },
  paymentMethod: 'Google Pay · Mastercard •••• 6630', shippingMethod: 'Standard', notes: []
},
{
  id: 'o-10485', number: '#ST-10485', customerId: 'cu-isaiah', customerName: 'Isaiah Johnson', customerEmail: 'isaiah.j@gmail.com',
  date: '2026-10-30T11:02:00', subtotal: 46, shipping: 6.95, tax: 3.8, discount: 0, total: 56.75,
  payment: 'refunded', fulfillment: 'cancelled', channel: 'Web',
  items: [
  { productId: 'p-armor-ls', name: 'Armor of God Long Sleeve', variant: 'White / L', sku: 'ST-AOG-WHT-L', qty: 1, price: 46, image: images.longsleeveWhite }],

  address: { name: 'Isaiah Johnson', line1: '207 Elm St', city: 'Charlotte', state: 'NC', zip: '28202', country: 'United States' },
  paymentMethod: 'Visa •••• 1184', shippingMethod: 'Standard',
  notes: [{ author: 'Jordan Hayes', text: 'Out of stock after order placed. Refunded in full and sent 15% code GRACE15.', date: '2026-10-30T13:40:00' }]
},
{
  id: 'o-10484', number: '#ST-10484', customerId: 'cu-ava', customerName: 'Ava Mitchell', customerEmail: 'ava.mitchell@gmail.com',
  date: '2026-10-29T18:30:00', subtotal: 68, shipping: 6.95, tax: 5.61, discount: 0, total: 80.56,
  payment: 'paid', fulfillment: 'delivered', channel: 'iOS', tracking: '1Z84F2E10392840022', carrier: 'UPS',
  items: [
  { productId: 'p-shepherds-crew', name: "Shepherd's Crewneck", variant: 'Black / L', sku: 'ST-SC-BLK-L', qty: 1, price: 68, image: images.crewneckStone }],

  address: { name: 'Ava Mitchell', line1: '2214 Magnolia Ave', city: 'Nashville', state: 'TN', zip: '37204', country: 'United States' },
  paymentMethod: 'Apple Pay · Visa •••• 4021', shippingMethod: 'Standard', notes: []
},
{
  id: 'o-10483', number: '#ST-10483', customerId: 'cu-olivia', customerName: 'Olivia Martinez', customerEmail: 'olivia.mtz@gmail.com',
  date: '2026-10-29T09:12:00', subtotal: 194, shipping: 0, tax: 16.01, discount: 29.1, discountCode: 'YOUTHGROUP15', total: 180.91,
  payment: 'partially_refunded', fulfillment: 'delivered', channel: 'Web', tracking: '9400111899223840051', carrier: 'USPS',
  items: [
  { productId: 'p-faithful-tee', name: 'Faithful Tee', variant: 'Black / S', sku: 'ST-FT-BLK-S', qty: 3, price: 38, image: images.teeBlack },
  { productId: 'p-psalm-23', name: 'Psalm 23 Tee', variant: 'White / L', sku: 'ST-P23-WHT-L', qty: 2, price: 40, image: images.teeBlack }],

  address: { name: 'Olivia Martinez', line1: '5120 Mission Rd', city: 'Phoenix', state: 'AZ', zip: '85004', country: 'United States' },
  paymentMethod: 'Visa •••• 5561', shippingMethod: 'Standard (free over $100)',
  notes: [{ author: 'Jordan Hayes', text: 'One tee returned (size exchange not available). Refunded $38.', date: '2026-10-31T10:05:00' }]
},
{
  id: 'o-10482', number: '#ST-10482', customerId: 'cu-noah', customerName: 'Noah Williams', customerEmail: 'noah.w@protonmail.com',
  date: '2026-10-28T20:47:00', subtotal: 78, shipping: 6.95, tax: 6.43, discount: 0, total: 91.38,
  payment: 'failed', fulfillment: 'unfulfilled', channel: 'Android',
  items: [
  { productId: 'p-grace-hoodie', name: 'Grace Hoodie', variant: 'Stone / XL', sku: 'ST-GH-STN-XL', qty: 1, price: 78, image: images.hoodieCream }],

  address: { name: 'Noah Williams', line1: '9 Birch Ct', city: 'Columbus', state: 'OH', zip: '43215', country: 'United States' },
  paymentMethod: 'Visa •••• 9902 (declined)', shippingMethod: 'Standard', notes: []
},
{
  id: 'o-10481', number: '#ST-10481', customerId: 'cu-grace', customerName: 'Grace Okafor', customerEmail: 'grace.okafor@icloud.com',
  date: '2026-10-28T13:15:00', subtotal: 38, shipping: 6.95, tax: 3.13, discount: 0, total: 48.08,
  payment: 'paid', fulfillment: 'delivered', channel: 'Android', tracking: '1Z84F2E10392838811', carrier: 'UPS',
  items: [
  { productId: 'p-faithful-tee', name: 'Faithful Tee', variant: 'Cream / M', sku: 'ST-FT-CRM-M', qty: 1, price: 38, image: images.teeBlack }],

  address: { name: 'Grace Okafor', line1: '410 Lakeshore Blvd', city: 'Chicago', state: 'IL', zip: '60611', country: 'United States' },
  paymentMethod: 'Google Pay · Visa •••• 0193', shippingMethod: 'Standard', notes: []
}];