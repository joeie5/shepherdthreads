export const colorSwatches: Record<string, string> = {
  Black: '#0A0A0A',
  Cream: '#EFE8D8',
  Stone: '#B9B5AC',
  White: '#FFFFFF',
  Natural: '#E6DCC6',
  Brass: '#B08D57'
};

export const sizeOptions = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'One size'];