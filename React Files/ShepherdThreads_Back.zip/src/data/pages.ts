import type { SitePage } from '../types/content';
import { images } from './images';

export const sitePages: SitePage[] = [
{
  id: 'home',
  name: 'Homepage',
  path: '/',
  lastPublished: '2026-10-29T16:20:00',
  blocks: [
  {
    id: 'b-hero',
    type: 'hero',
    visible: true,
    data: {
      headline: 'Faith, woven in.',
      subheadline: 'The Harvest collection — heavyweight layers for the season of gathering.',
      ctaLabel: 'Shop Harvest',
      ctaLink: '/collections/fall-2026-harvest',
      image: images.hero,
      align: 'left'
    }
  },
  {
    id: 'b-featured',
    type: 'productRow',
    visible: true,
    data: { title: 'Best Sellers', subtitle: 'The pieces our community reaches for most.', collection: 'c-best-sellers', count: 4, showPrices: true }
  },
  {
    id: 'b-story',
    type: 'story',
    visible: true,
    data: {
      eyebrow: 'Our craft',
      title: 'Every stitch, a small act of devotion.',
      body: 'Each piece is embroidered by a family-run workshop in North Carolina that has been stitching since 1978. We make fewer things, and we make them to last.',
      image: images.story,
      ctaLabel: 'Read our story',
      ctaLink: '/about',
      imageSide: 'left'
    }
  },
  {
    id: 'b-new',
    type: 'productRow',
    visible: true,
    data: { title: 'Scripture Series', subtitle: 'Verses set in type and thread.', collection: 'c-scripture', count: 4, showPrices: true }
  },
  {
    id: 'b-ugc',
    type: 'testimonials',
    visible: true,
    data: {
      title: 'Worn by our community',
      items: [
      { quote: 'I wear my Faithful Tee every Sunday. It’s the softest shirt I own and it sparks conversations.', name: 'Chloe A.', detail: 'Portland, OR', image: images.ugc },
      { quote: 'We ordered 40 tees for our youth retreat. Quality held up through a week of camp.', name: 'Olivia M.', detail: 'Youth pastor, Phoenix', image: images.teeBlack },
      { quote: 'The Grace Hoodie is a daily reminder. Heavy, warm, and quietly beautiful.', name: 'Ava M.', detail: 'Nashville, TN', image: images.hoodieCream }]

    }
  },
  {
    id: 'b-news',
    type: 'newsletter',
    visible: true,
    data: { headline: 'Join the flock', body: 'New drops, devotionals from our journal, and 10% off your first order.', buttonLabel: 'Subscribe', theme: 'black' }
  }]

},
{
  id: 'about',
  name: 'Our Story',
  path: '/about',
  lastPublished: '2026-09-12T11:00:00',
  blocks: [
  {
    id: 'a-hero',
    type: 'hero',
    visible: true,
    data: {
      headline: 'Made for those who follow.',
      subheadline: 'Shepherds Thread began on a walk through a Tennessee pasture with Psalm 23 on our minds.',
      ctaLabel: 'Shop the collection',
      ctaLink: '/shop',
      image: images.hero,
      align: 'center'
    }
  },
  {
    id: 'a-text',
    type: 'text',
    visible: true,
    data: {
      heading: 'Why we make clothing',
      body: 'We believe what you wear can be a quiet testimony. Not loud slogans — just honest garments, carefully made, carrying words worth remembering.',
      align: 'center'
    }
  },
  {
    id: 'a-story',
    type: 'story',
    visible: true,
    data: {
      eyebrow: 'The workshop',
      title: 'Stitched in North Carolina since 1978.',
      body: 'Our embroidery partners are a three-generation family business. Every cross, crook, and lamb passes through their hands.',
      image: images.story,
      ctaLabel: 'Visit the journal',
      ctaLink: '/journal',
      imageSide: 'right'
    }
  },
  {
    id: 'a-news',
    type: 'newsletter',
    visible: true,
    data: { headline: 'Walk with us', body: 'Monthly letters from the studio, plus early access to new collections.', buttonLabel: 'Subscribe', theme: 'cream' }
  }]

},
{
  id: 'journal',
  name: 'Journal landing',
  path: '/journal',
  lastPublished: '2026-10-22T09:30:00',
  blocks: [
  {
    id: 'j-hero',
    type: 'hero',
    visible: true,
    data: {
      headline: 'The Journal',
      subheadline: 'Devotionals, behind-the-seams stories, and notes from our community.',
      ctaLabel: 'Read the latest',
      ctaLink: '/journal/season-of-gathering',
      image: images.journal,
      align: 'center'
    }
  },
  {
    id: 'j-text',
    type: 'text',
    visible: true,
    data: { heading: 'Latest entries', body: 'Posts appear here automatically in order of publish date.', align: 'left' }
  },
  {
    id: 'j-news',
    type: 'newsletter',
    visible: false,
    data: { headline: 'Get the journal by email', body: 'One letter a month. No noise.', buttonLabel: 'Subscribe', theme: 'cream' }
  }]

}];