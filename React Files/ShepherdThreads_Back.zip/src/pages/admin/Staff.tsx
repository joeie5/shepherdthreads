import React, { useState } from 'react';
import { toast } from 'sonner';
import { EllipsisIcon, LockIcon, MailIcon, Trash2Icon, UserPlusIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Tabs } from '../../components/ui/Tabs';
import { Select } from '../../components/ui/Select';
import { Toggle } from '../../components/ui/Toggle';
import { Menu } from '../../components/ui/Menu';
import { Modal } from '../../components/ui/Modal';
import { Field } from '../../components/ui/Field';
import { TextInput } from '../../components/ui/TextInput';
import { RadioGroup } from '../../components/ui/RadioGroup';
import { Avatar } from '../../components/ui/Avatar';
import { permissionSections, roleDescriptions, rolePermissions, staff as initialStaff } from '../../data/staff';
import type { Role, StaffMember } from '../../types/admin';
import { cn } from '../../utils/cn';
import { formatDateTime } from '../../utils/format';
import { tableClass, tdClass, thClass } from '../../utils/styles';

const roles: Role[] = ['Admin', 'Editor', 'Support'];

export function Staff() {
  const [tab, setTab] = useState('members');
  const [members, setMembers] = useState<StaffMember[]>(initialStaff);
  const [perms, setPerms] = useState<Record<Role, string[]>>(rolePermissions);
  const [permsDirty, setPermsDirty] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [invite, setInvite] = useState({ name: '', email: '', role: 'Editor' as Role });
  const [inviteError, setInviteError] = useState('');

  const sendInvite = () => {
    if (!invite.name.trim() || !/^\S+@\S+\.\S+$/.test(invite.email)) {
      setInviteError('Enter a name and a valid email address');
      return;
    }
    setMembers((prev) => [...prev, { id: `s-${Date.now()}`, name: invite.name, email: invite.email, role: invite.role, status: 'invited', lastActive: null, twoFactor: false }]);
    toast.success(`Invite sent to ${invite.email}`);
    setInvite({ name: '', email: '', role: 'Editor' });
    setInviteError('');
    setInviteOpen(false);
  };

  const togglePerm = (role: Role, section: string) => {
    setPerms((p) => ({ ...p, [role]: p[role].includes(section) ? p[role].filter((x) => x !== section) : [...p[role], section] }));
    setPermsDirty(true);
  };

  return (
    <PageContainer narrow>
      <PageHeader
        title="Staff & roles"
        description="Invite your team and decide what each role can see and change."
        actions={
        <Button variant="primary" icon={UserPlusIcon} onClick={() => setInviteOpen(true)}>
            Invite staff
          </Button>
        } />
      

      <Tabs
        value={tab}
        onChange={setTab}
        className="mb-5"
        tabs={[
        { id: 'members', label: 'Staff members', count: members.length },
        { id: 'roles', label: 'Roles & permissions' }]
        } />
      

      {tab === 'members' ?
      <section className="overflow-x-auto rounded-lg border border-line bg-white">
          <table className={tableClass}>
            <thead>
              <tr>
                <th className={thClass}>Name</th>
                <th className={thClass}>Role</th>
                <th className={cn(thClass, 'hidden md:table-cell')}>Two-step login</th>
                <th className={cn(thClass, 'hidden lg:table-cell')}>Last active</th>
                <th className={cn(thClass, 'w-12')}>
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {members.map((m) =>
            <tr key={m.id}>
                  <td className={tdClass}>
                    <div className="flex items-center gap-3">
                      <Avatar name={m.name} size="sm" />
                      <div className="min-w-0">
                        <p className="flex items-center gap-2 font-medium text-ink">
                          {m.name}
                          {m.id === 's-hannah' && <Badge tone="brass">Owner</Badge>}
                          {m.status === 'invited' && <Badge tone="info">Invite pending</Badge>}
                        </p>
                        <p className="truncate text-xs text-ink-500">{m.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className={tdClass}>
                    <Select
                  compact
                  aria-label={`Role for ${m.name}`}
                  value={m.role}
                  disabled={m.id === 's-hannah'}
                  onChange={(e) => {
                    const role = e.target.value as Role;
                    setMembers((prev) => prev.map((x) => x.id === m.id ? { ...x, role } : x));
                    toast.success(`${m.name} is now ${role === 'Admin' ? 'an' : 'a'} ${role}`);
                  }}
                  options={roles.map((r) => ({ value: r, label: r }))}
                  className="w-32" />
                
                  </td>
                  <td className={cn(tdClass, 'hidden md:table-cell')}>
                    {m.twoFactor ? <Badge tone="success">On</Badge> : <Badge tone="warning">Off</Badge>}
                  </td>
                  <td className={cn(tdClass, 'hidden whitespace-nowrap text-ink-600 lg:table-cell')}>{m.lastActive ? formatDateTime(m.lastActive) : '—'}</td>
                  <td className={cn(tdClass, 'w-12 text-right')}>
                    {m.id !== 's-hannah' &&
                <Menu
                  ariaLabel={`Actions for ${m.name}`}
                  triggerClassName="flex h-8 w-8 items-center justify-center rounded-md text-ink-500 hover:bg-black/[0.05] hover:text-ink"
                  trigger={<EllipsisIcon className="h-4 w-4" />}
                  items={[
                  ...(m.status === 'invited' ? [{ label: 'Resend invite', icon: MailIcon, onClick: () => toast.success(`Invite resent to ${m.email}`) }] : []),
                  { label: 'Require two-step login', icon: LockIcon, onClick: () => toast.success(`${m.name} will set up two-step login next sign-in`) },
                  {
                    label: 'Remove from store',
                    icon: Trash2Icon,
                    danger: true,
                    divider: true,
                    onClick: () => {
                      setMembers((prev) => prev.filter((x) => x.id !== m.id));
                      toast.success(`${m.name} removed`);
                    }
                  }]
                  } />

                }
                  </td>
                </tr>
            )}
            </tbody>
          </table>
        </section> :

      <section className="rounded-lg border border-line bg-white">
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={cn(thClass, 'h-auto py-3')}>Section</th>
                  {roles.map((r) =>
                <th key={r} className={cn(thClass, 'h-auto w-[150px] py-3 align-top')}>
                      <span className="block text-[13px] font-semibold text-ink">{r}</span>
                      <span className="mt-0.5 block whitespace-normal font-normal text-ink-500">{roleDescriptions[r]}</span>
                    </th>
                )}
                </tr>
              </thead>
              <tbody>
                {permissionSections.map((s) =>
              <tr key={s.id}>
                    <td className={tdClass}>
                      <p className="font-medium text-ink">{s.label}</p>
                      <p className="text-xs text-ink-500">{s.description}</p>
                    </td>
                    {roles.map((r) =>
                <td key={r} className={tdClass}>
                        <Toggle
                    srLabel={`${r} can access ${s.label}`}
                    checked={perms[r].includes(s.id)}
                    disabled={r === 'Admin'}
                    onChange={() => togglePerm(r, s.id)} />
                  
                      </td>
                )}
                  </tr>
              )}
              </tbody>
            </table>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
            <p className="flex items-center gap-1.5 text-xs text-ink-500">
              <LockIcon className="h-3.5 w-3.5" /> Admins always have full access.
            </p>
            <Button
            variant="primary"
            disabled={!permsDirty}
            onClick={() => {
              setPermsDirty(false);
              toast.success('Permissions updated', { description: 'Staff see changes the next time they load the admin.' });
            }}>
            
              Save permissions
            </Button>
          </div>
        </section>
      }

      <Modal
        open={inviteOpen}
        onClose={() => setInviteOpen(false)}
        title="Invite a staff member"
        description="They’ll get an email to create their login."
        footer={
        <>
            <Button onClick={() => setInviteOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={sendInvite}>
              Send invite
            </Button>
          </>
        }>
        
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Full name" htmlFor="inv-name">
              <TextInput id="inv-name" value={invite.name} onChange={(e) => setInvite({ ...invite, name: e.target.value })} />
            </Field>
            <Field label="Email" htmlFor="inv-email">
              <TextInput id="inv-email" type="email" value={invite.email} onChange={(e) => setInvite({ ...invite, email: e.target.value })} />
            </Field>
          </div>
          <div>
            <p className="mb-2 text-[13px] font-medium text-ink">Role</p>
            <RadioGroup
              name="inv-role"
              ariaLabel="Role"
              value={invite.role}
              onChange={(v) => setInvite({ ...invite, role: v as Role })}
              options={roles.map((r) => ({ value: r, label: r, description: roleDescriptions[r] }))} />
            
          </div>
          {inviteError && <p className="text-xs text-danger">{inviteError}</p>}
        </div>
      </Modal>
    </PageContainer>);

}