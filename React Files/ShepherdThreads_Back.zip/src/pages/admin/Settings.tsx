import React from 'react';
import { Navigate, NavLink, useParams } from 'react-router-dom';
import { CreditCardIcon, MenuIcon, PaletteIcon, PanelBottomIcon, StoreIcon, TruckIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { GeneralSettings } from '../../components/settings/GeneralSettings';
import { ThemeSettings } from '../../components/settings/ThemeSettings';
import { NavigationSettings } from '../../components/settings/NavigationSettings';
import { FooterSettings } from '../../components/settings/FooterSettings';
import { ShippingTaxSettings } from '../../components/settings/ShippingTaxSettings';
import { PaymentSettings } from '../../components/settings/PaymentSettings';
import { cn } from '../../utils/cn';

const sections = [
{ id: 'general', label: 'General', description: 'Store name, logo, and contact details', icon: StoreIcon, component: GeneralSettings },
{ id: 'theme', label: 'Theme', description: 'Brand colors and typography', icon: PaletteIcon, component: ThemeSettings },
{ id: 'navigation', label: 'Navigation', description: 'Header menu links and order', icon: MenuIcon, component: NavigationSettings },
{ id: 'footer', label: 'Footer', description: 'Links, socials, and verse of the month', icon: PanelBottomIcon, component: FooterSettings },
{ id: 'shipping', label: 'Shipping & tax', description: 'Rates, zones, and sales tax', icon: TruckIcon, component: ShippingTaxSettings },
{ id: 'payments', label: 'Payments', description: 'Payment providers and checkout', icon: CreditCardIcon, component: PaymentSettings }];


export function Settings() {
  const { tab } = useParams();
  const current = sections.find((s) => s.id === tab);
  if (!current) return <Navigate to="/settings/general" replace />;
  const Section = current.component;

  return (
    <PageContainer>
      <PageHeader breadcrumbs={[{ label: 'Settings', to: '/settings/general' }, { label: current.label }]} title={current.label} description={current.description} />
      <div className="grid gap-6 lg:grid-cols-[220px_minmax(0,1fr)]">
        <nav aria-label="Settings sections" className="-mx-4 overflow-x-auto px-4 lg:mx-0 lg:overflow-visible lg:px-0">
          <ul className="flex gap-1 lg:sticky lg:top-6 lg:flex-col">
            {sections.map((s) => {
              const Icon = s.icon;
              return (
                <li key={s.id}>
                  <NavLink
                    to={`/settings/${s.id}`}
                    className={({ isActive }) =>
                    cn(
                      'flex h-9 items-center gap-2.5 whitespace-nowrap rounded-md px-3 text-[13px] font-medium transition-colors duration-150',
                      isActive ? 'bg-white text-ink shadow-sm ring-1 ring-line' : 'text-ink-600 hover:bg-black/[0.04] hover:text-ink'
                    )
                    }>
                    
                    {({ isActive }) =>
                    <>
                        <Icon className={cn('h-4 w-4', isActive ? 'text-brass-text' : 'text-stone')} />
                        {s.label}
                      </>
                    }
                  </NavLink>
                </li>);

            })}
          </ul>
        </nav>
        <div className="min-w-0">
          <Section />
        </div>
      </div>
    </PageContainer>);

}