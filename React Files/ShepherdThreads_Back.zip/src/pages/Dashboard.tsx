import React from 'react';
import { Link } from 'react-router-dom';
import { ExternalLinkIcon } from 'lucide-react';
import { PageContainer } from '../components/layout/PageContainer';
import { PageHeader } from '../components/ui/PageHeader';
import { Button } from '../components/ui/Button';
import { Panel } from '../components/ui/Panel';
import { KpiStrip } from '../components/dashboard/KpiStrip';
import { SalesTrendChart } from '../components/dashboard/SalesTrendChart';
import { AttentionList } from '../components/dashboard/AttentionList';
import { QuickActions } from '../components/dashboard/QuickActions';
import { LowStockList } from '../components/dashboard/LowStockList';
import { OrdersTable } from '../components/orders/OrdersTable';
import { orders } from '../data/orders';

export function Dashboard() {
  return (
    <PageContainer>
      <PageHeader
        title="Good morning, Hannah"
        description="Here’s how Shepherds Thread is doing today — Sunday, November 1."
        actions={
        <Button
          icon={ExternalLinkIcon}
          onClick={() => window.open('https://shepherdsthread.co', '_blank', 'noopener')}>
          
            View storefront
          </Button>
        } />
      

      <div className="space-y-6">
        <KpiStrip />

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <SalesTrendChart />
          </div>
          <div className="space-y-6">
            <AttentionList />
            <QuickActions />
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Panel
            title="Recent orders"
            className="lg:col-span-2"
            padded={false}
            actions={
            <Link to="/orders" className="text-[13px] font-medium text-ink-600 hover:text-ink">
                View all
              </Link>
            }>
            
            <OrdersTable orders={orders.slice(0, 6)} compact />
          </Panel>
          <LowStockList />
        </div>
      </div>
    </PageContainer>);

}