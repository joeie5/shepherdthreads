import React, { useState } from 'react';
import { toast } from 'sonner';
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { DownloadIcon } from 'lucide-react';
import { PageContainer } from '../components/layout/PageContainer';
import { PageHeader } from '../components/ui/PageHeader';
import { Panel } from '../components/ui/Panel';
import { Button } from '../components/ui/Button';
import { Select } from '../components/ui/Select';
import { TextInput } from '../components/ui/TextInput';
import { SegmentedControl } from '../components/ui/SegmentedControl';
import { ChartTooltip } from '../components/charts/ChartTooltip';
import { funnel, reports, salesByCollection, salesByProduct, salesTrend, trafficSources } from '../data/analytics';
import { cn } from '../utils/cn';
import { downloadCsv } from '../utils/csv';
import { formatCurrency, formatNumber } from '../utils/format';

const rangeFactor: Record<string, number> = { '7d': 0.24, '30d': 1, '90d': 2.9, ytd: 9.6, custom: 1 };
const rangeLabel: Record<string, string> = { '7d': 'Last 7 days', '30d': 'Last 30 days', '90d': 'Last 90 days', ytd: 'Year to date', custom: 'Custom range' };

export function Analytics() {
  const [range, setRange] = useState('30d');
  const [from, setFrom] = useState('2026-10-03');
  const [to, setTo] = useState('2026-11-01');
  const [productMetric, setProductMetric] = useState<'revenue' | 'units'>('revenue');
  const f = rangeFactor[range];

  const trend = range === '7d' ? salesTrend.slice(-7) : salesTrend;
  const trendWithPrev = trend.map((d, i) => ({ ...d, previous: Math.round(d.revenue * (0.82 + i * 7 % 10 / 50)) }));
  const gross = Math.round(salesTrend.reduce((s, d) => s + d.revenue, 0) * f);
  const orderCount = Math.round(salesTrend.reduce((s, d) => s + d.orders, 0) * f);

  const summary = [
  { label: 'Gross sales', value: formatCurrency(gross, false), change: '+14.2%', up: true, primary: true },
  { label: 'Orders', value: formatNumber(orderCount), change: '+9.8%', up: true },
  { label: 'Average order', value: formatCurrency(gross / orderCount), change: '+4.0%', up: true },
  { label: 'Conversion', value: '1.45%', change: '+0.12 pts', up: true },
  { label: 'Returning customers', value: '31%', change: '−2.1 pts', up: false }];


  const maxSessions = Math.max(...trafficSources.map((t) => t.sessions));

  return (
    <PageContainer>
      <PageHeader
        title="Analytics"
        description={`${rangeLabel[range]} · compared with the previous period`}
        actions={
        <>
            <Select
            aria-label="Date range"
            value={range}
            onChange={(e) => setRange(e.target.value)}
            options={Object.keys(rangeLabel).map((k) => ({ value: k, label: rangeLabel[k] }))}
            className="w-44" />
          
            {range === 'custom' &&
          <div className="flex items-center gap-2">
                <TextInput type="date" aria-label="From" value={from} onChange={(e) => setFrom(e.target.value)} className="w-40" />
                <span className="text-ink-500">–</span>
                <TextInput type="date" aria-label="To" value={to} min={from} onChange={(e) => setTo(e.target.value)} className="w-40" />
              </div>
          }
            <Button
            icon={DownloadIcon}
            onClick={() => {
              downloadCsv('sales-summary.csv', trend.map((d) => ({ Date: d.date, Revenue: d.revenue, Orders: d.orders })));
              toast.success('Sales summary exported');
            }}>
            
              Export
            </Button>
          </>
        } />
      

      <div className="space-y-6">
        <section aria-label="Summary" className="grid grid-cols-2 overflow-hidden rounded-lg border border-line bg-white md:grid-cols-[1.5fr_1fr_1fr_1fr_1fr]">
          {summary.map((s, i) =>
          <div key={s.label} className={cn('border-line p-5', i > 0 && 'md:border-l', i % 2 === 1 && 'border-l', i >= 2 && 'border-t md:border-t-0', i === 4 && 'col-span-2 md:col-span-1')}>
              <p className="text-[13px] text-ink-500">{s.label}</p>
              <p className={cn('mt-2 font-semibold leading-none tracking-tight tabular-nums text-ink', s.primary ? 'text-[30px]' : 'text-xl')}>{s.value}</p>
              <p className={cn('mt-2 text-xs font-medium tabular-nums', s.up ? 'text-success' : 'text-danger')}>{s.change}</p>
            </div>
          )}
        </section>

        <div className="grid gap-6 lg:grid-cols-3">
          <Panel title="Sales over time" description="Revenue vs. previous period" className="lg:col-span-2">
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trendWithPrev} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke="#EEECE7" />
                  <XAxis dataKey="date" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#696864' }} interval={range === '7d' ? 0 : 4} />
                  <YAxis tickLine={false} axisLine={false} width={44} tick={{ fontSize: 11, fill: '#696864' }} tickFormatter={(v: number) => `$${(v / 1000).toFixed(1)}k`} />
                  <Tooltip content={<ChartTooltip formatter={(v, n) => `${n === 'previous' ? 'Previous' : 'Current'}: ${formatCurrency(v, false)}`} />} />
                  <Line type="monotone" dataKey="previous" stroke="#B9B5AC" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                  <Line type="monotone" dataKey="revenue" stroke="#0A0A0A" strokeWidth={2} dot={false} activeDot={{ r: 4, fill: '#B08D57', stroke: '#fff' }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-3 flex gap-5 text-xs text-ink-500">
              <span className="flex items-center gap-2">
                <span className="h-0.5 w-4 bg-ink" /> This period
              </span>
              <span className="flex items-center gap-2">
                <span className="h-0 w-4 border-t border-dashed border-stone" /> Previous period
              </span>
            </div>
          </Panel>

          <Panel title="Conversion funnel" description="Where shoppers drop off">
            <ol className="space-y-3.5">
              {funnel.map((step, i) => {
                const pct = step.value / funnel[0].value * 100;
                const drop = i > 0 ? 100 - step.value / funnel[i - 1].value * 100 : null;
                return (
                  <li key={step.stage}>
                    <div className="mb-1 flex items-baseline justify-between text-[13px]">
                      <span className="text-ink">{step.stage}</span>
                      <span className="tabular-nums text-ink">{formatNumber(Math.round(step.value * f))}</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-line">
                      <div className={cn('h-full rounded-full', i === funnel.length - 1 ? 'bg-brass' : 'bg-ink')} style={{ width: `${Math.max(pct, 1.5)}%` }} />
                    </div>
                    {drop !== null && <p className="mt-1 text-[11px] tabular-nums text-ink-500">{drop.toFixed(0)}% dropped off</p>}
                  </li>);

              })}
            </ol>
          </Panel>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Panel
            title="Sales by product"
            actions={
            <SegmentedControl<'revenue' | 'units'>
              ariaLabel="Product metric"
              value={productMetric}
              onChange={setProductMetric}
              options={[
              { value: 'revenue', label: 'Revenue' },
              { value: 'units', label: 'Units' }]
              } />

            }>
            
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={salesByProduct} layout="vertical" margin={{ top: 0, right: 16, left: 0, bottom: 0 }}>
                  <CartesianGrid horizontal={false} stroke="#EEECE7" />
                  <XAxis type="number" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#696864' }} tickFormatter={(v: number) => productMetric === 'revenue' ? `$${v / 1000}k` : String(v)} />
                  <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} width={116} tick={{ fontSize: 12, fill: '#0A0A0A' }} />
                  <Tooltip cursor={{ fill: 'rgba(10,10,10,0.04)' }} content={<ChartTooltip formatter={(v) => productMetric === 'revenue' ? formatCurrency(v, false) : `${v} units`} />} />
                  <Bar dataKey={productMetric} fill="#0A0A0A" radius={[0, 3, 3, 0]} maxBarSize={18} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Panel>

          <Panel title="Sales by collection">
            <ul className="space-y-4">
              {salesByCollection.map((c) =>
              <li key={c.name}>
                  <div className="mb-1.5 flex items-baseline justify-between gap-3 text-[13px]">
                    <span className="truncate text-ink">{c.name}</span>
                    <span className="whitespace-nowrap tabular-nums text-ink">
                      {formatCurrency(Math.round(c.revenue * f), false)} <span className="text-ink-500">· {c.share}%</span>
                    </span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-line">
                    <div className="h-full rounded-full bg-ink" style={{ width: `${c.share * 2.5}%` }} />
                  </div>
                </li>
              )}
            </ul>
          </Panel>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Panel title="Traffic sources" padded={false} className="lg:col-span-2">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="text-xs text-ink-500">
                    <th className="h-9 border-b border-line px-5 font-medium">Source</th>
                    <th className="h-9 border-b border-line px-4 font-medium">Sessions</th>
                    <th className="h-9 border-b border-line px-4 text-right font-medium">Conversion</th>
                  </tr>
                </thead>
                <tbody>
                  {trafficSources.map((t) =>
                  <tr key={t.source}>
                      <td className="border-b border-line px-5 py-2.5 text-ink">{t.source}</td>
                      <td className="border-b border-line px-4 py-2.5">
                        <div className="flex items-center gap-3">
                          <div className="h-1.5 w-32 overflow-hidden rounded-full bg-line">
                            <div className="h-full rounded-full bg-ink" style={{ width: `${t.sessions / maxSessions * 100}%` }} />
                          </div>
                          <span className="tabular-nums text-ink-600">{formatNumber(Math.round(t.sessions * f))}</span>
                        </div>
                      </td>
                      <td className={cn('border-b border-line px-4 py-2.5 text-right tabular-nums', t.conversion >= 2.5 ? 'font-medium text-success' : 'text-ink')}>{t.conversion}%</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Panel>

          <Panel title="Reports" description={`Exports use ${rangeLabel[range].toLowerCase()}`} padded={false}>
            <ul>
              {reports.map((r) =>
              <li key={r.id} className="flex items-center gap-3 border-b border-line px-5 py-3 last:border-b-0">
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-medium text-ink">{r.name}</p>
                    <p className="text-xs text-ink-500">{r.description}</p>
                  </div>
                  <Button
                  size="sm"
                  variant="ghost"
                  icon={DownloadIcon}
                  aria-label={`Download ${r.name}`}
                  onClick={() => {
                    downloadCsv(`${r.id}.csv`, trend.map((d) => ({ Date: d.date, Revenue: d.revenue, Orders: d.orders })));
                    toast.success(`${r.name} downloaded`);
                  }} />
                
                </li>
              )}
            </ul>
          </Panel>
        </div>
      </div>
    </PageContainer>);

}