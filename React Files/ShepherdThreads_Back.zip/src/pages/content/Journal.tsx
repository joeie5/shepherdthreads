import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpenIcon, PanelsTopLeftIcon, PlusIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Tabs } from '../../components/ui/Tabs';
import { SearchInput } from '../../components/ui/SearchInput';
import { Avatar } from '../../components/ui/Avatar';
import { EmptyState } from '../../components/ui/EmptyState';
import { posts } from '../../data/posts';
import type { PostStatus } from '../../types/content';
import { cn } from '../../utils/cn';
import { formatDate } from '../../utils/format';
import { postStatusMeta } from '../../utils/status';
import { rowClass, tableClass, tdClass, thClass } from '../../utils/styles';

export function Journal() {
  const navigate = useNavigate();
  const [tab, setTab] = useState('all');
  const [query, setQuery] = useState('');

  const filtered = useMemo(
    () =>
    posts.
    filter((p) => (tab === 'all' || p.status === tab) && p.title.toLowerCase().includes(query.toLowerCase())).
    sort((a, b) => b.date.localeCompare(a.date)),
    [tab, query]
  );
  const count = (s: PostStatus) => posts.filter((p) => p.status === s).length;

  return (
    <PageContainer>
      <PageHeader
        title="Journal"
        description="Devotionals, stories, and guides published to the Journal on web and in the app."
        actions={
        <>
            <Button icon={PanelsTopLeftIcon} onClick={() => navigate('/content/journal')}>
              Edit journal landing page
            </Button>
            <Button variant="primary" icon={PlusIcon} onClick={() => navigate('/journal/new')}>
              New post
            </Button>
          </>
        } />
      

      <section className="rounded-lg border border-line bg-white">
        <div className="flex flex-col gap-3 px-4 pt-3 md:flex-row md:items-end md:justify-between">
          <Tabs
            value={tab}
            onChange={setTab}
            className="border-b-0"
            tabs={[
            { id: 'all', label: 'All', count: posts.length },
            { id: 'published', label: 'Published', count: count('published') },
            { id: 'scheduled', label: 'Scheduled', count: count('scheduled') },
            { id: 'draft', label: 'Drafts', count: count('draft') }]
            } />
          
          <SearchInput value={query} onChange={setQuery} placeholder="Search posts" className="pb-3 md:w-64" />
        </div>
        {filtered.length === 0 ?
        <div className="border-t border-line">
            <EmptyState icon={BookOpenIcon} title="No posts here" description="Write your first entry to share with your community." />
          </div> :

        <div className="overflow-x-auto border-t border-line">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Post</th>
                  <th className={thClass}>Status</th>
                  <th className={cn(thClass, 'hidden md:table-cell')}>Author</th>
                  <th className={thClass}>Date</th>
                  <th className={cn(thClass, 'hidden lg:table-cell')}>Tags</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p) => {
                const meta = postStatusMeta[p.status];
                return (
                  <tr key={p.id} onClick={() => navigate(`/journal/${p.id}`)} className={rowClass}>
                      <td className={cn(tdClass, 'max-w-[460px]')}>
                        <div className="flex items-center gap-3">
                          <img src={p.cover} alt="" className="h-12 w-[72px] shrink-0 rounded border border-line object-cover" />
                          <div className="min-w-0">
                            <p className="truncate font-medium text-ink">{p.title}</p>
                            <p className="truncate text-xs text-ink-500">{p.excerpt}</p>
                          </div>
                        </div>
                      </td>
                      <td className={tdClass}>
                        <Badge tone={meta.tone} dot>
                          {meta.label}
                        </Badge>
                      </td>
                      <td className={cn(tdClass, 'hidden md:table-cell')}>
                        <span className="flex items-center gap-2 whitespace-nowrap text-ink-600">
                          <Avatar name={p.author} size="sm" />
                          {p.author}
                        </span>
                      </td>
                      <td className={cn(tdClass, 'whitespace-nowrap text-ink-600')}>
                        {p.status === 'scheduled' ? `Goes live ${formatDate(p.date, 'MMM d')}` : formatDate(p.date)}
                      </td>
                      <td className={cn(tdClass, 'hidden lg:table-cell')}>
                        <div className="flex flex-wrap gap-1">
                          {p.tags.map((t) =>
                        <Badge key={t}>{t}</Badge>
                        )}
                        </div>
                      </td>
                    </tr>);

              })}
              </tbody>
            </table>
          </div>
        }
      </section>
    </PageContainer>);

}