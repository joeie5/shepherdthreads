import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';
import { BookOpenIcon, PlusIcon, RefreshCwIcon, XIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Panel } from '../../components/ui/Panel';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Field } from '../../components/ui/Field';
import { TextInput } from '../../components/ui/TextInput';
import { TextArea } from '../../components/ui/TextArea';
import { Select } from '../../components/ui/Select';
import { RadioGroup } from '../../components/ui/RadioGroup';
import { ImageDropzone } from '../../components/ui/ImageDropzone';
import { EmptyState } from '../../components/ui/EmptyState';
import { RichTextEditor } from '../../components/editor/RichTextEditor';
import { SeoFields } from '../../components/editor/SeoFields';
import { postAuthors, posts } from '../../data/posts';
import type { Post } from '../../types/content';
import { postStatusMeta } from '../../utils/status';

const blankPost: Post = {
  id: 'new',
  title: '',
  slug: '',
  excerpt: '',
  status: 'draft',
  author: 'Hannah Brooks',
  date: '2026-11-01',
  tags: [],
  cover: '',
  readMinutes: 0,
  body: ''
};

const suggestedTags = ['Devotional', 'Behind the seams', 'Collections', 'Community', 'Craft', 'Guides', 'Advent', 'Our story'];

export function PostEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = id === 'new';
  const source = posts.find((p) => p.id === id);
  const [post, setPost] = useState<Post>(source ?? blankPost);
  const [publishMode, setPublishMode] = useState(source?.status === 'scheduled' ? 'schedule' : source?.status === 'published' ? 'now' : 'draft');
  const [scheduleDate, setScheduleDate] = useState(source?.status === 'scheduled' ? source.date : '2026-11-08');
  const [scheduleTime, setScheduleTime] = useState('07:00');
  const [newTag, setNewTag] = useState('');
  const [seo, setSeo] = useState({ title: source?.title ?? '', description: source?.excerpt ?? '' });
  const [titleError, setTitleError] = useState(false);

  if (!isNew && !source) {
    return (
      <PageContainer>
        <EmptyState icon={BookOpenIcon} title="Post not found" description="It may have been deleted." action={<Button onClick={() => navigate('/journal')}>Back to journal</Button>} />
      </PageContainer>);

  }

  const patch = (p: Partial<Post>) => setPost((x) => ({ ...x, ...p }));
  const addTag = (t: string) => {
    const tag = t.trim();
    if (tag && !post.tags.includes(tag)) patch({ tags: [...post.tags, tag] });
    setNewTag('');
  };

  const primaryLabel = publishMode === 'now' ? source?.status === 'published' ? 'Update' : 'Publish' : publishMode === 'schedule' ? 'Schedule' : 'Save draft';

  const submit = () => {
    if (!post.title.trim()) {
      setTitleError(true);
      toast.error('Add a title before saving');
      return;
    }
    const msg =
    publishMode === 'now' ? 'Post published to the Journal' : publishMode === 'schedule' ? `Scheduled for ${scheduleDate} at ${scheduleTime}` : 'Draft saved';
    toast.success(msg);
    patch({ status: publishMode === 'now' ? 'published' : publishMode === 'schedule' ? 'scheduled' : 'draft' });
    if (isNew) navigate('/journal');
  };

  const status = postStatusMeta[post.status];

  return (
    <PageContainer narrow>
      <PageHeader
        breadcrumbs={[{ label: 'Journal', to: '/journal' }, { label: isNew ? 'New post' : post.title }]}
        title={isNew ? 'New post' : 'Edit post'}
        meta={!isNew && <Badge tone={status.tone}>{status.label}</Badge>}
        actions={
        <>
            <Button onClick={() => toast('Opening preview in a new tab')}>Preview</Button>
            <Button variant="primary" onClick={submit}>
              {primaryLabel}
            </Button>
          </>
        } />
      

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0 space-y-6">
          <section className="rounded-lg border border-line bg-white">
            {post.cover ?
            <div className="relative">
                <img src={post.cover} alt="Cover" className="aspect-[21/9] w-full rounded-t-lg object-cover" />
                <div className="absolute bottom-3 right-3 flex gap-2">
                  <label className="inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md bg-white/95 px-2.5 text-[13px] font-medium text-ink shadow-sm hover:bg-white">
                    <RefreshCwIcon className="h-3.5 w-3.5" />
                    Replace cover
                    <input type="file" accept="image/*" className="sr-only" onChange={(e) => e.target.files?.[0] && patch({ cover: URL.createObjectURL(e.target.files[0]) })} />
                  </label>
                  <button type="button" onClick={() => patch({ cover: '' })} aria-label="Remove cover" className="flex h-8 w-8 items-center justify-center rounded-md bg-white/95 text-ink shadow-sm hover:bg-white">
                    <XIcon className="h-4 w-4" />
                  </button>
                </div>
              </div> :

            <div className="p-5 pb-0">
                <ImageDropzone multiple={false} label="Add a cover image" hint="Shown on the journal page and when shared. 1600 × 900 recommended." onFiles={(urls) => patch({ cover: urls[0] })} />
              </div>
            }
            <div className="space-y-4 p-5">
              <label htmlFor="post-title" className="sr-only">
                Title
              </label>
              <input
                id="post-title"
                value={post.title}
                onChange={(e) => {
                  patch({ title: e.target.value, slug: isNew ? e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-') : post.slug });
                  setTitleError(false);
                }}
                placeholder="Post title"
                className={`w-full border-0 bg-transparent font-serif text-[32px] font-semibold leading-tight text-ink placeholder:text-stone focus:outline-none ${titleError ? 'placeholder:text-danger' : ''}`} />
              
              <RichTextEditor
                key={post.id}
                ariaLabel="Post body"
                allowImages
                minHeight={380}
                initialValue={post.body}
                placeholder="Begin your entry… Use the quote button for scripture."
                onChange={(body) => patch({ body })} />
              
            </div>
          </section>

          <Panel title="Excerpt" description="A short summary shown on the journal page.">
            <TextArea rows={2} aria-label="Excerpt" value={post.excerpt} onChange={(e) => patch({ excerpt: e.target.value })} />
          </Panel>

          <Panel title="Search engine listing">
            <SeoFields
              title={seo.title}
              description={seo.description}
              handle={post.slug}
              pathPrefix="/journal/"
              onTitle={(title) => setSeo({ ...seo, title })}
              onDescription={(description) => setSeo({ ...seo, description })}
              onHandle={(slug) => patch({ slug })} />
            
          </Panel>
        </div>

        <aside className="space-y-6">
          <Panel title="Publishing">
            <RadioGroup
              name="publish"
              ariaLabel="Publishing"
              value={publishMode}
              onChange={setPublishMode}
              options={[
              { value: 'draft', label: 'Save as draft', description: 'Only staff can see it' },
              { value: 'now', label: 'Publish now', description: 'Live on web and app immediately' },
              { value: 'schedule', label: 'Schedule', description: 'Publish automatically later' }]
              } />
            
            {publishMode === 'schedule' &&
            <div className="mt-4 grid grid-cols-2 gap-2 pl-6">
                <TextInput type="date" aria-label="Publish date" value={scheduleDate} min="2026-11-01" onChange={(e) => setScheduleDate(e.target.value)} />
                <TextInput type="time" aria-label="Publish time" value={scheduleTime} onChange={(e) => setScheduleTime(e.target.value)} />
              </div>
            }
            <Button variant="primary" className="mt-5 w-full" onClick={submit}>
              {primaryLabel}
            </Button>
          </Panel>

          <Panel title="Details">
            <div className="space-y-4">
              <Field label="Author" htmlFor="post-author">
                <Select id="post-author" value={post.author} onChange={(e) => patch({ author: e.target.value })} options={postAuthors.map((a) => ({ value: a, label: a }))} />
              </Field>
              <div>
                <p className="mb-1.5 text-[13px] font-medium text-ink">Tags</p>
                <div className="flex flex-wrap gap-1.5">
                  {post.tags.map((t) =>
                  <span key={t} className="inline-flex items-center gap-1 rounded-full bg-ink py-0.5 pl-2.5 pr-1 text-xs font-medium text-white">
                      {t}
                      <button type="button" aria-label={`Remove ${t}`} onClick={() => patch({ tags: post.tags.filter((x) => x !== t) })} className="rounded-full p-0.5 hover:bg-white/20">
                        <XIcon className="h-3 w-3" />
                      </button>
                    </span>
                  )}
                </div>
                <form
                  className="mt-2 flex gap-2"
                  onSubmit={(e) => {
                    e.preventDefault();
                    addTag(newTag);
                  }}>
                  
                  <input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="Add a tag"
                    aria-label="Add a tag"
                    className="h-8 min-w-0 flex-1 rounded-md border border-line-strong px-2.5 text-[13px] focus:border-ink focus:outline-none" />
                  
                  <Button size="sm" type="submit" icon={PlusIcon} aria-label="Add tag" />
                </form>
                <div className="mt-2 flex flex-wrap gap-1">
                  {suggestedTags.
                  filter((t) => !post.tags.includes(t)).
                  slice(0, 5).
                  map((t) =>
                  <button key={t} type="button" onClick={() => addTag(t)} className="rounded-full border border-line px-2 py-0.5 text-xs text-ink-600 hover:border-line-strong hover:text-ink">
                        + {t}
                      </button>
                  )}
                </div>
              </div>
            </div>
          </Panel>
        </aside>
      </div>
    </PageContainer>);

}