import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { toast } from 'sonner';
import { CopyIcon, ImagesIcon, Trash2Icon, UploadIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Button } from '../../components/ui/Button';
import { SearchInput } from '../../components/ui/SearchInput';
import { SegmentedControl } from '../../components/ui/SegmentedControl';
import { Toggle } from '../../components/ui/Toggle';
import { Drawer } from '../../components/ui/Drawer';
import { Field } from '../../components/ui/Field';
import { TextInput } from '../../components/ui/TextInput';
import { ImageDropzone } from '../../components/ui/ImageDropzone';
import { EmptyState } from '../../components/ui/EmptyState';
import { mediaAssets } from '../../data/media';
import type { MediaAsset } from '../../types/content';
import { cn } from '../../utils/cn';
import { formatDate } from '../../utils/format';

type Folder = 'all' | MediaAsset['folder'];

export function MediaLibrary() {
  const [assets, setAssets] = useState<MediaAsset[]>(mediaAssets);
  const [query, setQuery] = useState('');
  const [folder, setFolder] = useState<Folder>('all');
  const [unusedOnly, setUnusedOnly] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const active = assets.find((a) => a.id === activeId) ?? null;

  const filtered = useMemo(
    () =>
    assets.filter(
      (a) =>
      (folder === 'all' || a.folder === folder) && (
      !unusedOnly || a.usedIn.length === 0) && (
      a.name.toLowerCase().includes(query.toLowerCase()) || a.alt.toLowerCase().includes(query.toLowerCase()))
    ),
    [assets, folder, unusedOnly, query]
  );

  const upload = (urls: string[]) => {
    const added: MediaAsset[] = urls.map((url, i) => ({
      id: `m-new-${Date.now()}-${i}`,
      name: `upload-${Date.now().toString().slice(-5)}-${i + 1}.jpg`,
      url,
      folder: folder === 'all' ? 'Lifestyle' : folder,
      size: '—',
      dimensions: '—',
      uploadedAt: '2026-11-01',
      alt: '',
      usedIn: []
    }));
    setAssets((prev) => [...added, ...prev]);
    setUploadOpen(false);
    toast.success(`Uploaded ${urls.length} image${urls.length > 1 ? 's' : ''}`);
  };

  return (
    <PageContainer>
      <PageHeader
        title="Media library"
        description={`${assets.length} files · ${assets.filter((a) => a.usedIn.length === 0).length} not used anywhere`}
        actions={
        <Button variant="primary" icon={UploadIcon} onClick={() => setUploadOpen((o) => !o)}>
            Upload
          </Button>
        } />
      

      <AnimatePresence initial={false}>
        {uploadOpen &&
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
          className="overflow-hidden">
          
            <ImageDropzone className="mb-6 bg-white" onFiles={upload} />
          </motion.div>
        }
      </AnimatePresence>

      <div className="mb-5 flex flex-col gap-3 lg:flex-row lg:items-center">
        <SearchInput value={query} onChange={setQuery} placeholder="Search file name or alt text" className="lg:w-72" />
        <div className="overflow-x-auto">
          <SegmentedControl<Folder>
            ariaLabel="Folder"
            value={folder}
            onChange={setFolder}
            options={[
            { value: 'all', label: 'All' },
            { value: 'Products', label: 'Products' },
            { value: 'Lifestyle', label: 'Lifestyle' },
            { value: 'Journal', label: 'Journal' },
            { value: 'Brand', label: 'Brand' }]
            } />
          
        </div>
        <label className="flex items-center gap-2.5 text-[13px] text-ink-600 lg:ml-auto">
          <Toggle srLabel="Show unused only" checked={unusedOnly} onChange={setUnusedOnly} />
          Unused only
        </label>
      </div>

      {filtered.length === 0 ?
      <div className="rounded-lg border border-line bg-white">
          <EmptyState icon={ImagesIcon} title="No files found" description="Try another folder or search term." />
        </div> :

      <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
          {filtered.map((a) =>
        <li key={a.id}>
              <button
            type="button"
            onClick={() => setActiveId(a.id)}
            className={cn(
              'group block w-full overflow-hidden rounded-lg border bg-white text-left transition-[border-color,box-shadow] duration-150',
              activeId === a.id ? 'border-brass ring-1 ring-brass' : 'border-line hover:border-line-strong hover:shadow-sm'
            )}>
            
                <div className="aspect-square overflow-hidden bg-cream">
                  <img src={a.url} alt={a.alt} className="h-full w-full object-cover" />
                </div>
                <div className="p-2.5">
                  <p className="truncate text-[13px] font-medium text-ink">{a.name}</p>
                  <p className="mt-0.5 flex items-center gap-1.5 text-xs">
                    <span className={cn('h-1.5 w-1.5 rounded-full', a.usedIn.length ? 'bg-success' : 'bg-line-strong')} />
                    <span className={a.usedIn.length ? 'text-ink-600' : 'text-ink-500'}>
                      {a.usedIn.length ? `Used in ${a.usedIn.length} place${a.usedIn.length > 1 ? 's' : ''}` : 'Unused'}
                    </span>
                  </p>
                </div>
              </button>
            </li>
        )}
        </ul>
      }

      <Drawer
        open={!!active}
        onClose={() => setActiveId(null)}
        title={active?.name ?? ''}
        description={active ? `${active.folder} · uploaded ${formatDate(active.uploadedAt)}` : undefined}
        footer={
        active &&
        <>
              <Button
            variant="danger"
            icon={Trash2Icon}
            className="mr-auto"
            onClick={() => {
              if (active.usedIn.length) {
                toast.error('This image is still in use', { description: 'Replace it in the places listed before deleting.' });
                return;
              }
              setAssets((prev) => prev.filter((x) => x.id !== active.id));
              setActiveId(null);
              toast.success('File deleted');
            }}>
            
                Delete
              </Button>
              <Button
            variant="primary"
            onClick={() => {
              setActiveId(null);
              toast.success('Details saved');
            }}>
            
                Save
              </Button>
            </>

        }>
        
        {active &&
        <div className="space-y-5">
            <img src={active.url} alt={active.alt} className="w-full rounded-md border border-line object-contain" />
            <dl className="grid grid-cols-2 gap-3 text-[13px]">
              <div>
                <dt className="text-ink-500">Dimensions</dt>
                <dd className="text-ink">{active.dimensions}</dd>
              </div>
              <div>
                <dt className="text-ink-500">File size</dt>
                <dd className="text-ink">{active.size}</dd>
              </div>
            </dl>
            <Field label="Alt text" htmlFor="alt" hint="Describes the image for screen readers and search engines.">
              <TextInput
              id="alt"
              value={active.alt}
              onChange={(e) => setAssets((prev) => prev.map((x) => x.id === active.id ? { ...x, alt: e.target.value } : x))} />
            
            </Field>
            <Button
            size="sm"
            icon={CopyIcon}
            onClick={() => {
              navigator.clipboard?.writeText(active.url);
              toast.success('Image URL copied');
            }}>
            
              Copy URL
            </Button>
            <div className="border-t border-line pt-4">
              <p className="mb-2 text-[13px] font-medium text-ink">Where it’s used</p>
              {active.usedIn.length ?
            <ul className="space-y-1.5">
                  {active.usedIn.map((u) =>
              <li key={u} className="flex items-center gap-2 text-[13px] text-ink-600">
                      <span className="h-1.5 w-1.5 rounded-full bg-success" />
                      {u}
                    </li>
              )}
                </ul> :

            <p className="text-[13px] text-ink-500">Not used anywhere yet — safe to delete.</p>
            }
            </div>
          </div>
        }
      </Drawer>
    </PageContainer>);

}