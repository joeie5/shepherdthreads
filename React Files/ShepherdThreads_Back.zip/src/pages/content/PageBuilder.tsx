import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { toast } from 'sonner';
import { ExternalLinkIcon, MonitorIcon, SmartphoneIcon } from 'lucide-react';
import { Breadcrumbs } from '../../components/ui/Breadcrumbs';
import { Button } from '../../components/ui/Button';
import { Select } from '../../components/ui/Select';
import { SegmentedControl } from '../../components/ui/SegmentedControl';
import { BlockList } from '../../components/builder/BlockList';
import { BlockEditor } from '../../components/builder/BlockEditor';
import { PagePreview } from '../../components/builder/PagePreview';
import { sitePages } from '../../data/pages';
import type { BlockType, PageBlock, SitePage } from '../../types/content';
import { createBlock } from '../../utils/blocks';
import { cn } from '../../utils/cn';
import { formatDateTime } from '../../utils/format';

type Device = 'desktop' | 'mobile';

export function PageBuilder() {
  const { pageId = 'home' } = useParams();
  const navigate = useNavigate();
  const [pages, setPages] = useState<SitePage[]>(sitePages);
  const [dirty, setDirty] = useState<Record<string, boolean>>({});
  const [editingId, setEditingId] = useState<string | null>(null);
  const [device, setDevice] = useState<Device>('desktop');
  const [mobilePane, setMobilePane] = useState<'edit' | 'preview'>('edit');

  const page = pages.find((p) => p.id === pageId) ?? pages[0];
  const blocks = page.blocks;
  const editing = blocks.find((b) => b.id === editingId) ?? null;

  const setBlocks = (next: PageBlock[]) => {
    setPages((prev) => prev.map((p) => p.id === page.id ? { ...p, blocks: next } : p));
    setDirty((d) => ({ ...d, [page.id]: true }));
  };

  const updateBlock = (block: PageBlock) => setBlocks(blocks.map((b) => b.id === block.id ? block : b));

  const addBlock = (type: BlockType) => {
    const block = createBlock(type);
    setBlocks([...blocks, block]);
    setEditingId(block.id);
  };

  const publish = () => {
    setPages((prev) => prev.map((p) => p.id === page.id ? { ...p, lastPublished: '2026-11-01T10:12:00' } : p));
    setDirty((d) => ({ ...d, [page.id]: false }));
    toast.success(`${page.name} published`, { description: 'Live on web now. Apps refresh within a few minutes.' });
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-wrap items-center gap-3 border-b border-line bg-white px-4 py-2.5 lg:px-6">
        <div className="min-w-0">
          <Breadcrumbs items={[{ label: 'Pages', to: '/content' }, { label: page.name }]} />
          <div className="-mt-1 flex items-center gap-2">
            <Select
              compact
              aria-label="Page to edit"
              value={page.id}
              onChange={(e) => {
                setEditingId(null);
                navigate(`/content/${e.target.value}`);
              }}
              options={pages.map((p) => ({ value: p.id, label: p.name }))}
              className="w-44 font-medium" />
            
            <span className="hidden text-xs text-ink-500 md:inline">
              {dirty[page.id] ?
              <span className="inline-flex items-center gap-1.5 text-warning">
                  <span className="h-1.5 w-1.5 rounded-full bg-warning" /> Unpublished changes
                </span> :

              `Published ${formatDateTime(page.lastPublished)}`
              }
            </span>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <SegmentedControl<Device>
            ariaLabel="Preview device"
            value={device}
            onChange={setDevice}
            options={[
            { value: 'desktop', label: 'Desktop', icon: MonitorIcon, iconOnly: true },
            { value: 'mobile', label: 'Mobile', icon: SmartphoneIcon, iconOnly: true }]
            } />
          
          <Button icon={ExternalLinkIcon} className="hidden sm:inline-flex" onClick={() => window.open(`https://shepherdsthread.co${page.path}`, '_blank', 'noopener')}>
            View live
          </Button>
          <Button
            disabled={!dirty[page.id]}
            onClick={() => {
              setPages((prev) => prev.map((p) => p.id === page.id ? sitePages.find((s) => s.id === p.id) ?? p : p));
              setDirty((d) => ({ ...d, [page.id]: false }));
              setEditingId(null);
            }}>
            
            Discard
          </Button>
          <Button variant="primary" disabled={!dirty[page.id]} onClick={publish}>
            Publish
          </Button>
        </div>
      </div>

      <div className="flex border-b border-line bg-white px-4 lg:hidden">
        {(['edit', 'preview'] as const).map((p) =>
        <button
          key={p}
          type="button"
          onClick={() => setMobilePane(p)}
          className={cn('-mb-px border-b-2 px-3 py-2 text-[13px] font-medium capitalize', mobilePane === p ? 'border-ink text-ink' : 'border-transparent text-ink-500')}>
          
            {p === 'edit' ? 'Sections' : 'Preview'}
          </button>
        )}
      </div>

      <div className="flex min-h-0 flex-1">
        <aside className={cn('relative w-full shrink-0 overflow-y-auto overflow-x-hidden border-r border-line bg-white lg:block lg:w-[340px]', mobilePane === 'edit' ? 'block' : 'hidden')}>
          <AnimatePresence mode="wait" initial={false}>
            {editing ?
            <motion.div key="editor" initial={{ x: 24, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: 24, opacity: 0 }} transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}>
                <BlockEditor block={editing} onChange={updateBlock} onBack={() => setEditingId(null)} />
              </motion.div> :

            <motion.div key="list" initial={{ x: -24, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -24, opacity: 0 }} transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}>
                <BlockList
                blocks={blocks}
                selectedId={editingId}
                onReorder={setBlocks}
                onEdit={setEditingId}
                onToggle={(id) => setBlocks(blocks.map((b) => b.id === id ? { ...b, visible: !b.visible } as PageBlock : b))}
                onDuplicate={(id) => {
                  const i = blocks.findIndex((b) => b.id === id);
                  const copy = { ...blocks[i], id: `${id}-copy-${Date.now()}` } as PageBlock;
                  setBlocks([...blocks.slice(0, i + 1), copy, ...blocks.slice(i + 1)]);
                }}
                onDelete={(id) => {
                  setBlocks(blocks.filter((b) => b.id !== id));
                  toast('Section removed', { description: 'Discard changes to bring it back.' });
                }}
                onAdd={addBlock} />
              
              </motion.div>
            }
          </AnimatePresence>
        </aside>

        <div className={cn('min-w-0 flex-1 overflow-y-auto bg-[#EEEDE9] p-4 lg:block lg:p-8', mobilePane === 'preview' ? 'block' : 'hidden')}>
          <PagePreview
            blocks={blocks}
            device={device}
            path={page.path}
            selectedId={editingId}
            onSelect={(id) => {
              setEditingId(id);
              setMobilePane('edit');
            }} />
          
        </div>
      </div>
    </div>);

}