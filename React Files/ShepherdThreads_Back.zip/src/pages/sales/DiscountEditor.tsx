import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';
import { PercentIcon, DollarSignIcon, ShuffleIcon, TicketPercentIcon, TruckIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Panel } from '../../components/ui/Panel';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Field } from '../../components/ui/Field';
import { TextInput } from '../../components/ui/TextInput';
import { RadioGroup } from '../../components/ui/RadioGroup';
import { Checkbox } from '../../components/ui/Checkbox';
import { EmptyState } from '../../components/ui/EmptyState';
import { discounts } from '../../data/discounts';
import { collections } from '../../data/collections';
import { products } from '../../data/products';
import type { DiscountType } from '../../types/sales';
import { cn } from '../../utils/cn';
import { formatCurrency, formatDate, formatNumber } from '../../utils/format';
import { discountStatusMeta, discountValueLabel } from '../../utils/status';

const typeOptions: {value: DiscountType;label: string;icon: typeof PercentIcon;}[] = [
{ value: 'percent', label: 'Percentage', icon: PercentIcon },
{ value: 'fixed', label: 'Fixed amount', icon: DollarSignIcon },
{ value: 'free_shipping', label: 'Free shipping', icon: TruckIcon }];


export function DiscountEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = id === 'new';
  const source = discounts.find((d) => d.id === id);

  const [code, setCode] = useState(source?.code ?? '');
  const [type, setType] = useState<DiscountType>(source?.type ?? 'percent');
  const [value, setValue] = useState(source?.value ?? 10);
  const [appliesTo, setAppliesTo] = useState(source && source.appliesTo !== 'All products' ? 'collections' : 'all');
  const [pickedCollections, setPickedCollections] = useState<string[]>(
    source ? collections.filter((c) => c.name === source.appliesTo).map((c) => c.id) : []
  );
  const [pickedProducts, setPickedProducts] = useState<string[]>([]);
  const [requirement, setRequirement] = useState(source?.minSpend ? 'amount' : 'none');
  const [minSpend, setMinSpend] = useState(source?.minSpend ?? 50);
  const [limitTotal, setLimitTotal] = useState(!!source?.usageLimit);
  const [usageLimit, setUsageLimit] = useState(source?.usageLimit ?? 100);
  const [oncePer, setOncePer] = useState(source?.oncePerCustomer ?? true);
  const [startsAt, setStartsAt] = useState(source?.startsAt ?? '2026-11-01');
  const [hasEnd, setHasEnd] = useState(!!source?.endsAt);
  const [endsAt, setEndsAt] = useState(source?.endsAt ?? '2026-11-30');
  const [codeError, setCodeError] = useState('');

  if (!isNew && !source) {
    return (
      <PageContainer>
        <EmptyState icon={TicketPercentIcon} title="Discount not found" description="It may have been deleted." action={<Button onClick={() => navigate('/discounts')}>Back to discounts</Button>} />
      </PageContainer>);

  }

  const generate = () => {
    const words = ['FAITH', 'GRACE', 'HOPE', 'SHEPHERD', 'PSALM', 'HARVEST'];
    setCode(`${words[Math.floor(Math.random() * words.length)]}${Math.floor(10 + Math.random() * 40)}`);
    setCodeError('');
  };

  const scopeLabel =
  appliesTo === 'all' ?
  'all products' :
  appliesTo === 'collections' ?
  `${pickedCollections.length} collection${pickedCollections.length === 1 ? '' : 's'}` :
  `${pickedProducts.length} product${pickedProducts.length === 1 ? '' : 's'}`;

  const summary = [
  `${discountValueLabel(type, value)} ${type === 'free_shipping' ? 'on' : 'on'} ${scopeLabel}`,
  requirement === 'amount' ? `Minimum purchase of ${formatCurrency(minSpend, false)}` : 'No minimum purchase',
  limitTotal ? `Limited to ${formatNumber(usageLimit)} total uses` : 'Unlimited uses',
  oncePer ? 'One use per customer' : 'Customers can reuse',
  `Active from ${formatDate(startsAt)}${hasEnd ? ` to ${formatDate(endsAt)}` : ''}`];


  const save = () => {
    if (!code.trim()) {
      setCodeError('Enter or generate a code');
      return;
    }
    toast.success(isNew ? `${code} created` : `${code} saved`);
    navigate('/discounts');
  };

  const toggleIn = (list: string[], id: string) => list.includes(id) ? list.filter((x) => x !== id) : [...list, id];

  return (
    <PageContainer narrow>
      <PageHeader
        breadcrumbs={[{ label: 'Discounts', to: '/discounts' }, { label: isNew ? 'New discount' : source!.code }]}
        title={isNew ? 'Create discount' : source!.code}
        meta={source && <Badge tone={discountStatusMeta[source.status].tone}>{discountStatusMeta[source.status].label}</Badge>}
        actions={
        <>
            <Button onClick={() => navigate('/discounts')}>Cancel</Button>
            <Button variant="primary" onClick={save}>
              {isNew ? 'Create discount' : 'Save'}
            </Button>
          </>
        } />
      

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0 space-y-6">
          <Panel title="Code & value">
            <div className="space-y-5">
              <Field label="Discount code" htmlFor="d-code" error={codeError} hint="Customers enter this at checkout.">
                <div className="flex gap-2">
                  <TextInput
                    id="d-code"
                    value={code}
                    invalid={!!codeError}
                    placeholder="e.g. HARVEST10"
                    onChange={(e) => {
                      setCode(e.target.value.toUpperCase().replace(/\s/g, ''));
                      setCodeError('');
                    }}
                    className="font-mono tracking-wide" />
                  
                  <Button icon={ShuffleIcon} onClick={generate}>
                    Generate
                  </Button>
                </div>
              </Field>
              <div>
                <p className="mb-2 text-[13px] font-medium text-ink">Type</p>
                <div role="radiogroup" aria-label="Discount type" className="grid gap-2 sm:grid-cols-3">
                  {typeOptions.map((o) => {
                    const Icon = o.icon;
                    const on = type === o.value;
                    return (
                      <button
                        key={o.value}
                        type="button"
                        role="radio"
                        aria-checked={on}
                        onClick={() => setType(o.value)}
                        className={cn(
                          'flex items-center gap-2.5 rounded-md border px-3 py-2.5 text-left text-sm transition-colors duration-150',
                          on ? 'border-ink bg-cream text-ink ring-1 ring-ink' : 'border-line-strong text-ink-600 hover:border-stone'
                        )}>
                        
                        <Icon className={cn('h-4 w-4', on ? 'text-brass-text' : 'text-stone')} />
                        {o.label}
                      </button>);

                  })}
                </div>
              </div>
              {type !== 'free_shipping' &&
              <Field label={type === 'percent' ? 'Percentage off' : 'Amount off'} htmlFor="d-value" className="max-w-[200px]">
                  <TextInput
                  id="d-value"
                  type="number"
                  min={0}
                  value={value}
                  leading={type === 'fixed' ? '$' : undefined}
                  trailing={type === 'percent' ? '%' : undefined}
                  onChange={(e) => setValue(Number(e.target.value))} />
                
                </Field>
              }
            </div>
          </Panel>

          <Panel title="Applies to">
            <RadioGroup
              name="applies"
              ariaLabel="Applies to"
              value={appliesTo}
              onChange={setAppliesTo}
              options={[
              { value: 'all', label: 'All products' },
              { value: 'collections', label: 'Specific collections' },
              { value: 'products', label: 'Specific products' }]
              } />
            
            {appliesTo === 'collections' &&
            <div className="mt-4 grid gap-2 rounded-md border border-line bg-canvas p-3 sm:grid-cols-2">
                {collections.map((c) =>
              <Checkbox key={c.id} label={c.name} checked={pickedCollections.includes(c.id)} onChange={() => setPickedCollections(toggleIn(pickedCollections, c.id))} />
              )}
              </div>
            }
            {appliesTo === 'products' &&
            <div className="mt-4 grid gap-2 rounded-md border border-line bg-canvas p-3 sm:grid-cols-2">
                {products.filter((p) => p.status !== 'archived').map((p) =>
              <Checkbox key={p.id} label={p.name} checked={pickedProducts.includes(p.id)} onChange={() => setPickedProducts(toggleIn(pickedProducts, p.id))} />
              )}
              </div>
            }
          </Panel>

          <Panel title="Minimum requirements">
            <RadioGroup
              name="req"
              ariaLabel="Minimum requirements"
              value={requirement}
              onChange={setRequirement}
              options={[
              { value: 'none', label: 'No minimum' },
              { value: 'amount', label: 'Minimum purchase amount' }]
              } />
            
            {requirement === 'amount' &&
            <div className="mt-3 max-w-[200px] pl-6">
                <TextInput type="number" aria-label="Minimum purchase amount" leading="$" value={minSpend} onChange={(e) => setMinSpend(Number(e.target.value))} />
              </div>
            }
          </Panel>

          <Panel title="Usage limits">
            <div className="space-y-3">
              <Checkbox label="Limit total number of uses" checked={limitTotal} onChange={(e) => setLimitTotal(e.target.checked)} />
              {limitTotal &&
              <div className="max-w-[200px] pl-6">
                  <TextInput type="number" aria-label="Usage limit" value={usageLimit} trailing="uses" onChange={(e) => setUsageLimit(Number(e.target.value))} />
                </div>
              }
              <div>
                <Checkbox label="Limit to one use per customer" checked={oncePer} onChange={(e) => setOncePer(e.target.checked)} />
              </div>
            </div>
          </Panel>

          <Panel title="Active dates">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Start date" htmlFor="d-start">
                <TextInput id="d-start" type="date" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} />
              </Field>
              {hasEnd &&
              <Field label="End date" htmlFor="d-end">
                  <TextInput id="d-end" type="date" value={endsAt} min={startsAt} onChange={(e) => setEndsAt(e.target.value)} />
                </Field>
              }
            </div>
            <div className="mt-4">
              <Checkbox label="Set an end date" checked={hasEnd} onChange={(e) => setHasEnd(e.target.checked)} />
            </div>
          </Panel>
        </div>

        <aside className="lg:sticky lg:top-6 lg:self-start">
          <Panel title="Summary">
            <p className="font-mono text-lg font-semibold tracking-wide text-ink">{code || 'NO CODE YET'}</p>
            <ul className="mt-3 space-y-2">
              {summary.map((s) =>
              <li key={s} className="flex gap-2 text-[13px] text-ink-600">
                  <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-ink-500" />
                  {s}
                </li>
              )}
            </ul>
            {source &&
            <dl className="mt-5 space-y-2 border-t border-line pt-4 text-[13px]">
                <div className="flex justify-between">
                  <dt className="text-ink-500">Times used</dt>
                  <dd className="font-medium tabular-nums text-ink">{formatNumber(source.uses)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-ink-500">Est. revenue driven</dt>
                  <dd className="font-medium tabular-nums text-ink">{formatCurrency(source.uses * 74, false)}</dd>
                </div>
              </dl>
            }
          </Panel>
        </aside>
      </div>
    </PageContainer>);

}