import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { DownloadIcon, UsersIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Tabs } from '../../components/ui/Tabs';
import { SearchInput } from '../../components/ui/SearchInput';
import { Select } from '../../components/ui/Select';
import { Avatar } from '../../components/ui/Avatar';
import { EmptyState } from '../../components/ui/EmptyState';
import { Pagination } from '../../components/ui/Pagination';
import { customers } from '../../data/customers';
import type { Customer } from '../../types/sales';
import { cn } from '../../utils/cn';
import { downloadCsv } from '../../utils/csv';
import { formatCurrency, formatDate } from '../../utils/format';
import { rowClass, tableClass, tdClass, thClass } from '../../utils/styles';

const segments: Record<string, (c: Customer) => boolean> = {
  all: () => true,
  subscribed: (c) => c.marketingOptIn,
  vip: (c) => c.tags.includes('VIP'),
  new: (c) => c.orders <= 1,
  wholesale: (c) => c.tags.includes('Wholesale lead')
};

export function Customers() {
  const navigate = useNavigate();
  const [segment, setSegment] = useState('all');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState('spent');

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    const list = customers.filter((c) => segments[segment](c) && (!q || c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q)));
    if (sort === 'spent') return [...list].sort((a, b) => b.spent - a.spent);
    if (sort === 'orders') return [...list].sort((a, b) => b.orders - a.orders);
    return [...list].sort((a, b) => b.joined.localeCompare(a.joined));
  }, [segment, query, sort]);

  return (
    <PageContainer>
      <PageHeader
        title="Customers"
        description={`${customers.length} customers · ${customers.filter((c) => c.marketingOptIn).length} subscribed to email`}
        actions={
        <Button
          icon={DownloadIcon}
          onClick={() => {
            downloadCsv('customers.csv', filtered.map((c) => ({ Name: c.name, Email: c.email, Orders: c.orders, Spent: c.spent, Joined: c.joined, Subscribed: c.marketingOptIn ? 'Yes' : 'No' })));
            toast.success(`Exported ${filtered.length} customers`);
          }}>
          
            Export
          </Button>
        } />
      

      <section className="rounded-lg border border-line bg-white">
        <div className="px-4 pt-3">
          <Tabs
            value={segment}
            onChange={setSegment}
            tabs={[
            { id: 'all', label: 'All', count: customers.length },
            { id: 'subscribed', label: 'Email subscribers', count: customers.filter(segments.subscribed).length },
            { id: 'vip', label: 'VIP', count: customers.filter(segments.vip).length },
            { id: 'new', label: 'First-time', count: customers.filter(segments.new).length },
            { id: 'wholesale', label: 'Wholesale leads', count: customers.filter(segments.wholesale).length }]
            } />
          
        </div>
        <div className="flex flex-col gap-2 p-4 sm:flex-row">
          <SearchInput value={query} onChange={setQuery} placeholder="Search name or email" className="sm:w-72" />
          <Select
            aria-label="Sort customers"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            options={[
            { value: 'spent', label: 'Sort: Total spent' },
            { value: 'orders', label: 'Sort: Most orders' },
            { value: 'joined', label: 'Sort: Newest' }]
            } />
          
        </div>
        {filtered.length === 0 ?
        <EmptyState icon={UsersIcon} title="No customers found" description="Try a different search or segment." /> :

        <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Customer</th>
                  <th className={cn(thClass, 'hidden md:table-cell')}>Location</th>
                  <th className={cn(thClass, 'text-right')}>Orders</th>
                  <th className={cn(thClass, 'text-right')}>Total spent</th>
                  <th className={cn(thClass, 'hidden lg:table-cell')}>Joined</th>
                  <th className={thClass}>Email marketing</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((c) =>
              <tr key={c.id} onClick={() => navigate(`/customers/${c.id}`)} className={rowClass}>
                    <td className={tdClass}>
                      <div className="flex items-center gap-3">
                        <Avatar name={c.name} size="sm" />
                        <div className="min-w-0">
                          <p className="flex items-center gap-2 truncate font-medium text-ink">
                            {c.name}
                            {c.tags.includes('VIP') && <Badge tone="brass">VIP</Badge>}
                          </p>
                          <p className="truncate text-xs text-ink-500">{c.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className={cn(tdClass, 'hidden whitespace-nowrap text-ink-600 md:table-cell')}>{c.location}</td>
                    <td className={cn(tdClass, 'text-right tabular-nums text-ink')}>{c.orders}</td>
                    <td className={cn(tdClass, 'text-right font-medium tabular-nums text-ink')}>{formatCurrency(c.spent)}</td>
                    <td className={cn(tdClass, 'hidden whitespace-nowrap text-ink-600 lg:table-cell')}>{formatDate(c.joined)}</td>
                    <td className={tdClass}>
                      {c.marketingOptIn ? <Badge tone="success">Subscribed</Badge> : <Badge>Not subscribed</Badge>}
                    </td>
                  </tr>
              )}
              </tbody>
            </table>
          </div>
        }
        <Pagination showing={filtered.length} total={filtered.length} label="customers" />
      </section>
    </PageContainer>);

}