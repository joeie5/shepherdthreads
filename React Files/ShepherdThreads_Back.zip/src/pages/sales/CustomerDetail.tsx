import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';
import { MailIcon, MapPinIcon, PhoneIcon, PlusIcon, UsersIcon, XIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Panel } from '../../components/ui/Panel';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Toggle } from '../../components/ui/Toggle';
import { TextArea } from '../../components/ui/TextArea';
import { EmptyState } from '../../components/ui/EmptyState';
import { OrdersTable } from '../../components/orders/OrdersTable';
import { customers } from '../../data/customers';
import { orders } from '../../data/orders';
import { cn } from '../../utils/cn';
import { formatCurrency, formatDate } from '../../utils/format';

export function CustomerDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const customer = customers.find((c) => c.id === id);
  const [emailOpt, setEmailOpt] = useState(customer?.marketingOptIn ?? false);
  const [smsOpt, setSmsOpt] = useState(customer?.smsOptIn ?? false);
  const [note, setNote] = useState(customer?.note ?? '');
  const [savedNote, setSavedNote] = useState(customer?.note ?? '');
  const [tags, setTags] = useState<string[]>(customer?.tags ?? []);
  const [newTag, setNewTag] = useState('');

  if (!customer) {
    return (
      <PageContainer>
        <EmptyState icon={UsersIcon} title="Customer not found" description="They may have been removed." action={<Button onClick={() => navigate('/customers')}>Back to customers</Button>} />
      </PageContainer>);

  }

  const history = orders.filter((o) => o.customerId === customer.id);
  const avg = customer.orders ? customer.spent / customer.orders : 0;
  const stats = [
  { label: 'Total spent', value: formatCurrency(customer.spent) },
  { label: 'Orders', value: String(customer.orders) },
  { label: 'Average order', value: formatCurrency(avg) },
  { label: 'Last order', value: formatDate(customer.lastOrder) }];


  return (
    <PageContainer narrow>
      <PageHeader
        breadcrumbs={[{ label: 'Customers', to: '/customers' }, { label: customer.name }]}
        title={customer.name}
        meta={tags.includes('VIP') && <Badge tone="brass">VIP</Badge>}
        description={`Customer since ${formatDate(customer.joined, 'MMMM yyyy')} · ${customer.location}`}
        actions={
        <Button icon={MailIcon} onClick={() => window.location.href = `mailto:${customer.email}`}>
            Email customer
          </Button>
        } />
      

      <section className="mb-6 grid grid-cols-2 overflow-hidden rounded-lg border border-line bg-white sm:grid-cols-4">
        {stats.map((s, i) =>
        <div key={s.label} className={cn('border-line p-4', i % 2 === 1 && 'border-l', i >= 2 && 'border-t sm:border-t-0', i === 2 && 'sm:border-l')}>
            <p className="text-xs text-ink-500">{s.label}</p>
            <p className="mt-1 text-lg font-semibold tabular-nums text-ink">{s.value}</p>
          </div>
        )}
      </section>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0 space-y-6">
          <Panel title="Order history" description={`${history.length} recent orders shown`} padded={false}>
            {history.length ?
            <OrdersTable orders={history} compact /> :

            <p className="px-5 py-8 text-center text-[13px] text-ink-500">No orders in the last 90 days.</p>
            }
          </Panel>

          <Panel title="Notes" description="Private to your team.">
            <TextArea rows={4} value={note} aria-label="Customer notes" placeholder="Sizing preferences, church affiliation, wholesale details…" onChange={(e) => setNote(e.target.value)} />
            <div className="mt-3 flex justify-end">
              <Button
                variant="primary"
                size="sm"
                disabled={note === savedNote}
                onClick={() => {
                  setSavedNote(note);
                  toast.success('Note saved');
                }}>
                
                Save note
              </Button>
            </div>
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel title="Contact">
            <ul className="space-y-2.5 text-[13px]">
              <li className="flex items-center gap-2.5 text-ink">
                <MailIcon className="h-4 w-4 shrink-0 text-stone" />
                <a href={`mailto:${customer.email}`} className="truncate hover:underline">
                  {customer.email}
                </a>
              </li>
              <li className="flex items-center gap-2.5 text-ink">
                <PhoneIcon className="h-4 w-4 shrink-0 text-stone" />
                {customer.phone}
              </li>
              <li className="flex items-center gap-2.5 text-ink">
                <MapPinIcon className="h-4 w-4 shrink-0 text-stone" />
                {customer.location}
              </li>
            </ul>
          </Panel>

          <Panel title="Marketing">
            <div className="space-y-4">
              <Toggle
                label="Email"
                description={emailOpt ? 'Subscribed to newsletters and drops' : 'Not subscribed'}
                checked={emailOpt}
                onChange={(v) => {
                  setEmailOpt(v);
                  toast.success(v ? 'Subscribed to email' : 'Unsubscribed from email');
                }} />
              
              <Toggle
                label="SMS"
                description={smsOpt ? 'Receives text alerts' : 'Not subscribed'}
                checked={smsOpt}
                onChange={(v) => {
                  setSmsOpt(v);
                  toast.success(v ? 'Subscribed to SMS' : 'Unsubscribed from SMS');
                }} />
              
            </div>
          </Panel>

          <Panel title="Tags">
            <div className="flex flex-wrap gap-1.5">
              {tags.map((t) =>
              <span key={t} className="inline-flex items-center gap-1 rounded-full bg-black/[0.05] py-0.5 pl-2.5 pr-1 text-xs font-medium text-ink-600">
                  {t}
                  <button type="button" aria-label={`Remove tag ${t}`} onClick={() => setTags(tags.filter((x) => x !== t))} className="rounded-full p-0.5 hover:bg-black/10">
                    <XIcon className="h-3 w-3" />
                  </button>
                </span>
              )}
              {tags.length === 0 && <p className="text-[13px] text-ink-500">No tags yet.</p>}
            </div>
            <form
              className="mt-3 flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                const t = newTag.trim();
                if (t && !tags.includes(t)) setTags([...tags, t]);
                setNewTag('');
              }}>
              
              <input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="Add tag"
                aria-label="Add tag"
                className="h-8 min-w-0 flex-1 rounded-md border border-line-strong px-2.5 text-[13px] focus:border-ink focus:outline-none" />
              
              <Button size="sm" type="submit" icon={PlusIcon} aria-label="Add tag" />
            </form>
          </Panel>
        </div>
      </div>
    </PageContainer>);

}