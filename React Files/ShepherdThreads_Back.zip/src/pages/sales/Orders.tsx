import React, { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { toast } from 'sonner';
import { DownloadIcon, ShoppingBagIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Button } from '../../components/ui/Button';
import { Tabs } from '../../components/ui/Tabs';
import { SearchInput } from '../../components/ui/SearchInput';
import { Select } from '../../components/ui/Select';
import { EmptyState } from '../../components/ui/EmptyState';
import { Pagination } from '../../components/ui/Pagination';
import { OrdersTable } from '../../components/orders/OrdersTable';
import { orders as initial } from '../../data/orders';
import type { Order } from '../../types/sales';
import { downloadCsv } from '../../utils/csv';

const tabFilter: Record<string, (o: Order) => boolean> = {
  all: () => true,
  unfulfilled: (o) => o.fulfillment === 'unfulfilled' && o.payment === 'paid',
  payment: (o) => o.payment === 'pending' || o.payment === 'failed',
  transit: (o) => o.fulfillment === 'processing' || o.fulfillment === 'shipped',
  delivered: (o) => o.fulfillment === 'delivered'
};

const dateCutoff: Record<string, string> = {
  any: '0000',
  today: '2026-11-01',
  '7d': '2026-10-25',
  '30d': '2026-10-02'
};

export function Orders() {
  const [params] = useSearchParams();
  const [items, setItems] = useState<Order[]>(initial);
  const initialTab = params.get('status') ?? 'all';
  const [tab, setTab] = useState(initialTab in tabFilter ? initialTab : 'all');
  const [query, setQuery] = useState('');
  const [channel, setChannel] = useState('all');
  const [range, setRange] = useState('any');
  const [selected, setSelected] = useState<string[]>([]);

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    return items.filter(
      (o) =>
      tabFilter[tab](o) && (
      channel === 'all' || o.channel === channel) &&
      o.date >= dateCutoff[range] && (
      !q || o.number.toLowerCase().includes(q) || o.customerName.toLowerCase().includes(q) || o.customerEmail.toLowerCase().includes(q))
    );
  }, [items, tab, channel, range, query]);

  const count = (key: string) => items.filter(tabFilter[key]).length;

  const markFulfilled = () => {
    setItems((prev) => prev.map((o) => selected.includes(o.id) && o.fulfillment === 'unfulfilled' ? { ...o, fulfillment: 'processing' } : o));
    toast.success(`${selected.length} order${selected.length > 1 ? 's' : ''} moved to processing`, { description: 'Customers will get a shipping email once tracking is added.' });
    setSelected([]);
  };

  const exportOrders = (rows: Order[]) => {
    downloadCsv('orders.csv', rows.map((o) => ({ Order: o.number, Date: o.date, Customer: o.customerName, Total: o.total, Payment: o.payment, Fulfillment: o.fulfillment })));
    toast.success(`Exported ${rows.length} orders`);
  };

  return (
    <PageContainer>
      <PageHeader
        title="Orders"
        description="Orders from your web store, iOS, and Android apps."
        actions={
        <Button icon={DownloadIcon} onClick={() => exportOrders(filtered)}>
            Export
          </Button>
        } />
      

      <section className="rounded-lg border border-line bg-white">
        <div className="px-4 pt-3">
          <Tabs
            value={tab}
            onChange={(t) => {
              setTab(t);
              setSelected([]);
            }}
            tabs={[
            { id: 'all', label: 'All', count: count('all') },
            { id: 'unfulfilled', label: 'To fulfill', count: count('unfulfilled') },
            { id: 'payment', label: 'Payment issues', count: count('payment') },
            { id: 'transit', label: 'In progress', count: count('transit') },
            { id: 'delivered', label: 'Delivered', count: count('delivered') }]
            } />
          
        </div>
        <div className="relative">
          <div className="flex flex-col gap-2 p-4 sm:flex-row">
            <SearchInput value={query} onChange={setQuery} placeholder="Search order #, name, or email" className="sm:w-80" />
            <div className="flex gap-2">
              <Select
                aria-label="Date range"
                value={range}
                onChange={(e) => setRange(e.target.value)}
                options={[
                { value: 'any', label: 'Any date' },
                { value: 'today', label: 'Today' },
                { value: '7d', label: 'Last 7 days' },
                { value: '30d', label: 'Last 30 days' }]
                } />
              
              <Select
                aria-label="Channel"
                value={channel}
                onChange={(e) => setChannel(e.target.value)}
                options={[
                { value: 'all', label: 'All channels' },
                { value: 'Web', label: 'Web' },
                { value: 'iOS', label: 'iOS app' },
                { value: 'Android', label: 'Android app' }]
                } />
              
            </div>
          </div>
          <AnimatePresence>
            {selected.length > 0 &&
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.16, ease: [0.23, 1, 0.32, 1] }}
              className="absolute inset-x-4 top-4 z-10 flex h-9 items-center gap-1 rounded-md bg-ink pl-3 pr-1 text-white">
              
                <span className="mr-auto text-[13px] font-medium tabular-nums">{selected.length} selected</span>
                <button type="button" onClick={markFulfilled} className="h-7 rounded px-2.5 text-[13px] text-white/90 hover:bg-white/10">
                  Start fulfilling
                </button>
                <button type="button" onClick={() => toast.success('Packing slips ready to print')} className="hidden h-7 rounded px-2.5 text-[13px] text-white/90 hover:bg-white/10 sm:block">
                  Packing slips
                </button>
                <button type="button" onClick={() => exportOrders(items.filter((o) => selected.includes(o.id)))} className="h-7 rounded px-2.5 text-[13px] text-white/90 hover:bg-white/10">
                  Export
                </button>
                <button type="button" onClick={() => setSelected([])} className="h-7 rounded px-2.5 text-[13px] text-white/60 hover:bg-white/10 hover:text-white">
                  Clear
                </button>
              </motion.div>
            }
          </AnimatePresence>
        </div>
        {filtered.length === 0 ?
        <EmptyState icon={ShoppingBagIcon} title="No orders found" description="Try another tab, date range, or search term." /> :

        <OrdersTable orders={filtered} selected={selected} onSelectedChange={setSelected} />
        }
        <Pagination showing={filtered.length} total={filtered.length} label="orders" />
      </section>
    </PageContainer>);

}