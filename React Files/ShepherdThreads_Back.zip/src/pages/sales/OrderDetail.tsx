import React, { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';
import { CopyIcon, EllipsisIcon, MailIcon, PhoneIcon, PrinterIcon, RotateCcwIcon, ShoppingBagIcon, XIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Panel } from '../../components/ui/Panel';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Field } from '../../components/ui/Field';
import { Select } from '../../components/ui/Select';
import { TextInput } from '../../components/ui/TextInput';
import { TextArea } from '../../components/ui/TextArea';
import { Checkbox } from '../../components/ui/Checkbox';
import { Menu } from '../../components/ui/Menu';
import { Avatar } from '../../components/ui/Avatar';
import { EmptyState } from '../../components/ui/EmptyState';
import { RefundModal } from '../../components/orders/RefundModal';
import { orders } from '../../data/orders';
import { customers } from '../../data/customers';
import type { FulfillmentStatus, Order, OrderNote } from '../../types/sales';
import { formatCurrency, formatDateTime } from '../../utils/format';
import { fulfillmentMeta, paymentMeta } from '../../utils/status';

export function OrderDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const source = orders.find((o) => o.id === id);
  const [order, setOrder] = useState<Order | undefined>(source);
  const [status, setStatus] = useState<FulfillmentStatus>(source?.fulfillment ?? 'unfulfilled');
  const [carrier, setCarrier] = useState(source?.carrier ?? 'UPS');
  const [tracking, setTracking] = useState(source?.tracking ?? '');
  const [notify, setNotify] = useState(true);
  const [note, setNote] = useState('');
  const [refundOpen, setRefundOpen] = useState(false);
  const [refunded, setRefunded] = useState(source?.payment === 'refunded' ? source.total : source?.payment === 'partially_refunded' ? 38 : 0);

  if (!order) {
    return (
      <PageContainer>
        <EmptyState icon={ShoppingBagIcon} title="Order not found" description="Check the order number and try again." action={<Button onClick={() => navigate('/orders')}>Back to orders</Button>} />
      </PageContainer>);

  }

  const customer = customers.find((c) => c.id === order.customerId);
  const pay = paymentMeta[order.payment];
  const ful = fulfillmentMeta[order.fulfillment];
  const fulfillmentChanged = status !== order.fulfillment || tracking !== (order.tracking ?? '') || carrier !== (order.carrier ?? 'UPS');

  const saveFulfillment = () => {
    if (status === 'shipped' && !tracking.trim()) {
      toast.error('Add a tracking number before marking as shipped');
      return;
    }
    setOrder({ ...order, fulfillment: status, tracking: tracking || undefined, carrier });
    toast.success(`Order marked as ${fulfillmentMeta[status].label.toLowerCase()}`, {
      description: notify ? `${order.customerName} was emailed an update.` : undefined
    });
  };

  const addNote = () => {
    if (!note.trim()) return;
    const n: OrderNote = { author: 'Hannah Brooks', text: note.trim(), date: '2026-11-01T10:05:00' };
    setOrder({ ...order, notes: [n, ...order.notes] });
    setNote('');
  };

  const a = order.address;
  const addressText = [a.name, a.line1, a.line2, `${a.city}, ${a.state} ${a.zip}`, a.country].filter(Boolean).join('\n');

  return (
    <PageContainer narrow>
      <PageHeader
        breadcrumbs={[{ label: 'Orders', to: '/orders' }, { label: order.number }]}
        title={order.number}
        meta={
        <div className="flex gap-1.5">
            <Badge tone={pay.tone} dot>
              {pay.label}
            </Badge>
            <Badge tone={ful.tone} dot>
              {ful.label}
            </Badge>
          </div>
        }
        description={`${formatDateTime(order.date)} · via ${order.channel === 'Web' ? 'web store' : `${order.channel} app`}`}
        actions={
        <>
            <Button icon={PrinterIcon} onClick={() => toast.success('Packing slip sent to printer')}>
              Print
            </Button>
            <Button
            variant="danger"
            icon={RotateCcwIcon}
            disabled={order.payment === 'refunded' || order.payment === 'failed' || order.payment === 'pending'}
            onClick={() => setRefundOpen(true)}>
            
              Refund
            </Button>
            <Menu
            ariaLabel="More order actions"
            triggerClassName="flex h-9 w-9 items-center justify-center rounded-md border border-line-strong bg-white text-ink-600 hover:bg-canvas"
            trigger={<EllipsisIcon className="h-4 w-4" />}
            items={[
            { label: 'Duplicate order', icon: CopyIcon, onClick: () => toast.success('Draft order created') },
            { label: 'Resend confirmation', icon: MailIcon, onClick: () => toast.success('Confirmation email resent') },
            {
              label: 'Cancel order',
              icon: XIcon,
              danger: true,
              divider: true,
              onClick: () => {
                setOrder({ ...order, fulfillment: 'cancelled' });
                setStatus('cancelled');
                toast.success('Order cancelled');
              }
            }]
            } />
          
          </>
        } />
      

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0 space-y-6">
          <Panel title={`Items · ${order.items.reduce((s, i) => s + i.qty, 0)}`} padded={false}>
            <ul>
              {order.items.map((item) =>
              <li key={item.sku} className="flex items-center gap-4 border-b border-line px-5 py-3.5">
                  <img src={item.image} alt="" className="h-14 w-14 shrink-0 rounded-md border border-line object-cover" />
                  <div className="min-w-0 flex-1">
                    <Link to={`/products/${item.productId}`} className="block truncate text-sm font-medium text-ink hover:underline">
                      {item.name}
                    </Link>
                    <p className="text-[13px] text-ink-600">{item.variant}</p>
                    <p className="font-mono text-xs text-ink-500">{item.sku}</p>
                  </div>
                  <p className="whitespace-nowrap text-[13px] tabular-nums text-ink-600">
                    {formatCurrency(item.price)} × {item.qty}
                  </p>
                  <p className="w-20 text-right text-sm font-medium tabular-nums text-ink">{formatCurrency(item.price * item.qty)}</p>
                </li>
              )}
            </ul>
            <div className="space-y-4 p-5">
              <p className="text-sm font-semibold text-ink">Fulfillment</p>
              <div className="grid gap-4 sm:grid-cols-3">
                <Field label="Status" htmlFor="ful-status">
                  <Select
                    id="ful-status"
                    value={status}
                    onChange={(e) => setStatus(e.target.value as FulfillmentStatus)}
                    options={(Object.keys(fulfillmentMeta) as FulfillmentStatus[]).map((s) => ({ value: s, label: fulfillmentMeta[s].label }))} />
                  
                </Field>
                <Field label="Carrier" htmlFor="ful-carrier">
                  <Select
                    id="ful-carrier"
                    value={carrier}
                    onChange={(e) => setCarrier(e.target.value)}
                    options={['UPS', 'USPS', 'FedEx', 'DHL'].map((c) => ({ value: c, label: c }))} />
                  
                </Field>
                <Field label="Tracking number" htmlFor="ful-tracking">
                  <TextInput id="ful-tracking" value={tracking} placeholder="e.g. 1Z84F2E1…" onChange={(e) => setTracking(e.target.value)} className="font-mono text-[13px]" />
                </Field>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <Checkbox label="Email customer about this update" checked={notify} onChange={(e) => setNotify(e.target.checked)} />
                <Button variant="primary" disabled={!fulfillmentChanged} onClick={saveFulfillment}>
                  Update fulfillment
                </Button>
              </div>
            </div>
          </Panel>

          <Panel title="Payment">
            <dl className="space-y-2 text-[13px]">
              <div className="flex justify-between">
                <dt className="text-ink-600">Subtotal</dt>
                <dd className="tabular-nums text-ink">{formatCurrency(order.subtotal)}</dd>
              </div>
              {order.discount > 0 &&
              <div className="flex justify-between">
                  <dt className="text-ink-600">
                    Discount <span className="ml-1 rounded bg-brass-soft px-1.5 py-0.5 font-mono text-[11px] text-brass-text">{order.discountCode}</span>
                  </dt>
                  <dd className="tabular-nums text-ink">−{formatCurrency(order.discount)}</dd>
                </div>
              }
              <div className="flex justify-between">
                <dt className="text-ink-600">Shipping · {order.shippingMethod}</dt>
                <dd className="tabular-nums text-ink">{order.shipping ? formatCurrency(order.shipping) : 'Free'}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-ink-600">Tax</dt>
                <dd className="tabular-nums text-ink">{formatCurrency(order.tax)}</dd>
              </div>
              <div className="flex justify-between border-t border-line pt-2.5 text-sm font-semibold">
                <dt className="text-ink">Total</dt>
                <dd className="tabular-nums text-ink">{formatCurrency(order.total)}</dd>
              </div>
              {refunded > 0 &&
              <div className="flex justify-between text-danger">
                  <dt>Refunded</dt>
                  <dd className="tabular-nums">−{formatCurrency(refunded)}</dd>
                </div>
              }
              <div className="flex justify-between border-t border-line pt-2.5">
                <dt className="text-ink-600">Payment method</dt>
                <dd className="text-right text-ink">{order.paymentMethod}</dd>
              </div>
            </dl>
          </Panel>

          <Panel title="Internal notes" description="Only staff can see these.">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-start">
              <TextArea rows={2} value={note} placeholder="Add a note for the team…" aria-label="New note" onChange={(e) => setNote(e.target.value)} className="flex-1" />
              <Button onClick={addNote} disabled={!note.trim()}>
                Add note
              </Button>
            </div>
            <ol className="mt-5 space-y-4 border-l border-line pl-5">
              {order.notes.map((n) =>
              <li key={n.date + n.text} className="relative">
                  <span className="absolute -left-[25px] top-1.5 h-2 w-2 rounded-full bg-brass" />
                  <p className="text-[13px] text-ink">{n.text}</p>
                  <p className="mt-0.5 text-xs text-ink-500">
                    {n.author} · {formatDateTime(n.date)}
                  </p>
                </li>
              )}
              {order.payment === 'paid' &&
              <li className="relative">
                  <span className="absolute -left-[25px] top-1.5 h-2 w-2 rounded-full bg-line-strong" />
                  <p className="text-[13px] text-ink-600">Payment of {formatCurrency(order.total)} captured</p>
                  <p className="mt-0.5 text-xs text-ink-500">{formatDateTime(order.date)}</p>
                </li>
              }
              <li className="relative">
                <span className="absolute -left-[25px] top-1.5 h-2 w-2 rounded-full bg-line-strong" />
                <p className="text-[13px] text-ink-600">Order placed by {order.customerName}</p>
                <p className="mt-0.5 text-xs text-ink-500">{formatDateTime(order.date)}</p>
              </li>
            </ol>
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel title="Customer">
            <Link to={`/customers/${order.customerId}`} className="group flex items-center gap-3">
              <Avatar name={order.customerName} />
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-ink group-hover:underline">{order.customerName}</p>
                <p className="text-xs text-ink-500">{customer ? `${customer.orders} orders · ${formatCurrency(customer.spent, false)} spent` : 'Guest'}</p>
              </div>
            </Link>
            <div className="mt-4 space-y-2 border-t border-line pt-4 text-[13px]">
              <a href={`mailto:${order.customerEmail}`} className="flex items-center gap-2 text-ink-600 hover:text-ink">
                <MailIcon className="h-3.5 w-3.5 text-stone" />
                <span className="truncate">{order.customerEmail}</span>
              </a>
              {customer &&
              <p className="flex items-center gap-2 text-ink-600">
                  <PhoneIcon className="h-3.5 w-3.5 text-stone" />
                  {customer.phone}
                </p>
              }
            </div>
          </Panel>

          <Panel
            title="Shipping address"
            actions={
            <Button
              variant="ghost"
              size="sm"
              icon={CopyIcon}
              aria-label="Copy address"
              onClick={() => {
                navigator.clipboard?.writeText(addressText);
                toast.success('Address copied');
              }} />

            }>
            
            <address className="whitespace-pre-line text-[13px] not-italic leading-relaxed text-ink">{addressText}</address>
            <p className="mt-3 border-t border-line pt-3 text-xs text-ink-500">{order.shippingMethod}</p>
            {order.tracking &&
            <p className="mt-1 text-xs text-ink-600">
                {order.carrier} · <span className="font-mono">{order.tracking}</span>
              </p>
            }
          </Panel>
        </div>
      </div>

      <RefundModal
        order={order}
        open={refundOpen}
        onClose={() => setRefundOpen(false)}
        onRefund={(amount, full) => {
          setRefunded((r) => r + amount);
          setOrder({ ...order, payment: full ? 'refunded' : 'partially_refunded' });
          setRefundOpen(false);
          toast.success(`Refunded ${formatCurrency(amount)} to ${order.customerName}`);
        }} />
      
    </PageContainer>);

}