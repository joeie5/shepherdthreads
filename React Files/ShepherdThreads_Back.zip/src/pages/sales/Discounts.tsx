import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { CopyIcon, PlusIcon, TicketPercentIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Tabs } from '../../components/ui/Tabs';
import { SearchInput } from '../../components/ui/SearchInput';
import { EmptyState } from '../../components/ui/EmptyState';
import { discounts } from '../../data/discounts';
import type { DiscountStatus } from '../../types/sales';
import { cn } from '../../utils/cn';
import { formatDate, formatNumber } from '../../utils/format';
import { discountStatusMeta, discountValueLabel } from '../../utils/status';
import { rowClass, tableClass, tdClass, thClass } from '../../utils/styles';

export function Discounts() {
  const navigate = useNavigate();
  const [tab, setTab] = useState('all');
  const [query, setQuery] = useState('');

  const filtered = useMemo(
    () => discounts.filter((d) => (tab === 'all' || d.status === tab) && d.code.toLowerCase().includes(query.toLowerCase())),
    [tab, query]
  );
  const count = (s: DiscountStatus) => discounts.filter((d) => d.status === s).length;

  return (
    <PageContainer>
      <PageHeader
        title="Discounts"
        description="Codes customers enter at checkout on web and in the app."
        actions={
        <Button variant="primary" icon={PlusIcon} onClick={() => navigate('/discounts/new')}>
            Create discount
          </Button>
        } />
      

      <section className="rounded-lg border border-line bg-white">
        <div className="flex flex-col gap-3 px-4 pt-3 md:flex-row md:items-end md:justify-between">
          <Tabs
            value={tab}
            onChange={setTab}
            className="border-b-0"
            tabs={[
            { id: 'all', label: 'All', count: discounts.length },
            { id: 'active', label: 'Active', count: count('active') },
            { id: 'scheduled', label: 'Scheduled', count: count('scheduled') },
            { id: 'expired', label: 'Expired', count: count('expired') }]
            } />
          
          <SearchInput value={query} onChange={setQuery} placeholder="Search codes" className="pb-3 md:w-60" />
        </div>
        {filtered.length === 0 ?
        <div className="border-t border-line">
            <EmptyState icon={TicketPercentIcon} title="No discounts here" description="Create a code to run your next promotion." />
          </div> :

        <div className="overflow-x-auto border-t border-line">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Code</th>
                  <th className={thClass}>Discount</th>
                  <th className={cn(thClass, 'hidden md:table-cell')}>Applies to</th>
                  <th className={thClass}>Usage</th>
                  <th className={cn(thClass, 'hidden lg:table-cell')}>Active dates</th>
                  <th className={thClass}>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((d) => {
                const meta = discountStatusMeta[d.status];
                const pct = d.usageLimit ? Math.min(100, d.uses / d.usageLimit * 100) : null;
                return (
                  <tr key={d.id} onClick={() => navigate(`/discounts/${d.id}`)} className={rowClass}>
                      <td className={tdClass}>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-[13px] font-semibold tracking-wide text-ink">{d.code}</span>
                          <button
                          type="button"
                          aria-label={`Copy ${d.code}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            navigator.clipboard?.writeText(d.code);
                            toast.success(`Copied ${d.code}`);
                          }}
                          className="rounded p-1 text-stone hover:bg-black/[0.05] hover:text-ink">
                          
                            <CopyIcon className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                      <td className={tdClass}>
                        <p className="text-ink">{discountValueLabel(d.type, d.value)}</p>
                        <p className="text-xs text-ink-500">{d.minSpend ? `Min. spend $${d.minSpend}` : 'No minimum'}</p>
                      </td>
                      <td className={cn(tdClass, 'hidden text-ink-600 md:table-cell')}>{d.appliesTo}</td>
                      <td className={cn(tdClass, 'min-w-[140px]')}>
                        <p className="text-[13px] tabular-nums text-ink">
                          {formatNumber(d.uses)}
                          <span className="text-ink-500">{d.usageLimit ? ` / ${formatNumber(d.usageLimit)}` : ' uses'}</span>
                        </p>
                        {pct !== null &&
                      <div className="mt-1.5 h-1 w-24 overflow-hidden rounded-full bg-line">
                            <div className={cn('h-full rounded-full', pct >= 90 ? 'bg-warning' : 'bg-ink')} style={{ width: `${pct}%` }} />
                          </div>
                      }
                      </td>
                      <td className={cn(tdClass, 'hidden whitespace-nowrap text-ink-600 lg:table-cell')}>
                        {formatDate(d.startsAt, 'MMM d')} – {d.endsAt ? formatDate(d.endsAt, 'MMM d, yyyy') : 'No end date'}
                      </td>
                      <td className={tdClass}>
                        <Badge tone={meta.tone} dot>
                          {meta.label}
                        </Badge>
                      </td>
                    </tr>);

              })}
              </tbody>
            </table>
          </div>
        }
      </section>
    </PageContainer>);

}