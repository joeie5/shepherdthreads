import React, { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Reorder } from 'framer-motion';
import { toast } from 'sonner';
import { LayersIcon, PlusIcon, RefreshCwIcon, Trash2Icon, XIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Panel } from '../../components/ui/Panel';
import { Button } from '../../components/ui/Button';
import { Field } from '../../components/ui/Field';
import { TextInput } from '../../components/ui/TextInput';
import { TextArea } from '../../components/ui/TextArea';
import { Select } from '../../components/ui/Select';
import { Toggle } from '../../components/ui/Toggle';
import { Drawer } from '../../components/ui/Drawer';
import { Checkbox } from '../../components/ui/Checkbox';
import { SearchInput } from '../../components/ui/SearchInput';
import { ImageDropzone } from '../../components/ui/ImageDropzone';
import { DragHandle } from '../../components/ui/DragHandle';
import { SortableItem } from '../../components/ui/SortableItem';
import { EmptyState } from '../../components/ui/EmptyState';
import { collections } from '../../data/collections';
import { products } from '../../data/products';
import type { Collection } from '../../types/catalog';
import { formatCurrency } from '../../utils/format';

const blank: Collection = { id: 'new', name: '', handle: '', description: '', image: '', productIds: [], visible: true, updatedAt: '2026-11-01' };

export function CollectionEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = id === 'new';
  const source = collections.find((c) => c.id === id);
  const [form, setForm] = useState<Collection>(source ?? blank);
  const [sort, setSort] = useState('manual');
  const [picker, setPicker] = useState(false);
  const [pickerQuery, setPickerQuery] = useState('');
  const [pending, setPending] = useState<string[]>([]);
  const [dirty, setDirty] = useState(false);

  const assigned = useMemo(() => {
    const list = form.productIds.map((pid) => products.find((p) => p.id === pid)).filter((p): p is (typeof products)[number] => !!p);
    if (sort === 'price-asc') return [...list].sort((a, b) => a.price - b.price);
    if (sort === 'best') return [...list].sort((a, b) => b.sales30d - a.sales30d);
    return list;
  }, [form.productIds, sort]);

  if (!isNew && !source) {
    return (
      <PageContainer>
        <EmptyState icon={LayersIcon} title="Collection not found" description="It may have been deleted." action={<Button onClick={() => navigate('/collections')}>Back to collections</Button>} />
      </PageContainer>);

  }

  const patch = (p: Partial<Collection>) => {
    setForm((f) => ({ ...f, ...p }));
    setDirty(true);
  };

  const openPicker = () => {
    setPending(form.productIds);
    setPickerQuery('');
    setPicker(true);
  };

  const pickerList = products.filter((p) => p.name.toLowerCase().includes(pickerQuery.toLowerCase()));

  return (
    <PageContainer narrow>
      <PageHeader
        breadcrumbs={[{ label: 'Collections', to: '/collections' }, { label: isNew ? 'New collection' : form.name }]}
        title={isNew ? 'Create collection' : form.name}
        actions={
        <>
            {dirty && <span className="mr-1 text-[13px] text-ink-500">Unsaved changes</span>}
            {!isNew &&
          <Button variant="danger" icon={Trash2Icon} onClick={() => {toast.success(`${form.name} deleted`);navigate('/collections');}}>
                Delete
              </Button>
          }
            <Button
            variant="primary"
            onClick={() => {
              if (!form.name.trim()) {
                toast.error('Give the collection a name');
                return;
              }
              setDirty(false);
              toast.success('Collection saved');
              if (isNew) navigate('/collections');
            }}>
            
              Save
            </Button>
          </>
        } />
      

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0 space-y-6">
          <Panel title="Details">
            <div className="space-y-4">
              <Field label="Name" htmlFor="c-name">
                <TextInput
                  id="c-name"
                  value={form.name}
                  placeholder="e.g. Scripture Series"
                  onChange={(e) => patch({ name: e.target.value, handle: isNew ? e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-') : form.handle })} />
                
              </Field>
              <Field label="Description" htmlFor="c-desc" hint="Shown at the top of the collection page.">
                <TextArea id="c-desc" rows={3} value={form.description} onChange={(e) => patch({ description: e.target.value })} />
              </Field>
            </div>
          </Panel>

          <Panel
            title="Products"
            description={`${assigned.length} products in this collection`}
            padded={false}
            actions={
            <>
                <Select compact aria-label="Sort products" value={sort} onChange={(e) => setSort(e.target.value)} options={[
              { value: 'manual', label: 'Manual order' },
              { value: 'best', label: 'Best selling' },
              { value: 'price-asc', label: 'Price, low to high' }]
              } />
                <Button size="sm" icon={PlusIcon} onClick={openPicker}>
                  Add
                </Button>
              </>
            }>
            
            {assigned.length === 0 ?
            <EmptyState icon={LayersIcon} title="No products yet" description="Add products to start building this collection." action={<Button size="sm" icon={PlusIcon} onClick={openPicker}>Add products</Button>} /> :

            <Reorder.Group axis="y" values={form.productIds} onReorder={(ids) => {if (sort === 'manual') patch({ productIds: ids });}}>
                {assigned.map((p) =>
              <SortableItem key={p.id} value={p.id} className="border-b border-line bg-white last:border-b-0">
                    {(startDrag) =>
                <div className="flex items-center gap-3 px-4 py-2.5">
                        {sort === 'manual' ? <DragHandle onPointerDown={startDrag} label={`Reorder ${p.name}`} /> : <span className="w-6" />}
                        <img src={p.image} alt="" className="h-10 w-10 rounded-md border border-line object-cover" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium text-ink">{p.name}</p>
                          <p className="text-xs text-ink-500">
                            {formatCurrency(p.price)} · {p.stock} in stock
                          </p>
                        </div>
                        <Button
                    variant="ghost"
                    size="sm"
                    icon={XIcon}
                    aria-label={`Remove ${p.name}`}
                    onClick={() => patch({ productIds: form.productIds.filter((x) => x !== p.id) })} />
                  
                      </div>
                }
                  </SortableItem>
              )}
              </Reorder.Group>
            }
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel title="Visibility">
            <Toggle
              label="Visible on storefront"
              description={form.visible ? 'Shown in the shop menu and app.' : 'Only staff can see this collection.'}
              checked={form.visible}
              onChange={(v) => patch({ visible: v })} />
            
          </Panel>

          <Panel title="Cover image">
            {form.image ?
            <div>
                <img src={form.image} alt="Collection cover" className="aspect-[4/3] w-full rounded-md border border-line object-cover" />
                <div className="mt-3 flex gap-2">
                  <label className="inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md border border-line-strong bg-white px-2.5 text-[13px] font-medium text-ink hover:bg-canvas">
                    <RefreshCwIcon className="h-3.5 w-3.5" />
                    Replace
                    <input
                    type="file"
                    accept="image/*"
                    className="sr-only"
                    onChange={(e) => e.target.files?.[0] && patch({ image: URL.createObjectURL(e.target.files[0]) })} />
                  
                  </label>
                  <Button size="sm" variant="ghost" onClick={() => patch({ image: '' })}>
                    Remove
                  </Button>
                </div>
              </div> :

            <ImageDropzone multiple={false} label="Upload cover image" onFiles={(urls) => patch({ image: urls[0] })} />
            }
          </Panel>

          <Panel title="URL">
            <Field label="Handle" htmlFor="c-handle" hint={`shepherdsthread.co/collections/${form.handle || '…'}`}>
              <TextInput id="c-handle" value={form.handle} onChange={(e) => patch({ handle: e.target.value })} />
            </Field>
          </Panel>
        </div>
      </div>

      <Drawer
        open={picker}
        onClose={() => setPicker(false)}
        title="Add products"
        description={`${pending.length} selected`}
        footer={
        <>
            <Button onClick={() => setPicker(false)}>Cancel</Button>
            <Button
            variant="primary"
            onClick={() => {
              patch({ productIds: [...form.productIds.filter((x) => pending.includes(x)), ...pending.filter((x) => !form.productIds.includes(x))] });
              setPicker(false);
            }}>
            
              Done
            </Button>
          </>
        }>
        
        <SearchInput value={pickerQuery} onChange={setPickerQuery} placeholder="Search products" />
        <ul className="mt-4 divide-y divide-line">
          {pickerList.map((p) =>
          <li key={p.id}>
              <label className="flex cursor-pointer items-center gap-3 py-2.5">
                <Checkbox
                checked={pending.includes(p.id)}
                onChange={() => setPending((s) => s.includes(p.id) ? s.filter((x) => x !== p.id) : [...s, p.id])} />
              
                <img src={p.image} alt="" className="h-9 w-9 rounded border border-line object-cover" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm text-ink">{p.name}</span>
                  <span className="block text-xs text-ink-500">{p.category}</span>
                </span>
                <span className="text-[13px] tabular-nums text-ink-600">{formatCurrency(p.price)}</span>
              </label>
            </li>
          )}
        </ul>
      </Drawer>
    </PageContainer>);

}