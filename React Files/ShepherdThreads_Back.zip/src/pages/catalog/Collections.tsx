import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion, Reorder } from 'framer-motion';
import { toast } from 'sonner';
import { ChevronRightIcon, PlusIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Toggle } from '../../components/ui/Toggle';
import { DragHandle } from '../../components/ui/DragHandle';
import { SortableItem } from '../../components/ui/SortableItem';
import { collections as initial } from '../../data/collections';
import type { Collection } from '../../types/catalog';
import { formatDate } from '../../utils/format';

export function Collections() {
  const navigate = useNavigate();
  const [items, setItems] = useState<Collection[]>(initial);
  const [orderChanged, setOrderChanged] = useState(false);

  const toggleVisible = (id: string, visible: boolean) => {
    setItems((prev) => prev.map((c) => c.id === id ? { ...c, visible } : c));
    toast.success(visible ? 'Collection is now visible' : 'Collection hidden from storefront');
  };

  return (
    <PageContainer narrow>
      <PageHeader
        title="Collections"
        description="Drag to set the order collections appear in the shop menu and app."
        actions={
        <Button variant="primary" icon={PlusIcon} onClick={() => navigate('/collections/new')}>
            Create collection
          </Button>
        } />
      

      <section className="overflow-hidden rounded-lg border border-line bg-white">
        <div className="hidden grid-cols-[32px_56px_minmax(0,1fr)_110px_110px_120px_24px] items-center gap-4 border-b border-line bg-canvas px-4 py-2.5 text-xs font-medium text-ink-500 md:grid">
          <span />
          <span />
          <span>Collection</span>
          <span>Products</span>
          <span>Visible</span>
          <span>Updated</span>
          <span />
        </div>
        <Reorder.Group
          axis="y"
          values={items}
          onReorder={(next) => {
            setItems(next);
            setOrderChanged(true);
          }}>
          
          {items.map((c, i) =>
          <SortableItem key={c.id} value={c} className="border-b border-line bg-white last:border-b-0">
              {(startDrag) =>
            <div className="grid grid-cols-[32px_48px_minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 md:grid-cols-[32px_56px_minmax(0,1fr)_110px_110px_120px_24px] md:gap-4">
                  <DragHandle onPointerDown={startDrag} label={`Reorder ${c.name}`} />
                  <img src={c.image} alt="" className="h-12 w-12 rounded-md border border-line object-cover md:h-14 md:w-14" />
                  <Link to={`/collections/${c.id}`} className="min-w-0 group">
                    <p className="truncate text-sm font-medium text-ink group-hover:underline">
                      <span className="mr-2 text-ink-500 tabular-nums">{i + 1}.</span>
                      {c.name}
                    </p>
                    <p className="truncate text-xs text-ink-500">/collections/{c.handle}</p>
                  </Link>
                  <span className="hidden text-[13px] tabular-nums text-ink-600 md:block">{c.productIds.length} products</span>
                  <div className="flex items-center gap-2">
                    <Toggle srLabel={`Show ${c.name} on storefront`} checked={c.visible} onChange={(v) => toggleVisible(c.id, v)} />
                    {!c.visible && <Badge className="hidden lg:inline-flex">Hidden</Badge>}
                  </div>
                  <span className="hidden text-[13px] text-ink-600 md:block">{formatDate(c.updatedAt)}</span>
                  <Link to={`/collections/${c.id}`} aria-label={`Edit ${c.name}`} className="hidden text-stone hover:text-ink md:block">
                    <ChevronRightIcon className="h-4 w-4" />
                  </Link>
                </div>
            }
            </SortableItem>
          )}
        </Reorder.Group>
      </section>

      <AnimatePresence>
        {orderChanged &&
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 12 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
          className="sticky bottom-6 mx-auto mt-6 flex w-fit items-center gap-4 rounded-lg bg-ink py-2 pl-4 pr-2 text-white shadow-pop">
          
            <span className="text-[13px]">Collection order changed</span>
            <button type="button" onClick={() => {setItems(initial);setOrderChanged(false);}} className="h-8 rounded-md px-3 text-[13px] text-white/70 hover:bg-white/10 hover:text-white">
              Undo
            </button>
            <button
            type="button"
            onClick={() => {
              setOrderChanged(false);
              toast.success('Collection order saved');
            }}
            className="h-8 rounded-md bg-white px-3 text-[13px] font-medium text-ink hover:bg-cream">
            
              Save order
            </button>
          </motion.div>
        }
      </AnimatePresence>
    </PageContainer>);

}