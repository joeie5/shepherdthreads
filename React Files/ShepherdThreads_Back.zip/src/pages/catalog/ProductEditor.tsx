import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'sonner';
import { ShirtIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Panel } from '../../components/ui/Panel';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Field } from '../../components/ui/Field';
import { TextInput } from '../../components/ui/TextInput';
import { Select } from '../../components/ui/Select';
import { Checkbox } from '../../components/ui/Checkbox';
import { Toggle } from '../../components/ui/Toggle';
import { EmptyState } from '../../components/ui/EmptyState';
import { RichTextEditor } from '../../components/editor/RichTextEditor';
import { SeoFields } from '../../components/editor/SeoFields';
import { ProductImagesField } from '../../components/products/ProductImagesField';
import { VariantMatrix } from '../../components/products/VariantMatrix';
import { productCategories, products } from '../../data/products';
import { collections } from '../../data/collections';
import type { Product } from '../../types/catalog';
import { formatCurrency, formatDate } from '../../utils/format';
import { productStatusMeta } from '../../utils/status';

const blankProduct: Product = {
  id: 'new',
  name: '',
  handle: '',
  category: 'Tees',
  collections: [],
  price: 0,
  cost: 0,
  status: 'draft',
  image: '',
  gallery: [],
  sizes: ['S', 'M', 'L', 'XL'],
  colors: ['Black'],
  stock: 0,
  sku: 'ST-NEW',
  description: '',
  seoTitle: '',
  seoDescription: '',
  updatedAt: '2026-11-01',
  sales30d: 0
};

export function ProductEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = id === 'new';
  const source = products.find((p) => p.id === id);
  const [form, setForm] = useState<Product>(source ?? blankProduct);
  const [dirty, setDirty] = useState(false);
  const [error, setError] = useState('');
  const [chargeTax, setChargeTax] = useState(true);
  const [channels, setChannels] = useState({ web: true, ios: true, android: true });

  if (!isNew && !source) {
    return (
      <PageContainer>
        <EmptyState
          icon={ShirtIcon}
          title="Product not found"
          description="It may have been deleted or the link is out of date."
          action={<Button onClick={() => navigate('/products')}>Back to products</Button>} />
        
      </PageContainer>);

  }

  const update = <K extends keyof Product,>(key: K, value: Product[K]) => {
    setForm((f) => ({ ...f, [key]: value }));
    setDirty(true);
  };

  const save = () => {
    if (!form.name.trim()) {
      setError('Give your product a title');
      return;
    }
    setError('');
    setDirty(false);
    toast.success(isNew ? `${form.name} created` : 'Product saved', { description: 'Changes are live on web and mobile.' });
    if (isNew) navigate('/products');
  };

  const margin = form.price > 0 ? (form.price - form.cost) / form.price * 100 : 0;
  const status = productStatusMeta[form.status];

  return (
    <PageContainer narrow>
      <PageHeader
        breadcrumbs={[{ label: 'Products', to: '/products' }, { label: isNew ? 'New product' : form.name }]}
        title={isNew ? 'Add product' : form.name || 'Untitled product'}
        meta={!isNew && <Badge tone={status.tone}>{status.label}</Badge>}
        actions={
        <>
            {dirty && <span className="mr-1 text-[13px] text-ink-500">Unsaved changes</span>}
            <Button
            disabled={!dirty}
            onClick={() => {
              setForm(source ?? blankProduct);
              setDirty(false);
            }}>
            
              Discard
            </Button>
            <Button variant="primary" onClick={save}>
              Save
            </Button>
          </>
        } />
      

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="min-w-0 space-y-6">
          <Panel title="Details">
            <div className="space-y-4">
              <Field label="Title" htmlFor="title" error={error}>
                <TextInput
                  id="title"
                  value={form.name}
                  invalid={!!error}
                  placeholder="e.g. Faithful Tee"
                  onChange={(e) => update('name', e.target.value)} />
                
              </Field>
              <Field label="Description">
                <RichTextEditor
                  key={form.id}
                  ariaLabel="Product description"
                  initialValue={form.description ? `<p>${form.description}</p>` : ''}
                  placeholder="Fabric, fit, the verse behind it…"
                  onChange={() => setDirty(true)} />
                
              </Field>
            </div>
          </Panel>

          <Panel title="Media" description="Drag to reorder. The first image is the cover shown in the shop and app.">
            <ProductImagesField images={form.gallery} onChange={(g) => update('gallery', g)} />
          </Panel>

          <Panel title="Pricing">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Price" htmlFor="price">
                <TextInput id="price" type="number" leading="$" value={form.price} onChange={(e) => update('price', Number(e.target.value))} />
              </Field>
              <Field label="Compare-at price" htmlFor="compare" optional>
                <TextInput
                  id="compare"
                  type="number"
                  leading="$"
                  value={form.compareAtPrice ?? ''}
                  onChange={(e) => update('compareAtPrice', e.target.value ? Number(e.target.value) : undefined)} />
                
              </Field>
              <Field label="Cost per item" htmlFor="cost" hint="Customers won’t see this">
                <TextInput id="cost" type="number" leading="$" value={form.cost} onChange={(e) => update('cost', Number(e.target.value))} />
              </Field>
            </div>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-line pt-4">
              <p className="text-[13px] text-ink-600">
                Profit <span className="font-medium tabular-nums text-ink">{formatCurrency(Math.max(0, form.price - form.cost))}</span>
                <span className="mx-2 text-line-strong">|</span>
                Margin <span className="font-medium tabular-nums text-ink">{margin.toFixed(0)}%</span>
              </p>
              <Checkbox label="Charge tax on this product" checked={chargeTax} onChange={(e) => setChargeTax(e.target.checked)} />
            </div>
          </Panel>

          <Panel title="Variants" description="Each size and color combination gets its own SKU and stock count.">
            <VariantMatrix
              key={form.id}
              productId={form.id}
              baseSku={form.sku}
              basePrice={form.price}
              totalStock={form.stock}
              sizes={form.sizes}
              colors={form.colors}
              onOptionsChange={(sizes, colors) => {
                setForm((f) => ({ ...f, sizes, colors }));
                setDirty(true);
              }}
              onEdit={() => setDirty(true)} />
            
          </Panel>

          <Panel title="Search engine listing" description="How this product appears on Google and when shared.">
            <SeoFields
              title={form.seoTitle}
              description={form.seoDescription}
              handle={form.handle}
              pathPrefix="/products/"
              onTitle={(v) => update('seoTitle', v)}
              onDescription={(v) => update('seoDescription', v)}
              onHandle={(v) => update('handle', v)} />
            
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel title="Status">
            <Select
              aria-label="Product status"
              value={form.status}
              onChange={(e) => update('status', e.target.value as Product['status'])}
              options={[
              { value: 'active', label: 'Active' },
              { value: 'draft', label: 'Draft' },
              { value: 'archived', label: 'Archived' }]
              } />
            
            <p className="mt-2 text-xs text-ink-500">
              {form.status === 'active' ?
              'Visible to customers on all selected channels.' :
              form.status === 'draft' ?
              'Hidden from customers until you set it to active.' :
              'Hidden and removed from collections.'}
            </p>
            <div className="mt-4 space-y-2.5 border-t border-line pt-4">
              <p className="text-[13px] font-medium text-ink">Sales channels</p>
              <Checkbox label="Web storefront" checked={channels.web} onChange={(e) => setChannels({ ...channels, web: e.target.checked })} />
              <br />
              <Checkbox label="iOS app" checked={channels.ios} onChange={(e) => setChannels({ ...channels, ios: e.target.checked })} />
              <br />
              <Checkbox label="Android app" checked={channels.android} onChange={(e) => setChannels({ ...channels, android: e.target.checked })} />
            </div>
          </Panel>

          <Panel title="Organization">
            <div className="space-y-4">
              <Field label="Category" htmlFor="category">
                <Select
                  id="category"
                  value={form.category}
                  onChange={(e) => update('category', e.target.value)}
                  options={productCategories.map((c) => ({ value: c, label: c }))} />
                
              </Field>
              <div>
                <p className="mb-2 text-[13px] font-medium text-ink">Collections</p>
                <div className="space-y-2">
                  {collections.map((c) =>
                  <div key={c.id}>
                      <Checkbox
                      label={c.name}
                      checked={form.collections.includes(c.id)}
                      onChange={() =>
                      update(
                        'collections',
                        form.collections.includes(c.id) ? form.collections.filter((x) => x !== c.id) : [...form.collections, c.id]
                      )
                      } />
                    
                    </div>
                  )}
                </div>
              </div>
              <Toggle
                label="Feature on homepage"
                description="Eligible for featured product rows"
                checked={form.collections.includes('c-best-sellers')}
                onChange={(v) =>
                update('collections', v ? [...form.collections, 'c-best-sellers'] : form.collections.filter((x) => x !== 'c-best-sellers'))
                } />
              
            </div>
          </Panel>

          {!isNew &&
          <Panel title="Performance">
              <dl className="space-y-2.5 text-[13px]">
                <div className="flex justify-between">
                  <dt className="text-ink-500">Sold (30 days)</dt>
                  <dd className="font-medium tabular-nums text-ink">{form.sales30d} units</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-ink-500">Revenue (30 days)</dt>
                  <dd className="font-medium tabular-nums text-ink">{formatCurrency(form.sales30d * form.price, false)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-ink-500">Last updated</dt>
                  <dd className="text-ink">{formatDate(form.updatedAt)}</dd>
                </div>
              </dl>
            </Panel>
          }
        </div>
      </div>
    </PageContainer>);

}