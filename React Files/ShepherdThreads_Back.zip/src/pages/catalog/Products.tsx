import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { toast } from 'sonner';
import { ArchiveIcon, CopyIcon, DownloadIcon, EllipsisIcon, PencilIcon, PlusIcon, ShirtIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Tabs } from '../../components/ui/Tabs';
import { SearchInput } from '../../components/ui/SearchInput';
import { Select } from '../../components/ui/Select';
import { Checkbox } from '../../components/ui/Checkbox';
import { Menu } from '../../components/ui/Menu';
import { EmptyState } from '../../components/ui/EmptyState';
import { Pagination } from '../../components/ui/Pagination';
import { productCategories, products } from '../../data/products';
import type { Product, ProductStatus } from '../../types/catalog';
import { cn } from '../../utils/cn';
import { downloadCsv } from '../../utils/csv';
import { formatCurrency } from '../../utils/format';
import { productStatusMeta } from '../../utils/status';
import { rowClass, tableClass, tdClass, thClass } from '../../utils/styles';

export function Products() {
  const navigate = useNavigate();
  const [items, setItems] = useState<Product[]>(products);
  const [tab, setTab] = useState('all');
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [stockFilter, setStockFilter] = useState('all');
  const [selected, setSelected] = useState<string[]>([]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter(
      (p) =>
      (tab === 'all' || p.status === tab) && (
      category === 'all' || p.category === category) && (
      stockFilter === 'all' ||
      stockFilter === 'in' && p.stock > 12 ||
      stockFilter === 'low' && p.stock > 0 && p.stock <= 12 ||
      stockFilter === 'out' && p.stock === 0) && (
      !q || p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q))
    );
  }, [items, tab, category, stockFilter, query]);

  const count = (s: ProductStatus) => items.filter((p) => p.status === s).length;
  const allSelected = filtered.length > 0 && filtered.every((p) => selected.includes(p.id));
  const someSelected = !allSelected && filtered.some((p) => selected.includes(p.id));

  const setStatus = (ids: string[], status: ProductStatus) => {
    setItems((prev) => prev.map((p) => ids.includes(p.id) ? { ...p, status } : p));
    toast.success(`${ids.length} product${ids.length > 1 ? 's' : ''} set to ${productStatusMeta[status].label.toLowerCase()}`);
    setSelected([]);
  };

  const exportRows = (rows: Product[]) => {
    downloadCsv(
      'shepherds-thread-products.csv',
      rows.map((p) => ({ Name: p.name, SKU: p.sku, Category: p.category, Price: p.price, Stock: p.stock, Status: p.status }))
    );
    toast.success(`Exported ${rows.length} products`);
  };

  return (
    <PageContainer>
      <PageHeader
        title="Products"
        description="Everything listed in your web store and mobile apps."
        actions={
        <>
            <Button icon={DownloadIcon} onClick={() => exportRows(filtered)}>
              Export
            </Button>
            <Button variant="primary" icon={PlusIcon} onClick={() => navigate('/products/new')}>
              Add product
            </Button>
          </>
        } />
      

      <section className="rounded-lg border border-line bg-white">
        <div className="px-4 pt-3">
          <Tabs
            value={tab}
            onChange={(t) => {
              setTab(t);
              setSelected([]);
            }}
            tabs={[
            { id: 'all', label: 'All', count: items.length },
            { id: 'active', label: 'Active', count: count('active') },
            { id: 'draft', label: 'Draft', count: count('draft') },
            { id: 'archived', label: 'Archived', count: count('archived') }]
            } />
          
        </div>

        <div className="relative">
          <div className="flex flex-col gap-2 p-4 sm:flex-row">
            <SearchInput value={query} onChange={setQuery} placeholder="Search by name or SKU" className="sm:w-72" />
            <div className="flex gap-2">
              <Select
                aria-label="Category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                options={[{ value: 'all', label: 'All categories' }, ...productCategories.map((c) => ({ value: c, label: c }))]} />
              
              <Select
                aria-label="Stock level"
                value={stockFilter}
                onChange={(e) => setStockFilter(e.target.value)}
                options={[
                { value: 'all', label: 'Any stock level' },
                { value: 'in', label: 'In stock' },
                { value: 'low', label: 'Low stock' },
                { value: 'out', label: 'Out of stock' }]
                } />
              
            </div>
          </div>

          <AnimatePresence>
            {selected.length > 0 &&
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.16, ease: [0.23, 1, 0.32, 1] }}
              className="absolute inset-x-4 top-4 z-10 flex h-9 items-center gap-1 rounded-md bg-ink pl-3 pr-1 text-white">
              
                <span className="mr-auto text-[13px] font-medium tabular-nums">{selected.length} selected</span>
                {(['active', 'draft'] as ProductStatus[]).map((s) =>
              <button
                key={s}
                type="button"
                onClick={() => setStatus(selected, s)}
                className="hidden h-7 rounded px-2.5 text-[13px] text-white/90 transition-colors duration-150 hover:bg-white/10 sm:block">
                
                    Set {productStatusMeta[s].label.toLowerCase()}
                  </button>
              )}
                <button type="button" onClick={() => setStatus(selected, 'archived')} className="h-7 rounded px-2.5 text-[13px] text-white/90 hover:bg-white/10">
                  Archive
                </button>
                <button
                type="button"
                onClick={() => exportRows(items.filter((p) => selected.includes(p.id)))}
                className="h-7 rounded px-2.5 text-[13px] text-white/90 hover:bg-white/10">
                
                  Export
                </button>
                <button type="button" onClick={() => setSelected([])} className="h-7 rounded px-2.5 text-[13px] text-white/60 hover:bg-white/10 hover:text-white">
                  Clear
                </button>
              </motion.div>
            }
          </AnimatePresence>
        </div>

        {filtered.length === 0 ?
        <EmptyState
          icon={ShirtIcon}
          title="No products match these filters"
          description="Try a different search term or clear your filters."
          action={
          <Button
            size="sm"
            onClick={() => {
              setQuery('');
              setCategory('all');
              setStockFilter('all');
              setTab('all');
            }}>
            
                Clear filters
              </Button>
          } /> :


        <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={cn(thClass, 'w-10 pr-0')}>
                    <Checkbox
                    aria-label="Select all products"
                    checked={allSelected}
                    indeterminate={someSelected}
                    onChange={() => setSelected(allSelected ? [] : filtered.map((p) => p.id))} />
                  
                  </th>
                  <th className={thClass}>Product</th>
                  <th className={thClass}>Status</th>
                  <th className={thClass}>Inventory</th>
                  <th className={cn(thClass, 'hidden md:table-cell')}>Category</th>
                  <th className={cn(thClass, 'text-right')}>Price</th>
                  <th className={cn(thClass, 'hidden text-right lg:table-cell')}>Sold (30d)</th>
                  <th className={cn(thClass, 'w-12')}>
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p) => {
                const meta = productStatusMeta[p.status];
                const isSel = selected.includes(p.id);
                const variantCount = p.sizes.length * p.colors.length;
                return (
                  <tr key={p.id} onClick={() => navigate(`/products/${p.id}`)} className={cn(rowClass, isSel && 'bg-brass-soft/50 hover:bg-brass-soft/70')}>
                      <td className={cn(tdClass, 'w-10 pr-0')}>
                        <Checkbox
                        aria-label={`Select ${p.name}`}
                        checked={isSel}
                        onChange={() => setSelected((s) => s.includes(p.id) ? s.filter((x) => x !== p.id) : [...s, p.id])} />
                      
                      </td>
                      <td className={tdClass}>
                        <div className="flex items-center gap-3">
                          <img src={p.image} alt="" className="h-10 w-10 shrink-0 rounded-md border border-line object-cover" />
                          <div className="min-w-0">
                            <p className="truncate font-medium text-ink">{p.name}</p>
                            <p className="font-mono text-xs text-ink-500">{p.sku}</p>
                          </div>
                        </div>
                      </td>
                      <td className={tdClass}>
                        <Badge tone={meta.tone}>{meta.label}</Badge>
                      </td>
                      <td className={cn(tdClass, 'whitespace-nowrap')}>
                        <p
                        className={cn(
                          'tabular-nums',
                          p.stock === 0 ? 'font-medium text-danger' : p.stock <= 12 ? 'font-medium text-warning' : 'text-ink'
                        )}>
                        
                          {p.stock === 0 ? 'Out of stock' : `${p.stock} in stock`}
                        </p>
                        <p className="text-xs text-ink-500">{variantCount} variants</p>
                      </td>
                      <td className={cn(tdClass, 'hidden text-ink-600 md:table-cell')}>{p.category}</td>
                      <td className={cn(tdClass, 'text-right tabular-nums text-ink')}>{formatCurrency(p.price)}</td>
                      <td className={cn(tdClass, 'hidden text-right tabular-nums text-ink-600 lg:table-cell')}>{p.sales30d}</td>
                      <td className={cn(tdClass, 'w-12 text-right')}>
                        <Menu
                        ariaLabel={`Actions for ${p.name}`}
                        triggerClassName="flex h-8 w-8 items-center justify-center rounded-md text-ink-500 hover:bg-black/[0.05] hover:text-ink"
                        trigger={<EllipsisIcon className="h-4 w-4" />}
                        items={[
                        { label: 'Edit', icon: PencilIcon, onClick: () => navigate(`/products/${p.id}`) },
                        {
                          label: 'Duplicate',
                          icon: CopyIcon,
                          onClick: () => {
                            setItems((prev) => [{ ...p, id: `${p.id}-copy-${Date.now()}`, name: `${p.name} (copy)`, status: 'draft' }, ...prev]);
                            toast.success(`Duplicated ${p.name} as a draft`);
                          }
                        },
                        { label: 'Archive', icon: ArchiveIcon, danger: true, divider: true, onClick: () => setStatus([p.id], 'archived') }]
                        } />
                      
                      </td>
                    </tr>);

              })}
              </tbody>
            </table>
          </div>
        }
        <Pagination showing={filtered.length} total={filtered.length} label="products" />
      </section>
    </PageContainer>);

}