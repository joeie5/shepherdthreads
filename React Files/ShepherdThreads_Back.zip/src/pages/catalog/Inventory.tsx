import React, { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { toast } from 'sonner';
import { BoxesIcon, DownloadIcon, MinusIcon, PlusIcon, SlidersHorizontalIcon } from 'lucide-react';
import { PageContainer } from '../../components/layout/PageContainer';
import { PageHeader } from '../../components/ui/PageHeader';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Tabs } from '../../components/ui/Tabs';
import { SearchInput } from '../../components/ui/SearchInput';
import { Drawer } from '../../components/ui/Drawer';
import { Field } from '../../components/ui/Field';
import { TextInput } from '../../components/ui/TextInput';
import { Toggle } from '../../components/ui/Toggle';
import { EmptyState } from '../../components/ui/EmptyState';
import { inventory } from '../../data/inventory';
import type { InventoryItem } from '../../types/catalog';
import { cn } from '../../utils/cn';
import { downloadCsv } from '../../utils/csv';
import { stockMeta } from '../../utils/status';
import { inputBase, tableClass, tdClass, thClass } from '../../utils/styles';

export function Inventory() {
  const [params] = useSearchParams();
  const [rows, setRows] = useState<InventoryItem[]>(inventory);
  const [edits, setEdits] = useState<Record<string, number>>({});
  const [filter, setFilter] = useState(params.get('filter') ?? 'all');
  const [query, setQuery] = useState('');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [defaultThreshold, setDefaultThreshold] = useState(10);
  const [alerts, setAlerts] = useState({ email: true, recipient: 'hannah@shepherdsthread.co', hideOos: false, preorder: false });

  const stockOf = (r: InventoryItem) => edits[r.sku] ?? r.stock;

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    return rows.filter((r) => {
      const s = stockOf(r);
      const match = !q || r.product.toLowerCase().includes(q) || r.sku.toLowerCase().includes(q);
      if (!match) return false;
      if (filter === 'low') return s > 0 && s <= r.threshold;
      if (filter === 'out') return s === 0;
      return true;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, filter, query, edits]);

  const lowCount = rows.filter((r) => r.stock > 0 && r.stock <= r.threshold).length;
  const outCount = rows.filter((r) => r.stock === 0).length;
  const totalUnits = rows.reduce((s, r) => s + r.stock, 0);
  const editCount = Object.keys(edits).length;

  const setStock = (r: InventoryItem, value: number) => {
    const v = Math.max(0, value);
    setEdits((e) => {
      const next = { ...e };
      if (v === r.stock) delete next[r.sku];else
      next[r.sku] = v;
      return next;
    });
  };

  const save = () => {
    setRows((prev) => prev.map((r) => edits[r.sku] !== undefined ? { ...r, stock: edits[r.sku] } : r));
    toast.success(`Updated stock on ${editCount} variant${editCount > 1 ? 's' : ''}`);
    setEdits({});
  };

  return (
    <PageContainer>
      <PageHeader
        title="Inventory"
        description={`${rows.length} variants · ${totalUnits} units on hand · ${lowCount + outCount} need attention`}
        actions={
        <>
            <Button
            icon={DownloadIcon}
            onClick={() => {
              downloadCsv('inventory.csv', rows.map((r) => ({ SKU: r.sku, Product: r.product, Color: r.color, Size: r.size, Stock: r.stock, Threshold: r.threshold })));
              toast.success('Inventory exported');
            }}>
            
              Export
            </Button>
            <Button icon={SlidersHorizontalIcon} onClick={() => setSettingsOpen(true)}>
              Alert settings
            </Button>
          </>
        } />
      

      <section className="rounded-lg border border-line bg-white">
        <div className="flex flex-col gap-3 px-4 pt-3 md:flex-row md:items-end md:justify-between">
          <Tabs
            value={filter}
            onChange={setFilter}
            tabs={[
            { id: 'all', label: 'All variants', count: rows.length },
            { id: 'low', label: 'Low stock', count: lowCount },
            { id: 'out', label: 'Out of stock', count: outCount }]
            }
            className="border-b-0" />
          
          <SearchInput value={query} onChange={setQuery} placeholder="Search product or SKU" className="pb-3 md:w-64" />
        </div>

        {filtered.length === 0 ?
        <div className="border-t border-line">
            <EmptyState icon={BoxesIcon} title="Nothing here" description="No variants match this filter. Nice work keeping stock healthy." />
          </div> :

        <div className="overflow-x-auto border-t border-line">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Product</th>
                  <th className={cn(thClass, 'hidden md:table-cell')}>SKU</th>
                  <th className={cn(thClass, 'text-right')}>Committed</th>
                  <th className={cn(thClass, 'text-right')}>Available</th>
                  <th className={thClass}>Alert at</th>
                  <th className={thClass}>On hand</th>
                  <th className={thClass}>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => {
                const s = stockOf(r);
                const meta = stockMeta(s, r.threshold);
                const changed = edits[r.sku] !== undefined;
                return (
                  <tr key={r.sku} className={cn(changed && 'bg-brass-soft/50')}>
                      <td className={tdClass}>
                        <div className="flex items-center gap-3">
                          <img src={r.image} alt="" className="h-9 w-9 rounded border border-line object-cover" />
                          <div className="min-w-0">
                            <p className="truncate font-medium text-ink">{r.product}</p>
                            <p className="text-xs text-ink-500">
                              {r.color} · {r.size}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className={cn(tdClass, 'hidden font-mono text-xs text-ink-600 md:table-cell')}>{r.sku}</td>
                      <td className={cn(tdClass, 'text-right tabular-nums text-ink-600')}>{r.committed}</td>
                      <td className={cn(tdClass, 'text-right font-medium tabular-nums text-ink')}>{Math.max(0, s - r.committed)}</td>
                      <td className={tdClass}>
                        <input
                        type="number"
                        min={0}
                        aria-label={`Low-stock alert threshold for ${r.sku}`}
                        value={r.threshold}
                        onChange={(e) => setRows((prev) => prev.map((x) => x.sku === r.sku ? { ...x, threshold: Math.max(0, Number(e.target.value)) } : x))}
                        className={cn(inputBase, 'h-8 w-16 px-2 text-[13px] tabular-nums')} />
                      
                      </td>
                      <td className={tdClass}>
                        <div className="inline-flex items-center rounded-md border border-line-strong bg-white">
                          <button type="button" aria-label={`Decrease ${r.sku}`} onClick={() => setStock(r, s - 1)} className="flex h-8 w-8 items-center justify-center text-ink-600 hover:bg-canvas">
                            <MinusIcon className="h-3.5 w-3.5" />
                          </button>
                          <input
                          type="number"
                          min={0}
                          aria-label={`On hand for ${r.sku}`}
                          value={s}
                          onChange={(e) => setStock(r, Number(e.target.value))}
                          className="h-8 w-14 border-x border-line-strong text-center text-[13px] font-medium tabular-nums text-ink focus:outline-none [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none" />
                        
                          <button type="button" aria-label={`Increase ${r.sku}`} onClick={() => setStock(r, s + 1)} className="flex h-8 w-8 items-center justify-center text-ink-600 hover:bg-canvas">
                            <PlusIcon className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                      <td className={tdClass}>
                        <Badge tone={meta.tone} dot>
                          {meta.label}
                        </Badge>
                      </td>
                    </tr>);

              })}
              </tbody>
            </table>
          </div>
        }
      </section>

      <AnimatePresence>
        {editCount > 0 &&
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 12 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
          className="sticky bottom-6 mx-auto mt-6 flex w-fit items-center gap-4 rounded-lg bg-ink py-2 pl-4 pr-2 text-white shadow-pop">
          
            <span className="text-[13px] tabular-nums">
              {editCount} stock adjustment{editCount > 1 ? 's' : ''}
            </span>
            <button type="button" onClick={() => setEdits({})} className="h-8 rounded-md px-3 text-[13px] text-white/70 hover:bg-white/10 hover:text-white">
              Discard
            </button>
            <button type="button" onClick={save} className="h-8 rounded-md bg-white px-3 text-[13px] font-medium text-ink hover:bg-cream">
              Save stock
            </button>
          </motion.div>
        }
      </AnimatePresence>

      <Drawer
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        title="Stock alert settings"
        description="Decide when a variant counts as low stock and who hears about it."
        footer={
        <>
            <Button onClick={() => setSettingsOpen(false)}>Cancel</Button>
            <Button
            variant="primary"
            onClick={() => {
              setSettingsOpen(false);
              toast.success('Alert settings saved');
            }}>
            
              Save settings
            </Button>
          </>
        }>
        
        <div className="space-y-6">
          <Field label="Default low-stock threshold" htmlFor="def-th" hint="Used for new variants. Each variant can override it in the table.">
            <div className="flex gap-2">
              <TextInput id="def-th" type="number" value={defaultThreshold} trailing="units" onChange={(e) => setDefaultThreshold(Number(e.target.value))} />
              <Button
                onClick={() => {
                  setRows((prev) => prev.map((r) => ({ ...r, threshold: defaultThreshold })));
                  toast.success(`Applied ${defaultThreshold} units to all variants`);
                }}>
                
                Apply to all
              </Button>
            </div>
          </Field>
          <div className="space-y-4 border-t border-line pt-5">
            <Toggle label="Email me when stock is low" description="Daily digest at 8:00 AM" checked={alerts.email} onChange={(v) => setAlerts({ ...alerts, email: v })} />
            {alerts.email &&
            <Field label="Send alerts to" htmlFor="alert-to">
                <TextInput id="alert-to" type="email" value={alerts.recipient} onChange={(e) => setAlerts({ ...alerts, recipient: e.target.value })} />
              </Field>
            }
          </div>
          <div className="space-y-4 border-t border-line pt-5">
            <Toggle label="Hide sold-out products" description="Remove from storefront and app when every variant is at 0" checked={alerts.hideOos} onChange={(v) => setAlerts({ ...alerts, hideOos: v })} />
            <Toggle label="Allow pre-orders" description="Keep selling when out of stock and ship later" checked={alerts.preorder} onChange={(v) => setAlerts({ ...alerts, preorder: v })} />
          </div>
        </div>
      </Drawer>
    </PageContainer>);

}