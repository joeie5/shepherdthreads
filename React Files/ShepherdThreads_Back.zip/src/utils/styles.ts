export const inputBase =
'w-full rounded-md border border-line-strong bg-white text-sm text-ink placeholder:text-stone transition-[border-color,box-shadow] duration-150 ease-out focus:border-ink focus:outline-none focus:ring-[3px] focus:ring-brass/25 disabled:bg-canvas disabled:text-ink-500';

export const tableClass = 'w-full text-left text-sm';
export const thClass =
'h-10 px-4 text-xs font-medium text-ink-500 whitespace-nowrap border-b border-line bg-canvas';
export const tdClass = 'px-4 py-3 border-b border-line align-middle';
export const rowClass = 'cursor-pointer transition-colors duration-150 hover:bg-canvas';