import type { Tone } from '../components/ui/Badge';
import type { ProductStatus } from '../types/catalog';
import type { DiscountStatus, DiscountType, FulfillmentStatus, PaymentStatus } from '../types/sales';
import type { PostStatus } from '../types/content';

interface StatusMeta {
  label: string;
  tone: Tone;
}

export const productStatusMeta: Record<ProductStatus, StatusMeta> = {
  active: { label: 'Active', tone: 'success' },
  draft: { label: 'Draft', tone: 'neutral' },
  archived: { label: 'Archived', tone: 'warning' }
};

export const paymentMeta: Record<PaymentStatus, StatusMeta> = {
  paid: { label: 'Paid', tone: 'success' },
  pending: { label: 'Pending', tone: 'warning' },
  refunded: { label: 'Refunded', tone: 'neutral' },
  partially_refunded: { label: 'Partially refunded', tone: 'info' },
  failed: { label: 'Failed', tone: 'danger' }
};

export const fulfillmentMeta: Record<FulfillmentStatus, StatusMeta> = {
  unfulfilled: { label: 'Unfulfilled', tone: 'brass' },
  processing: { label: 'Processing', tone: 'info' },
  shipped: { label: 'Shipped', tone: 'info' },
  delivered: { label: 'Delivered', tone: 'success' },
  cancelled: { label: 'Cancelled', tone: 'neutral' }
};

export const discountStatusMeta: Record<DiscountStatus, StatusMeta> = {
  active: { label: 'Active', tone: 'success' },
  scheduled: { label: 'Scheduled', tone: 'info' },
  expired: { label: 'Expired', tone: 'neutral' }
};

export const postStatusMeta: Record<PostStatus, StatusMeta> = {
  published: { label: 'Published', tone: 'success' },
  draft: { label: 'Draft', tone: 'neutral' },
  scheduled: { label: 'Scheduled', tone: 'info' }
};

export function discountValueLabel(type: DiscountType, value: number): string {
  if (type === 'percent') return `${value}% off`;
  if (type === 'fixed') return `$${value} off`;
  return 'Free shipping';
}

export function stockMeta(stock: number, threshold = 10): StatusMeta {
  if (stock <= 0) return { label: 'Out of stock', tone: 'danger' };
  if (stock <= threshold) return { label: 'Low stock', tone: 'warning' };
  return { label: 'In stock', tone: 'success' };
}