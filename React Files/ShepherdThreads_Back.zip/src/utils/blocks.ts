import type { LucideIcon } from 'lucide-react';
import { ImageIcon, LayoutGridIcon, MailIcon, NewspaperIcon, QuoteIcon, TypeIcon } from 'lucide-react';
import type { BlockType, PageBlock } from '../types/content';
import { images } from '../data/images';
import { collections } from '../data/collections';

export const blockMeta: Record<BlockType, {label: string;description: string;icon: LucideIcon;}> = {
  hero: { label: 'Hero banner', description: 'Full-width image with headline and button', icon: ImageIcon },
  productRow: { label: 'Featured products', description: 'A row of products from a collection', icon: LayoutGridIcon },
  story: { label: 'Story strip', description: 'Image beside a short story', icon: NewspaperIcon },
  testimonials: { label: 'Testimonials', description: 'Customer quotes and photos', icon: QuoteIcon },
  newsletter: { label: 'Newsletter band', description: 'Email signup call-to-action', icon: MailIcon },
  text: { label: 'Text section', description: 'Heading and paragraph', icon: TypeIcon }
};

export function blockSummary(block: PageBlock): string {
  switch (block.type) {
    case 'hero':
      return block.data.headline;
    case 'productRow':
      return `${block.data.title} · ${collections.find((c) => c.id === block.data.collection)?.name ?? 'No collection'}`;
    case 'story':
      return block.data.title;
    case 'testimonials':
      return `${block.data.items.length} quotes`;
    case 'newsletter':
      return block.data.headline;
    case 'text':
      return block.data.heading;
  }
}

export function createBlock(type: BlockType): PageBlock {
  const id = `b-${type}-${Date.now()}`;
  switch (type) {
    case 'hero':
      return { id, type, visible: true, data: { headline: 'New headline', subheadline: 'Supporting line of text', ctaLabel: 'Shop now', ctaLink: '/shop', image: images.hero, align: 'left' } };
    case 'productRow':
      return { id, type, visible: true, data: { title: 'Featured', subtitle: '', collection: 'c-best-sellers', count: 4, showPrices: true } };
    case 'story':
      return { id, type, visible: true, data: { eyebrow: 'Our story', title: 'A new story', body: 'Tell your customers something worth knowing.', image: images.story, ctaLabel: 'Learn more', ctaLink: '/about', imageSide: 'left' } };
    case 'testimonials':
      return { id, type, visible: true, data: { title: 'What people are saying', items: [{ quote: 'Add a customer quote here.', name: 'Customer name', detail: 'City, State', image: images.ugc }] } };
    case 'newsletter':
      return { id, type, visible: true, data: { headline: 'Stay in touch', body: 'New drops and devotionals in your inbox.', buttonLabel: 'Subscribe', theme: 'cream' } };
    case 'text':
      return { id, type, visible: true, data: { heading: 'Section heading', body: 'Write something here.', align: 'center' } };
  }
}