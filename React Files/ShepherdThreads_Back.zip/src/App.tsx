import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Toaster } from 'sonner';
import { AdminLayout } from './components/layout/AdminLayout';
import { Dashboard } from './pages/Dashboard';
import { Analytics } from './pages/Analytics';
import { Products } from './pages/catalog/Products';
import { ProductEditor } from './pages/catalog/ProductEditor';
import { Collections } from './pages/catalog/Collections';
import { CollectionEditor } from './pages/catalog/CollectionEditor';
import { Inventory } from './pages/catalog/Inventory';
import { Orders } from './pages/sales/Orders';
import { OrderDetail } from './pages/sales/OrderDetail';
import { Customers } from './pages/sales/Customers';
import { CustomerDetail } from './pages/sales/CustomerDetail';
import { Discounts } from './pages/sales/Discounts';
import { DiscountEditor } from './pages/sales/DiscountEditor';
import { PageBuilder } from './pages/content/PageBuilder';
import { Journal } from './pages/content/Journal';
import { PostEditor } from './pages/content/PostEditor';
import { MediaLibrary } from './pages/content/MediaLibrary';
import { Staff } from './pages/admin/Staff';
import { Settings } from './pages/admin/Settings';

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AdminLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="analytics" element={<Analytics />} />
          <Route path="products" element={<Products />} />
          <Route path="products/:id" element={<ProductEditor />} />
          <Route path="collections" element={<Collections />} />
          <Route path="collections/:id" element={<CollectionEditor />} />
          <Route path="inventory" element={<Inventory />} />
          <Route path="orders" element={<Orders />} />
          <Route path="orders/:id" element={<OrderDetail />} />
          <Route path="customers" element={<Customers />} />
          <Route path="customers/:id" element={<CustomerDetail />} />
          <Route path="discounts" element={<Discounts />} />
          <Route path="discounts/:id" element={<DiscountEditor />} />
          <Route path="content" element={<Navigate to="/content/home" replace />} />
          <Route path="content/:pageId" element={<PageBuilder />} />
          <Route path="journal" element={<Journal />} />
          <Route path="journal/:id" element={<PostEditor />} />
          <Route path="media" element={<MediaLibrary />} />
          <Route path="staff" element={<Staff />} />
          <Route path="settings" element={<Navigate to="/settings/general" replace />} />
          <Route path="settings/:tab" element={<Settings />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
      <Toaster position="bottom-right" toastOptions={{ style: { fontFamily: 'Inter, sans-serif', fontSize: 13 } }} />
    </BrowserRouter>);

}