import React from 'react';
import { Field } from '../ui/Field';
import { TextInput } from '../ui/TextInput';
import { TextArea } from '../ui/TextArea';
import { cn } from '../../utils/cn';

interface SeoFieldsProps {
  title: string;
  description: string;
  handle: string;
  pathPrefix: string;
  onTitle: (v: string) => void;
  onDescription: (v: string) => void;
  onHandle: (v: string) => void;
}

function Counter({ value, max }: {value: string;max: number;}) {
  return (
    <span className={cn('text-xs tabular-nums', value.length > max ? 'text-danger' : 'text-ink-500')}>
      {value.length}/{max}
    </span>);

}

export function SeoFields({ title, description, handle, pathPrefix, onTitle, onDescription, onHandle }: SeoFieldsProps) {
  return (
    <div className="space-y-4">
      <div className="rounded-md border border-line bg-canvas p-4" aria-label="Search result preview">
        <p className="text-xs text-ink-500">
          shepherdsthread.co{pathPrefix}
          {handle || 'your-handle'}
        </p>
        <p className="mt-1 truncate text-[17px] leading-snug text-info">{title || 'Page title'}</p>
        <p className="mt-1 line-clamp-2 text-[13px] text-ink-600">
          {description || 'Add a description to show how this page might appear in search results.'}
        </p>
      </div>
      <Field label="Page title" htmlFor="seo-title" aside={<Counter value={title} max={70} />}>
        <TextInput id="seo-title" value={title} onChange={(e) => onTitle(e.target.value)} />
      </Field>
      <Field label="Meta description" htmlFor="seo-desc" aside={<Counter value={description} max={160} />}>
        <TextArea id="seo-desc" rows={3} value={description} onChange={(e) => onDescription(e.target.value)} />
      </Field>
      <Field label="URL handle" htmlFor="seo-handle">
        <TextInput
          id="seo-handle"
          value={handle}
          onChange={(e) => onHandle(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-'))}
          leading={<span className="text-xs">{pathPrefix}</span>}
          style={{ paddingLeft: `calc(0.75rem + ${(pathPrefix.length * 0.9).toFixed(1)}ch + 4px)` }} />
        
      </Field>
    </div>);

}