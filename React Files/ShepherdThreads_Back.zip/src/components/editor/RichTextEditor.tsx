import React, { useEffect, useRef, useState } from 'react';
import {
  BoldIcon,
  Heading2Icon,
  ImagePlusIcon,
  ItalicIcon,
  LinkIcon,
  ListIcon,
  ListOrderedIcon,
  PilcrowIcon,
  QuoteIcon,
  Redo2Icon,
  UnderlineIcon,
  Undo2Icon } from
'lucide-react';
import { ToolbarButton } from './ToolbarButton';
import { cn } from '../../utils/cn';

interface RichTextEditorProps {
  initialValue: string;
  onChange: (html: string) => void;
  ariaLabel: string;
  placeholder?: string;
  minHeight?: number;
  allowImages?: boolean;
  className?: string;
}

type ActiveState = Record<'bold' | 'italic' | 'underline' | 'insertUnorderedList' | 'insertOrderedList', boolean>;

export function RichTextEditor({
  initialValue,
  onChange,
  ariaLabel,
  placeholder = 'Start writing…',
  minHeight = 160,
  allowImages = false,
  className
}: RichTextEditorProps) {
  const ref = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [active, setActive] = useState<Partial<ActiveState>>({});

  useEffect(() => {
    if (ref.current) ref.current.innerHTML = initialValue;
    // Only seed once; parent remounts with a key to load different content.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const update = () => {
      const node = document.getSelection()?.anchorNode ?? null;
      if (!ref.current || !node || !ref.current.contains(node)) return;
      setActive({
        bold: document.queryCommandState('bold'),
        italic: document.queryCommandState('italic'),
        underline: document.queryCommandState('underline'),
        insertUnorderedList: document.queryCommandState('insertUnorderedList'),
        insertOrderedList: document.queryCommandState('insertOrderedList')
      });
    };
    document.addEventListener('selectionchange', update);
    return () => document.removeEventListener('selectionchange', update);
  }, []);

  const emit = () => onChange(ref.current?.innerHTML ?? '');
  const exec = (cmd: string, arg?: string) => {
    ref.current?.focus();
    document.execCommand(cmd, false, arg);
    emit();
  };

  const addLink = () => {
    const url = window.prompt('Link URL', 'https://');
    if (url) exec('createLink', url);
  };

  const onImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) exec('insertImage', URL.createObjectURL(file));
    e.target.value = '';
  };

  const divider = <span className="mx-1 h-4 w-px bg-line-strong" aria-hidden />;

  return (
    <div
      className={cn(
        'rounded-md border border-line-strong bg-white transition-[border-color,box-shadow] duration-150 focus-within:border-ink focus-within:ring-[3px] focus-within:ring-brass/25',
        className
      )}>
      
      <div role="toolbar" aria-label="Formatting" className="flex flex-wrap items-center gap-0.5 rounded-t-md border-b border-line bg-canvas px-1.5 py-1">
        <ToolbarButton icon={BoldIcon} label="Bold" active={active.bold} onClick={() => exec('bold')} />
        <ToolbarButton icon={ItalicIcon} label="Italic" active={active.italic} onClick={() => exec('italic')} />
        <ToolbarButton icon={UnderlineIcon} label="Underline" active={active.underline} onClick={() => exec('underline')} />
        {divider}
        <ToolbarButton icon={Heading2Icon} label="Heading" onClick={() => exec('formatBlock', '<h2>')} />
        <ToolbarButton icon={PilcrowIcon} label="Paragraph" onClick={() => exec('formatBlock', '<p>')} />
        <ToolbarButton icon={QuoteIcon} label="Scripture / quote" onClick={() => exec('formatBlock', '<blockquote>')} />
        {divider}
        <ToolbarButton icon={ListIcon} label="Bulleted list" active={active.insertUnorderedList} onClick={() => exec('insertUnorderedList')} />
        <ToolbarButton icon={ListOrderedIcon} label="Numbered list" active={active.insertOrderedList} onClick={() => exec('insertOrderedList')} />
        {divider}
        <ToolbarButton icon={LinkIcon} label="Insert link" onClick={addLink} />
        {allowImages && <ToolbarButton icon={ImagePlusIcon} label="Insert image" onClick={() => fileRef.current?.click()} />}
        <span className="ml-auto flex">
          <ToolbarButton icon={Undo2Icon} label="Undo" onClick={() => exec('undo')} />
          <ToolbarButton icon={Redo2Icon} label="Redo" onClick={() => exec('redo')} />
        </span>
      </div>
      <div
        ref={ref}
        contentEditable
        suppressContentEditableWarning
        role="textbox"
        aria-multiline="true"
        aria-label={ariaLabel}
        data-placeholder={placeholder}
        onInput={emit}
        className="rte px-4 py-3 text-[15px] text-ink"
        style={{ minHeight }} />
      
      {allowImages && <input ref={fileRef} type="file" accept="image/*" className="sr-only" onChange={onImage} />}
    </div>);

}