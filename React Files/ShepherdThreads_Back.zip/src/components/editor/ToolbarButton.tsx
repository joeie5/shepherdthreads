import React from "react";
import { cn } from "../../utils/cn";
import { BoxIcon } from "lucide-react";
interface ToolbarButtonProps {
  icon: BoxIcon;
  label: string;
  onClick: () => void;
  active?: boolean;
}
export function ToolbarButton({
  icon: Icon,
  label,
  onClick,
  active
}: ToolbarButtonProps) {
  return <button type="button" aria-label={label} title={label} aria-pressed={active} onMouseDown={(e) => e.preventDefault()} onClick={onClick} className={cn('flex h-7 w-7 items-center justify-center rounded transition-colors duration-100', active ? 'bg-ink text-white' : 'text-ink-600 hover:bg-black/[0.06] hover:text-ink')}>
      <Icon className="h-4 w-4" />
    </button>;
}