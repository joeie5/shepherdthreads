import React, { useState } from 'react';
import { PlusIcon, XIcon } from 'lucide-react';
import { inventory } from '../../data/inventory';
import { colorSwatches, sizeOptions } from '../../data/swatches';
import { cn } from '../../utils/cn';
import { inputBase } from '../../utils/styles';

interface VariantValues {
  sku: string;
  price: number;
  stock: number;
}

interface VariantMatrixProps {
  productId: string;
  baseSku: string;
  basePrice: number;
  totalStock: number;
  sizes: string[];
  colors: string[];
  onOptionsChange: (sizes: string[], colors: string[]) => void;
  onEdit: () => void;
}

const keyOf = (color: string, size: string) => `${color}__${size}`;
const sizeCode = (s: string) => s === 'One size' ? 'OS' : s;

export function VariantMatrix({
  productId,
  baseSku,
  basePrice,
  totalStock,
  sizes,
  colors,
  onOptionsChange,
  onEdit
}: VariantMatrixProps) {
  const [values, setValues] = useState<Record<string, VariantValues>>(() => {
    const count = Math.max(1, sizes.length * colors.length);
    const fallbackStock = Math.floor(totalStock / count);
    const init: Record<string, VariantValues> = {};
    colors.forEach((c) =>
    sizes.forEach((s) => {
      const inv = inventory.find((i) => i.productId === productId && i.color === c && i.size === s);
      init[keyOf(c, s)] = {
        sku: inv?.sku ?? `${baseSku}-${c.slice(0, 3).toUpperCase()}-${sizeCode(s)}`,
        price: basePrice,
        stock: inv?.stock ?? fallbackStock
      };
    })
    );
    return init;
  });
  const [newColor, setNewColor] = useState('');

  const get = (c: string, s: string): VariantValues =>
  values[keyOf(c, s)] ?? { sku: `${baseSku || 'ST'}-${c.slice(0, 3).toUpperCase()}-${sizeCode(s)}`, price: basePrice, stock: 0 };

  const set = (c: string, s: string, patch: Partial<VariantValues>) => {
    setValues((v) => ({ ...v, [keyOf(c, s)]: { ...get(c, s), ...patch } }));
    onEdit();
  };

  const toggleSize = (s: string) =>
  onOptionsChange(sizes.includes(s) ? sizes.filter((x) => x !== s) : sizeOptions.filter((x) => x === s || sizes.includes(x)), colors);

  const addColor = () => {
    const c = newColor.trim();
    if (!c || colors.includes(c)) return;
    onOptionsChange(sizes, [...colors, c]);
    setNewColor('');
  };

  const colorTotal = (c: string) => sizes.reduce((sum, s) => sum + get(c, s).stock, 0);
  const total = colors.reduce((sum, c) => sum + colorTotal(c), 0);
  const cellInput = cn(inputBase, 'h-8 px-2 text-[13px]');

  return (
    <div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <p className="mb-2 text-[13px] font-medium text-ink">Sizes</p>
          <div className="flex flex-wrap gap-1.5">
            {sizeOptions.map((s) => {
              const on = sizes.includes(s);
              return (
                <button
                  key={s}
                  type="button"
                  aria-pressed={on}
                  onClick={() => toggleSize(s)}
                  className={cn(
                    'h-8 min-w-[40px] whitespace-nowrap rounded-md border px-2.5 text-[13px] font-medium transition-colors duration-150',
                    on ? 'border-ink bg-ink text-white' : 'border-line-strong bg-white text-ink-600 hover:border-stone'
                  )}>
                  
                  {s}
                </button>);

            })}
          </div>
        </div>
        <div>
          <p className="mb-2 text-[13px] font-medium text-ink">Colors</p>
          <div className="flex flex-wrap items-center gap-1.5">
            {colors.map((c) =>
            <span key={c} className="inline-flex h-8 items-center gap-2 rounded-md border border-line-strong bg-white pl-2 pr-1 text-[13px] text-ink">
                <span className="h-3.5 w-3.5 rounded-full border border-line-strong" style={{ background: colorSwatches[c] ?? '#ddd' }} />
                {c}
                <button
                type="button"
                aria-label={`Remove ${c}`}
                onClick={() => onOptionsChange(sizes, colors.filter((x) => x !== c))}
                className="rounded p-0.5 text-ink-500 hover:bg-black/[0.05] hover:text-ink">
                
                  <XIcon className="h-3.5 w-3.5" />
                </button>
              </span>
            )}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                addColor();
              }}
              className="relative">
              
              <input
                value={newColor}
                onChange={(e) => setNewColor(e.target.value)}
                placeholder="Add color"
                aria-label="Add color"
                className="h-8 w-28 rounded-md border border-dashed border-line-strong bg-white pl-7 pr-2 text-[13px] placeholder:text-ink-500 focus:border-ink focus:outline-none" />
              
              <PlusIcon className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-500" />
            </form>
          </div>
        </div>
      </div>

      {sizes.length === 0 || colors.length === 0 ?
      <p className="mt-5 rounded-md border border-dashed border-line-strong bg-canvas px-4 py-6 text-center text-[13px] text-ink-500">
          Choose at least one size and one color to create variants.
        </p> :

      <>
          <div className="mt-5 overflow-x-auto rounded-md border border-line">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="bg-white">
                  <th className="h-9 border-b border-line px-4 text-xs font-medium text-ink-500">Variant</th>
                  <th className="h-9 border-b border-line px-3 text-xs font-medium text-ink-500">SKU</th>
                  <th className="h-9 border-b border-line px-3 text-xs font-medium text-ink-500">Price</th>
                  <th className="h-9 border-b border-line px-3 text-xs font-medium text-ink-500">Stock</th>
                </tr>
              </thead>
              <tbody>
                {colors.map((c) =>
              <React.Fragment key={c}>
                    <tr className="bg-canvas">
                      <td colSpan={4} className="border-b border-line px-4 py-2 text-[13px] font-medium text-ink">
                        <span className="inline-flex items-center gap-2">
                          <span className="h-3.5 w-3.5 rounded-full border border-line-strong" style={{ background: colorSwatches[c] ?? '#ddd' }} />
                          {c}
                          <span className="font-normal text-ink-500">· {colorTotal(c)} in stock</span>
                        </span>
                      </td>
                    </tr>
                    {sizes.map((s) => {
                  const v = get(c, s);
                  return (
                    <tr key={s}>
                          <td className="whitespace-nowrap border-b border-line py-2 pl-10 pr-4 text-[13px] text-ink">{s}</td>
                          <td className="border-b border-line px-3 py-2">
                            <input
                          aria-label={`SKU for ${c} ${s}`}
                          value={v.sku}
                          onChange={(e) => set(c, s, { sku: e.target.value })}
                          className={cn(cellInput, 'min-w-[150px] font-mono text-xs')} />
                        
                          </td>
                          <td className="border-b border-line px-3 py-2">
                            <div className="relative w-24">
                              <span className="pointer-events-none absolute left-2 top-1/2 -translate-y-1/2 text-[13px] text-ink-500">$</span>
                              <input
                            type="number"
                            aria-label={`Price for ${c} ${s}`}
                            value={v.price}
                            onChange={(e) => set(c, s, { price: Number(e.target.value) })}
                            className={cn(cellInput, 'pl-5 tabular-nums')} />
                          
                            </div>
                          </td>
                          <td className="border-b border-line px-3 py-2">
                            <input
                          type="number"
                          min={0}
                          aria-label={`Stock for ${c} ${s}`}
                          value={v.stock}
                          onChange={(e) => set(c, s, { stock: Math.max(0, Number(e.target.value)) })}
                          className={cn(cellInput, 'w-20 tabular-nums', v.stock === 0 && 'border-danger/40 text-danger')} />
                        
                          </td>
                        </tr>);

                })}
                  </React.Fragment>
              )}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-[13px] text-ink-500">
            {colors.length * sizes.length} variants · <span className="font-medium tabular-nums text-ink">{total}</span> units in stock
          </p>
        </>
      }
    </div>);

}