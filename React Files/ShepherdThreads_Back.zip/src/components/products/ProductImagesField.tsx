import React from 'react';
import { Reorder } from 'framer-motion';
import { XIcon } from 'lucide-react';
import { ImageDropzone } from '../ui/ImageDropzone';

interface ProductImagesFieldProps {
  images: string[];
  onChange: (images: string[]) => void;
}

export function ProductImagesField({ images, onChange }: ProductImagesFieldProps) {
  return (
    <div>
      {images.length > 0 &&
      <Reorder.Group axis="x" values={images} onReorder={onChange} className="flex gap-3 overflow-x-auto pb-2">
          {images.map((src, i) =>
        <Reorder.Item
          key={src}
          value={src}
          className="group relative h-28 w-28 shrink-0 cursor-grab overflow-hidden rounded-md border border-line bg-cream active:cursor-grabbing"
          whileDrag={{ scale: 1.04, boxShadow: '0 14px 30px -14px rgba(10,10,10,0.35)', zIndex: 10 }}>
          
              <img src={src} alt={`Product image ${i + 1}`} draggable={false} className="pointer-events-none h-full w-full object-cover" />
              {i === 0 &&
          <span className="absolute bottom-1.5 left-1.5 rounded bg-ink/85 px-1.5 py-0.5 text-[10px] font-medium text-white">
                  Cover
                </span>
          }
              <button
            type="button"
            aria-label={`Remove image ${i + 1}`}
            onPointerDown={(e) => e.stopPropagation()}
            onClick={() => onChange(images.filter((x) => x !== src))}
            className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-white/95 text-ink opacity-0 shadow-sm transition-opacity duration-150 focus:opacity-100 group-hover:opacity-100">
            
                <XIcon className="h-3.5 w-3.5" />
              </button>
            </Reorder.Item>
        )}
        </Reorder.Group>
      }
      <ImageDropzone className="mt-2" onFiles={(urls) => onChange([...images, ...urls])} />
    </div>);

}