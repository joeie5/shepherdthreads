import React, { useState } from 'react';
import { toast } from 'sonner';
import { Panel } from '../ui/Panel';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Toggle } from '../ui/Toggle';
import { RadioGroup } from '../ui/RadioGroup';
import { SaveFooter } from './SaveFooter';
import { paymentGateways } from '../../data/siteSettings';

export function PaymentSettings() {
  const [gateways, setGateways] = useState(paymentGateways);
  const [testMode, setTestMode] = useState(false);
  const [capture, setCapture] = useState('auto');

  const toggleConnect = (id: string) => {
    const g = gateways.find((x) => x.id === id)!;
    setGateways((prev) => prev.map((x) => x.id === id ? { ...x, connected: !x.connected, account: !x.connected ? 'Connected just now' : '' } : x));
    toast.success(g.connected ? `${g.name} disconnected` : `${g.name} connected`);
  };

  return (
    <div className="space-y-6">
      <Panel title="Payment providers" description="How customers pay on web, iOS, and Android." padded={false}>
        <ul>
          {gateways.map((g) =>
          <li key={g.id} className="flex flex-wrap items-center gap-4 border-b border-line px-5 py-4 last:border-b-0">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md border border-line bg-cream text-[13px] font-semibold text-ink">{g.name.slice(0, 2)}</span>
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-2 text-sm font-medium text-ink">
                  {g.name}
                  {g.connected ? <Badge tone="success" dot>Connected</Badge> : <Badge>Not connected</Badge>}
                </p>
                <p className="text-[13px] text-ink-500">{g.description}</p>
                {g.connected && g.account && <p className="mt-0.5 font-mono text-xs text-ink-600">{g.account}</p>}
              </div>
              {g.connected ?
            <div className="flex gap-2">
                  <Button size="sm" onClick={() => toast(`Opening ${g.name} dashboard`)}>
                    Manage
                  </Button>
                  <Button size="sm" variant="danger" onClick={() => toggleConnect(g.id)}>
                    Disconnect
                  </Button>
                </div> :

            <Button size="sm" variant="primary" onClick={() => toggleConnect(g.id)}>
                  Connect
                </Button>
            }
            </li>
          )}
        </ul>
      </Panel>

      <Panel title="Checkout behavior">
        <div className="space-y-5">
          <div>
            <p className="mb-2 text-sm font-medium text-ink">Payment capture</p>
            <RadioGroup
              name="capture"
              ariaLabel="Payment capture"
              value={capture}
              onChange={setCapture}
              options={[
              { value: 'auto', label: 'Automatically when an order is placed', description: 'Recommended for in-stock items' },
              { value: 'manual', label: 'Manually when fulfilling', description: 'Useful for pre-orders and custom church orders' }]
              } />
            
          </div>
          <div className="border-t border-line pt-5">
            <Toggle label="Test mode" description="Process fake payments to try checkout without charging cards." checked={testMode} onChange={setTestMode} />
          </div>
        </div>
      </Panel>
      <SaveFooter label="Payment settings saved" />
    </div>);

}