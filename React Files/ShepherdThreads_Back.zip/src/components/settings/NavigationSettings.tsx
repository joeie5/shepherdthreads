import React, { useState } from 'react';
import { Reorder } from 'framer-motion';
import { ChevronLeftIcon, ChevronRightIcon, PlusIcon, Trash2Icon } from 'lucide-react';
import { Panel } from '../ui/Panel';
import { Button } from '../ui/Button';
import { DragHandle } from '../ui/DragHandle';
import { SortableItem } from '../ui/SortableItem';
import { SaveFooter } from './SaveFooter';
import { headerMenu } from '../../data/siteSettings';
import type { MenuLink } from '../../types/admin';
import { cn } from '../../utils/cn';
import { inputBase } from '../../utils/styles';

export function NavigationSettings() {
  const [items, setItems] = useState<MenuLink[]>(headerMenu);
  const update = (id: string, patch: Partial<MenuLink>) => setItems((prev) => prev.map((i) => i.id === id ? { ...i, ...patch } : i));
  const topLevel = items.filter((i) => !i.nested);

  return (
    <div className="space-y-6">
      <Panel title="Menu preview" description="How the header menu looks on the storefront. The app uses the same order in its side menu." padded={false}>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 bg-white px-5 py-4">
          <span className="mr-4 font-serif text-sm font-semibold tracking-[0.16em] text-ink">SHEPHERDS THREAD</span>
          {topLevel.map((i) =>
          <span key={i.id} className="text-xs font-medium uppercase tracking-[0.12em] text-ink">
              {i.label || 'Untitled'}
            </span>
          )}
        </div>
      </Panel>

      <Panel
        title="Header menu"
        description="Drag to reorder. Indent an item to place it in the dropdown under the item above."
        actions={
        <Button size="sm" icon={PlusIcon} onClick={() => setItems([...items, { id: `n-${Date.now()}`, label: 'New link', link: '/', nested: false }])}>
            Add link
          </Button>
        }
        padded={false}>
        
        <div className="hidden grid-cols-[24px_minmax(0,1fr)_minmax(0,1fr)_72px] gap-3 border-b border-line bg-canvas px-4 py-2 text-xs font-medium text-ink-500 sm:grid">
          <span />
          <span>Label</span>
          <span>Link</span>
          <span />
        </div>
        <Reorder.Group axis="y" values={items} onReorder={setItems}>
          {items.map((item, idx) =>
          <SortableItem key={item.id} value={item} className="border-b border-line bg-white last:border-b-0">
              {(startDrag) =>
            <div className={cn('grid grid-cols-[24px_minmax(0,1fr)_72px] items-center gap-3 px-4 py-2.5 sm:grid-cols-[24px_minmax(0,1fr)_minmax(0,1fr)_72px]')}>
                  <DragHandle onPointerDown={startDrag} label={`Reorder ${item.label}`} />
                  <div className={cn('flex items-center gap-2', item.nested && 'pl-6')}>
                    {item.nested && <span className="h-px w-3 bg-line-strong" aria-hidden />}
                    <input aria-label="Menu label" value={item.label} onChange={(e) => update(item.id, { label: e.target.value })} className={cn(inputBase, 'h-8 px-2.5 text-[13px]')} />
                  </div>
                  <input aria-label="Menu link" value={item.link} onChange={(e) => update(item.id, { link: e.target.value })} className={cn(inputBase, 'hidden h-8 px-2.5 font-mono text-xs sm:block')} />
                  <div className="flex justify-end gap-0.5">
                    <Button
                  variant="ghost"
                  size="sm"
                  icon={item.nested ? ChevronLeftIcon : ChevronRightIcon}
                  aria-label={item.nested ? 'Move out of dropdown' : 'Move into dropdown'}
                  disabled={idx === 0}
                  onClick={() => update(item.id, { nested: !item.nested })} />
                
                    <Button variant="ghost" size="sm" icon={Trash2Icon} aria-label={`Delete ${item.label}`} onClick={() => setItems(items.filter((i) => i.id !== item.id))} />
                  </div>
                </div>
            }
            </SortableItem>
          )}
        </Reorder.Group>
      </Panel>
      <SaveFooter label="Menu saved" />
    </div>);

}