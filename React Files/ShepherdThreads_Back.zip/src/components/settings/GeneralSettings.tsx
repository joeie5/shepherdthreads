import React, { useState } from 'react';
import { RefreshCwIcon } from 'lucide-react';
import { Panel } from '../ui/Panel';
import { Field } from '../ui/Field';
import { TextInput } from '../ui/TextInput';
import { Select } from '../ui/Select';
import { SaveFooter } from './SaveFooter';

function UploadButton({ label, onFile }: {label: string;onFile: (url: string) => void;}) {
  return (
    <label className="inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md border border-line-strong bg-white px-2.5 text-[13px] font-medium text-ink hover:bg-canvas">
      <RefreshCwIcon className="h-3.5 w-3.5" />
      {label}
      <input type="file" accept="image/*" className="sr-only" onChange={(e) => e.target.files?.[0] && onFile(URL.createObjectURL(e.target.files[0]))} />
    </label>);

}

export function GeneralSettings() {
  const [store, setStore] = useState({
    name: 'Shepherds Thread',
    tagline: 'Faith, woven in.',
    email: 'hello@shepherdsthread.co',
    phone: '(615) 555-0100',
    hours: 'Mon–Fri, 9am–5pm CT',
    address: '118 Main St, Suite 4, Franklin, TN 37064',
    currency: 'USD',
    timezone: 'America/Chicago'
  });
  const [logo, setLogo] = useState('');
  const [favicon, setFavicon] = useState('');
  const set = (k: keyof typeof store, v: string) => setStore((s) => ({ ...s, [k]: v }));

  return (
    <div className="space-y-6">
      <Panel title="Store details" description="Shown in emails, receipts, and the app’s contact screen.">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Store name" htmlFor="g-name">
            <TextInput id="g-name" value={store.name} onChange={(e) => set('name', e.target.value)} />
          </Field>
          <Field label="Tagline" htmlFor="g-tag">
            <TextInput id="g-tag" value={store.tagline} onChange={(e) => set('tagline', e.target.value)} />
          </Field>
          <Field label="Contact email" htmlFor="g-email">
            <TextInput id="g-email" type="email" value={store.email} onChange={(e) => set('email', e.target.value)} />
          </Field>
          <Field label="Phone" htmlFor="g-phone">
            <TextInput id="g-phone" type="tel" value={store.phone} onChange={(e) => set('phone', e.target.value)} />
          </Field>
          <Field label="Support hours" htmlFor="g-hours">
            <TextInput id="g-hours" value={store.hours} onChange={(e) => set('hours', e.target.value)} />
          </Field>
          <Field label="Business address" htmlFor="g-addr">
            <TextInput id="g-addr" value={store.address} onChange={(e) => set('address', e.target.value)} />
          </Field>
        </div>
      </Panel>

      <Panel title="Logo & favicon">
        <div className="grid gap-6 sm:grid-cols-2">
          <div>
            <p className="mb-2 text-[13px] font-medium text-ink">Logo</p>
            <div className="grid grid-cols-2 overflow-hidden rounded-md border border-line">
              <div className="flex h-24 items-center justify-center bg-cream">
                {logo ? <img src={logo} alt="Logo on light" className="max-h-12" /> : <span className="font-serif text-lg font-semibold tracking-[0.16em] text-ink">SHEPHERDS THREAD</span>}
              </div>
              <div className="flex h-24 items-center justify-center bg-ink">
                {logo ? <img src={logo} alt="Logo on dark" className="max-h-12" /> : <span className="font-serif text-lg font-semibold tracking-[0.16em] text-cream">SHEPHERDS THREAD</span>}
              </div>
            </div>
            <div className="mt-3 flex items-center gap-3">
              <UploadButton label="Replace logo" onFile={setLogo} />
              <span className="text-xs text-ink-500">SVG or PNG, transparent background</span>
            </div>
          </div>
          <div>
            <p className="mb-2 text-[13px] font-medium text-ink">Favicon</p>
            <div className="flex h-24 items-center gap-4 rounded-md border border-line bg-canvas px-5">
              <span className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-md bg-ink">
                {favicon ? <img src={favicon} alt="Favicon" className="h-full w-full object-cover" /> : <span className="font-serif text-sm font-semibold text-cream">ST</span>}
              </span>
              <div className="flex h-8 items-center gap-2 rounded-t-md border border-b-0 border-line bg-white px-3 text-xs text-ink-600">
                <span className="h-3.5 w-3.5 rounded-sm bg-ink" />
                Shepherds Thread
              </div>
            </div>
            <div className="mt-3 flex items-center gap-3">
              <UploadButton label="Replace favicon" onFile={setFavicon} />
              <span className="text-xs text-ink-500">Square, at least 512 × 512</span>
            </div>
          </div>
        </div>
      </Panel>

      <Panel title="Regional">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Store currency" htmlFor="g-cur">
            <Select id="g-cur" value={store.currency} onChange={(e) => set('currency', e.target.value)} options={[{ value: 'USD', label: 'US Dollar (USD $)' }, { value: 'CAD', label: 'Canadian Dollar (CAD $)' }]} />
          </Field>
          <Field label="Time zone" htmlFor="g-tz">
            <Select
              id="g-tz"
              value={store.timezone}
              onChange={(e) => set('timezone', e.target.value)}
              options={[
              { value: 'America/Chicago', label: '(GMT-06:00) Central Time' },
              { value: 'America/New_York', label: '(GMT-05:00) Eastern Time' },
              { value: 'America/Los_Angeles', label: '(GMT-08:00) Pacific Time' }]
              } />
            
          </Field>
        </div>
      </Panel>

      <SaveFooter label="Store details saved" />
    </div>);

}