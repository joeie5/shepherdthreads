import React, { useState } from 'react';
import { PlusIcon, Trash2Icon } from 'lucide-react';
import { Panel } from '../ui/Panel';
import { Toggle } from '../ui/Toggle';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { SaveFooter } from './SaveFooter';
import { shippingZones } from '../../data/siteSettings';
import { cn } from '../../utils/cn';
import { inputBase } from '../../utils/styles';

export function ShippingTaxSettings() {
  const [zones, setZones] = useState(shippingZones);
  const [tax, setTax] = useState({ auto: true, inclusive: false, shipping: true });
  const cell = cn(inputBase, 'h-8 px-2 text-[13px]');

  type Rate = (typeof shippingZones)[number]['rates'][number];
  const updateRate = (zoneId: string, idx: number, patch: Partial<Rate>) =>
  setZones((prev) => prev.map((z) => z.id === zoneId ? { ...z, rates: z.rates.map((r, i) => i === idx ? { ...r, ...patch } : r) } : z));

  return (
    <div className="space-y-6">
      {zones.map((z) =>
      <Panel
        key={z.id}
        title={z.name}
        description={z.countries}
        padded={false}
        actions={
        <Button size="sm" icon={PlusIcon} onClick={() => setZones((prev) => prev.map((x) => x.id === z.id ? { ...x, rates: [...x.rates, { name: 'New rate', price: 0, freeOver: null }] } : x))}>
              Add rate
            </Button>
        }>
        
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-ink-500">
                  <th className="h-9 border-b border-line px-5 font-medium">Rate name</th>
                  <th className="h-9 border-b border-line px-3 font-medium">Price</th>
                  <th className="h-9 border-b border-line px-3 font-medium">Free when order is over</th>
                  <th className="h-9 w-12 border-b border-line" />
                </tr>
              </thead>
              <tbody>
                {z.rates.map((r, i) =>
              <tr key={i}>
                    <td className="border-b border-line px-5 py-2">
                      <input aria-label="Rate name" value={r.name} onChange={(e) => updateRate(z.id, i, { name: e.target.value })} className={cn(cell, 'min-w-[180px]')} />
                    </td>
                    <td className="border-b border-line px-3 py-2">
                      <div className="relative w-24">
                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[13px] text-ink-500">$</span>
                        <input type="number" aria-label="Price" value={r.price} onChange={(e) => updateRate(z.id, i, { price: Number(e.target.value) })} className={cn(cell, 'pl-5 tabular-nums')} />
                      </div>
                    </td>
                    <td className="border-b border-line px-3 py-2">
                      <div className="relative w-28">
                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[13px] text-ink-500">$</span>
                        <input
                      type="number"
                      aria-label="Free shipping threshold"
                      placeholder="Never"
                      value={r.freeOver ?? ''}
                      onChange={(e) => updateRate(z.id, i, { freeOver: e.target.value ? Number(e.target.value) : null })}
                      className={cn(cell, 'pl-5 tabular-nums')} />
                    
                      </div>
                    </td>
                    <td className="border-b border-line pr-3 text-right">
                      <Button
                    variant="ghost"
                    size="sm"
                    icon={Trash2Icon}
                    aria-label={`Delete ${r.name}`}
                    onClick={() => setZones((prev) => prev.map((x) => x.id === z.id ? { ...x, rates: x.rates.filter((_, j) => j !== i) } : x))} />
                  
                    </td>
                  </tr>
              )}
              </tbody>
            </table>
          </div>
        </Panel>
      )}

      <Panel title="Taxes">
        <div className="space-y-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="flex items-center gap-2 text-sm font-medium text-ink">
                Automatic tax calculation <Badge tone="success">Stripe Tax</Badge>
              </p>
              <p className="mt-0.5 text-[13px] text-ink-500">Calculates sales tax by address for all US states where you’re registered.</p>
            </div>
            <Toggle srLabel="Automatic tax calculation" checked={tax.auto} onChange={(v) => setTax({ ...tax, auto: v })} />
          </div>
          <Toggle label="Prices include tax" description="Turn on if your listed prices already include sales tax." checked={tax.inclusive} onChange={(v) => setTax({ ...tax, inclusive: v })} />
          <Toggle label="Charge tax on shipping" description="Required in some states, including Tennessee." checked={tax.shipping} onChange={(v) => setTax({ ...tax, shipping: v })} />
          <div className="rounded-md bg-canvas p-4">
            <p className="text-[13px] font-medium text-ink">Registered in</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {['Tennessee', 'Georgia', 'Texas', 'California'].map((s) =>
              <Badge key={s}>{s}</Badge>
              )}
            </div>
          </div>
        </div>
      </Panel>
      <SaveFooter label="Shipping & tax saved" />
    </div>);

}