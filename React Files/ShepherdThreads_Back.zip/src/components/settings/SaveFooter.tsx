import React from 'react';
import { toast } from 'sonner';
import { Button } from '../ui/Button';

export function SaveFooter({ label = 'Settings saved' }: {label?: string;}) {
  return (
    <div className="flex justify-end border-t border-line pt-5">
      <Button variant="primary" onClick={() => toast.success(label, { description: 'Changes sync to web and mobile apps.' })}>
        Save changes
      </Button>
    </div>);

}