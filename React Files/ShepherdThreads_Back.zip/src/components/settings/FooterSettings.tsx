import React, { useState } from 'react';
import { PlusIcon, XIcon } from 'lucide-react';
import { Panel } from '../ui/Panel';
import { Field } from '../ui/Field';
import { TextInput } from '../ui/TextInput';
import { TextArea } from '../ui/TextArea';
import { Toggle } from '../ui/Toggle';
import { Button } from '../ui/Button';
import { SaveFooter } from './SaveFooter';
import { footerColumns, socialLinks } from '../../data/siteSettings';
import { cn } from '../../utils/cn';
import { inputBase } from '../../utils/styles';

export function FooterSettings() {
  const [verse, setVerse] = useState({ text: 'I am the good shepherd. The good shepherd lays down his life for the sheep.', ref: 'John 10:11', month: 'November 2026' });
  const [columns, setColumns] = useState(footerColumns);
  const [socials, setSocials] = useState(socialLinks);
  const [newsletter, setNewsletter] = useState(true);
  const cell = cn(inputBase, 'h-8 px-2.5 text-[13px]');

  const updateLink = (colId: string, linkId: string, patch: {label?: string;link?: string;}) =>
  setColumns((prev) => prev.map((c) => c.id === colId ? { ...c, links: c.links.map((l) => l.id === linkId ? { ...l, ...patch } : l) } : c));

  return (
    <div className="space-y-6">
      <Panel title="Verse of the month" description="Shown in the footer of every page and on the app’s home screen.">
        <div className="grid gap-6 md:grid-cols-[minmax(0,1fr)_280px]">
          <div className="space-y-4">
            <Field label="Verse" htmlFor="v-text">
              <TextArea id="v-text" rows={3} value={verse.text} onChange={(e) => setVerse({ ...verse, text: e.target.value })} />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Reference" htmlFor="v-ref">
                <TextInput id="v-ref" value={verse.ref} onChange={(e) => setVerse({ ...verse, ref: e.target.value })} />
              </Field>
              <Field label="Month" htmlFor="v-month">
                <TextInput id="v-month" value={verse.month} onChange={(e) => setVerse({ ...verse, month: e.target.value })} />
              </Field>
            </div>
          </div>
          <figure className="flex flex-col justify-center rounded-md bg-ink p-5">
            <blockquote className="font-serif text-lg italic leading-snug text-white/90">“{verse.text}”</blockquote>
            <figcaption className="mt-3 text-xs text-white/60">
              — {verse.ref} · {verse.month}
            </figcaption>
          </figure>
        </div>
      </Panel>

      <Panel title="Footer links">
        <div className="grid gap-5 md:grid-cols-3">
          {columns.map((col) =>
          <div key={col.id} className="space-y-2">
              <input
              aria-label="Column title"
              value={col.title}
              onChange={(e) => setColumns((prev) => prev.map((c) => c.id === col.id ? { ...c, title: e.target.value } : c))}
              className={cn(cell, 'font-semibold')} />
            
              {col.links.map((l) =>
            <div key={l.id} className="space-y-1 rounded-md border border-line p-2">
                  <div className="flex gap-1">
                    <input aria-label="Link label" value={l.label} onChange={(e) => updateLink(col.id, l.id, { label: e.target.value })} className={cell} />
                    <Button
                  variant="ghost"
                  size="sm"
                  icon={XIcon}
                  aria-label={`Remove ${l.label}`}
                  onClick={() => setColumns((prev) => prev.map((c) => c.id === col.id ? { ...c, links: c.links.filter((x) => x.id !== l.id) } : c))} />
                
                  </div>
                  <input aria-label="Link URL" value={l.link} onChange={(e) => updateLink(col.id, l.id, { link: e.target.value })} className={cn(cell, 'font-mono text-xs text-ink-600')} />
                </div>
            )}
              <Button
              size="sm"
              variant="ghost"
              icon={PlusIcon}
              onClick={() => setColumns((prev) => prev.map((c) => c.id === col.id ? { ...c, links: [...c.links, { id: `fl-${Date.now()}`, label: 'New link', link: '/' }] } : c))}>
              
                Add link
              </Button>
            </div>
          )}
        </div>
      </Panel>

      <Panel title="Social profiles">
        <ul className="divide-y divide-line">
          {socials.map((s) =>
          <li key={s.id} className="flex items-center gap-3 py-2.5 first:pt-0 last:pb-0">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-cream text-[11px] font-semibold text-ink-600">{s.label.slice(0, 2)}</span>
              <span className="w-24 shrink-0 text-sm text-ink">{s.label}</span>
              <input
              aria-label={`${s.label} URL`}
              value={s.url}
              placeholder={`https://${s.id}.com/…`}
              onChange={(e) => setSocials((prev) => prev.map((x) => x.id === s.id ? { ...x, url: e.target.value } : x))}
              className={cn(cell, 'min-w-0 flex-1')} />
            
              <Toggle srLabel={`Show ${s.label} icon`} checked={s.enabled} onChange={(v) => setSocials((prev) => prev.map((x) => x.id === s.id ? { ...x, enabled: v } : x))} />
            </li>
          )}
        </ul>
        <div className="mt-5 border-t border-line pt-4">
          <Toggle label="Show newsletter signup in footer" checked={newsletter} onChange={setNewsletter} />
        </div>
      </Panel>
      <SaveFooter label="Footer saved" />
    </div>);

}