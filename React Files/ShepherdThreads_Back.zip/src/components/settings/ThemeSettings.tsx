import React, { useEffect, useState } from 'react';
import { RotateCcwIcon } from 'lucide-react';
import { Panel } from '../ui/Panel';
import { Field } from '../ui/Field';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { SegmentedControl } from '../ui/SegmentedControl';
import { SaveFooter } from './SaveFooter';
import { brandPalette, fontOptions } from '../../data/siteSettings';

type Radius = 'square' | 'soft' | 'round';
const radiusPx: Record<Radius, string> = { square: '0px', soft: '6px', round: '999px' };

export function ThemeSettings() {
  const [palette, setPalette] = useState(brandPalette);
  const [headingFont, setHeadingFont] = useState('Cormorant Garamond');
  const [bodyFont, setBodyFont] = useState('Inter');
  const [radius, setRadius] = useState<Radius>('square');

  useEffect(() => {
    const id = 'theme-preview-fonts';
    let link = document.getElementById(id) as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement('link');
      link.id = id;
      link.rel = 'stylesheet';
      document.head.appendChild(link);
    }
    const fam = [headingFont, bodyFont].map((f) => `family=${f.replace(/ /g, '+')}:wght@400;600`).join('&');
    link.href = `https://fonts.googleapis.com/css2?${fam}&display=swap`;
  }, [headingFont, bodyFont]);

  const color = (id: string) => palette.find((p) => p.id === id)?.value ?? '#000';
  const setColor = (id: string, value: string) => setPalette((prev) => prev.map((p) => p.id === id ? { ...p, value } : p));

  return (
    <div className="space-y-6">
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-6">
          <Panel
            title="Color palette"
            description="Applied across the storefront and mobile apps."
            actions={
            <Button size="sm" variant="ghost" icon={RotateCcwIcon} onClick={() => setPalette(brandPalette)}>
                Reset to brand
              </Button>
            }>
            
            <ul className="divide-y divide-line">
              {palette.map((p) =>
              <li key={p.id} className="flex items-center gap-4 py-3 first:pt-0 last:pb-0">
                  <label className="relative h-10 w-10 shrink-0 cursor-pointer overflow-hidden rounded-md border border-line-strong" style={{ background: p.value }}>
                    <span className="sr-only">Pick {p.label}</span>
                    <input type="color" value={p.value} onChange={(e) => setColor(p.id, e.target.value.toUpperCase())} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" />
                  </label>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-ink">{p.label}</p>
                    <p className="text-xs text-ink-500">Brand default {brandPalette.find((b) => b.id === p.id)?.value}</p>
                  </div>
                  <input
                  aria-label={`${p.label} hex value`}
                  value={p.value}
                  onChange={(e) => setColor(p.id, e.target.value)}
                  className="h-8 w-24 rounded-md border border-line-strong px-2 font-mono text-xs uppercase text-ink focus:border-ink focus:outline-none" />
                
                </li>
              )}
            </ul>
          </Panel>

          <Panel title="Typography & buttons">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Heading font" htmlFor="t-head">
                <Select id="t-head" value={headingFont} onChange={(e) => setHeadingFont(e.target.value)} options={fontOptions} />
              </Field>
              <Field label="Body font" htmlFor="t-body">
                <Select id="t-body" value={bodyFont} onChange={(e) => setBodyFont(e.target.value)} options={fontOptions} />
              </Field>
            </div>
            <div className="mt-4">
              <p className="mb-1.5 text-[13px] font-medium text-ink">Button corners</p>
              <SegmentedControl<Radius>
                ariaLabel="Button corners"
                value={radius}
                onChange={setRadius}
                options={[
                { value: 'square', label: 'Square' },
                { value: 'soft', label: 'Soft' },
                { value: 'round', label: 'Pill' }]
                } />
              
            </div>
          </Panel>
        </div>

        <aside className="xl:sticky xl:top-6 xl:self-start">
          <Panel title="Live preview" padded={false}>
            <div style={{ background: color('background'), fontFamily: `'${bodyFont}', sans-serif` }} className="rounded-b-lg">
              <div className="flex items-center justify-between border-b px-5 py-3" style={{ borderColor: color('surface') }}>
                <span style={{ fontFamily: `'${headingFont}', serif`, color: color('primary') }} className="text-sm font-semibold tracking-[0.16em]">
                  SHEPHERDS THREAD
                </span>
                <span className="text-[11px]" style={{ color: color('muted') }}>
                  Shop · Journal
                </span>
              </div>
              <div className="px-5 py-6" style={{ background: color('surface') }}>
                <p className="text-[11px] font-medium uppercase tracking-[0.16em]" style={{ color: color('accent') }}>
                  New season
                </p>
                <p style={{ fontFamily: `'${headingFont}', serif`, color: color('primary') }} className="mt-2 text-3xl font-semibold leading-tight">
                  Faith, woven in.
                </p>
                <p className="mt-2 text-[13px]" style={{ color: color('muted') }}>
                  Heavyweight layers for the season of gathering.
                </p>
                <span
                  className="mt-4 inline-block px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.14em]"
                  style={{ background: color('primary'), color: color('background'), borderRadius: radiusPx[radius] }}>
                  
                  Shop Harvest
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 p-5">
                {['Faithful Tee', 'Grace Hoodie'].map((n, i) =>
                <div key={n}>
                    <div className="aspect-[4/5]" style={{ background: i ? color('surface') : color('primary') }} />
                    <p className="mt-2 text-xs" style={{ color: color('primary') }}>
                      {n}
                    </p>
                    <p className="text-xs" style={{ color: color('muted') }}>
                      {i ? '$78' : '$38'}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </Panel>
        </aside>
      </div>
      <SaveFooter label="Theme saved" />
    </div>);

}