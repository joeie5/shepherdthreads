import React from 'react';
import { useNavigate } from 'react-router-dom';
import type { Order } from '../../types/sales';
import { Badge } from '../ui/Badge';
import { Checkbox } from '../ui/Checkbox';
import { cn } from '../../utils/cn';
import { formatCurrency, formatDate } from '../../utils/format';
import { fulfillmentMeta, paymentMeta } from '../../utils/status';
import { rowClass, tableClass, tdClass, thClass } from '../../utils/styles';

interface OrdersTableProps {
  orders: Order[];
  compact?: boolean;
  selected?: string[];
  onSelectedChange?: (ids: string[]) => void;
}

export function OrdersTable({ orders, compact = false, selected, onSelectedChange }: OrdersTableProps) {
  const navigate = useNavigate();
  const selectable = !!selected && !!onSelectedChange;
  const allSelected = selectable && orders.length > 0 && orders.every((o) => selected.includes(o.id));
  const someSelected = selectable && !allSelected && orders.some((o) => selected.includes(o.id));

  const toggle = (id: string) => {
    if (!selected || !onSelectedChange) return;
    onSelectedChange(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id]);
  };

  return (
    <div className="overflow-x-auto">
      <table className={tableClass}>
        <thead>
          <tr>
            {selectable &&
            <th className={cn(thClass, 'w-10 pr-0')}>
                <Checkbox
                aria-label="Select all orders"
                checked={allSelected}
                indeterminate={someSelected}
                onChange={() => onSelectedChange!(allSelected ? [] : orders.map((o) => o.id))} />
              
              </th>
            }
            <th className={thClass}>Order</th>
            <th className={thClass}>Date</th>
            <th className={thClass}>Customer</th>
            {!compact && <th className={cn(thClass, 'hidden xl:table-cell')}>Channel</th>}
            <th className={cn(thClass, 'text-right')}>Total</th>
            <th className={thClass}>Payment</th>
            <th className={thClass}>Fulfillment</th>
            {!compact && <th className={cn(thClass, 'hidden lg:table-cell')}>Items</th>}
          </tr>
        </thead>
        <tbody>
          {orders.map((o) => {
            const pay = paymentMeta[o.payment];
            const ful = fulfillmentMeta[o.fulfillment];
            const isSelected = selected?.includes(o.id);
            return (
              <tr
                key={o.id}
                onClick={() => navigate(`/orders/${o.id}`)}
                className={cn(rowClass, isSelected && 'bg-brass-soft/50 hover:bg-brass-soft/70')}>
                
                {selectable &&
                <td className={cn(tdClass, 'w-10 pr-0')}>
                    <Checkbox aria-label={`Select ${o.number}`} checked={!!isSelected} onChange={() => toggle(o.id)} />
                  </td>
                }
                <td className={cn(tdClass, 'whitespace-nowrap font-medium text-ink')}>{o.number}</td>
                <td className={cn(tdClass, 'whitespace-nowrap text-ink-600')}>
                  {formatDate(o.date, compact ? 'MMM d, h:mm a' : 'MMM d, yyyy · h:mm a')}
                </td>
                <td className={cn(tdClass, 'whitespace-nowrap text-ink')}>{o.customerName}</td>
                {!compact && <td className={cn(tdClass, 'hidden text-ink-600 xl:table-cell')}>{o.channel}</td>}
                <td className={cn(tdClass, 'whitespace-nowrap text-right font-medium tabular-nums text-ink')}>
                  {formatCurrency(o.total)}
                </td>
                <td className={tdClass}>
                  <Badge tone={pay.tone} dot>
                    {pay.label}
                  </Badge>
                </td>
                <td className={tdClass}>
                  <Badge tone={ful.tone} dot>
                    {ful.label}
                  </Badge>
                </td>
                {!compact &&
                <td className={cn(tdClass, 'hidden whitespace-nowrap text-ink-600 lg:table-cell')}>
                    {o.items.reduce((s, i) => s + i.qty, 0)} items
                  </td>
                }
              </tr>);

          })}
        </tbody>
      </table>
    </div>);

}