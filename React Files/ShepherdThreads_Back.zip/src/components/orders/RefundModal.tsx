import React, { useState } from 'react';
import type { Order } from '../../types/sales';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Checkbox } from '../ui/Checkbox';
import { Select } from '../ui/Select';
import { Field } from '../ui/Field';
import { TextInput } from '../ui/TextInput';
import { formatCurrency } from '../../utils/format';

interface RefundModalProps {
  order: Order;
  open: boolean;
  onClose: () => void;
  onRefund: (amount: number, full: boolean) => void;
}

export function RefundModal({ order, open, onClose, onRefund }: RefundModalProps) {
  const [picked, setPicked] = useState<string[]>(order.items.map((i) => i.sku));
  const [includeShipping, setIncludeShipping] = useState(true);
  const [restock, setRestock] = useState(true);
  const [reason, setReason] = useState('customer');

  const itemsTotal = order.items.filter((i) => picked.includes(i.sku)).reduce((s, i) => s + i.qty * i.price, 0);
  const ratio = order.subtotal ? itemsTotal / order.subtotal : 0;
  const amount = itemsTotal - order.discount * ratio + order.tax * ratio + (includeShipping ? order.shipping : 0);
  const full = picked.length === order.items.length && includeShipping;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={`Refund ${order.number}`}
      description="Money returns to the original payment method in 5–10 business days."
      footer={
      <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" disabled={amount <= 0} onClick={() => onRefund(Number(amount.toFixed(2)), full)}>
            Refund {formatCurrency(Math.max(0, amount))}
          </Button>
        </>
      }>
      
      <div className="space-y-4">
        <ul className="divide-y divide-line rounded-md border border-line">
          {order.items.map((i) =>
          <li key={i.sku}>
              <label className="flex cursor-pointer items-center gap-3 px-3 py-2.5">
                <Checkbox
                checked={picked.includes(i.sku)}
                onChange={() => setPicked((p) => p.includes(i.sku) ? p.filter((x) => x !== i.sku) : [...p, i.sku])} />
              
                <img src={i.image} alt="" className="h-9 w-9 rounded border border-line object-cover" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px] font-medium text-ink">{i.name}</span>
                  <span className="block text-xs text-ink-500">
                    {i.variant} · Qty {i.qty}
                  </span>
                </span>
                <span className="text-[13px] tabular-nums text-ink">{formatCurrency(i.qty * i.price)}</span>
              </label>
            </li>
          )}
        </ul>
        <div className="flex flex-col gap-2">
          {order.shipping > 0 &&
          <Checkbox label={`Refund shipping (${formatCurrency(order.shipping)})`} checked={includeShipping} onChange={(e) => setIncludeShipping(e.target.checked)} />
          }
          <Checkbox label="Restock refunded items" checked={restock} onChange={(e) => setRestock(e.target.checked)} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Reason" htmlFor="refund-reason">
            <Select
              id="refund-reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              options={[
              { value: 'customer', label: 'Customer request' },
              { value: 'size', label: 'Wrong size' },
              { value: 'damaged', label: 'Damaged item' },
              { value: 'oos', label: 'Out of stock' },
              { value: 'other', label: 'Other' }]
              } />
            
          </Field>
          <Field label="Refund amount" htmlFor="refund-amount">
            <TextInput id="refund-amount" leading="$" readOnly value={Math.max(0, amount).toFixed(2)} className="tabular-nums" />
          </Field>
        </div>
      </div>
    </Modal>);

}