import React from 'react';
import { ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
import { Button } from './Button';

interface PaginationProps {
  showing: number;
  total: number;
  label: string;
}

export function Pagination({ showing, total, label }: PaginationProps) {
  return (
    <div className="flex items-center justify-between gap-4 px-4 py-3 text-[13px] text-ink-500">
      <span className="tabular-nums">
        Showing {showing} of {total} {label}
      </span>
      <div className="flex gap-1">
        <Button size="sm" icon={ChevronLeftIcon} aria-label="Previous page" disabled />
        <Button size="sm" icon={ChevronRightIcon} aria-label="Next page" disabled={showing >= total} />
      </div>
    </div>);

}