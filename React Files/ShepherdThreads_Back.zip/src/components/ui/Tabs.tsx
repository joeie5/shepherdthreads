import React from 'react';
import { cn } from '../../utils/cn';

export interface TabItem {
  id: string;
  label: string;
  count?: number;
}

interface TabsProps {
  tabs: TabItem[];
  value: string;
  onChange: (id: string) => void;
  className?: string;
}

export function Tabs({ tabs, value, onChange, className }: TabsProps) {
  return (
    <div role="tablist" className={cn('flex gap-6 overflow-x-auto border-b border-line', className)}>
      {tabs.map((tab) => {
        const selected = tab.id === value;
        return (
          <button
            key={tab.id}
            role="tab"
            type="button"
            aria-selected={selected}
            onClick={() => onChange(tab.id)}
            className={cn(
              '-mb-px flex items-center whitespace-nowrap border-b-2 pb-2.5 pt-1 text-sm font-medium transition-colors duration-150',
              selected ? 'border-ink text-ink' : 'border-transparent text-ink-500 hover:text-ink'
            )}>
            
            {tab.label}
            {tab.count !== undefined &&
            <span
              className={cn(
                'ml-1.5 rounded-full px-1.5 text-xs tabular-nums',
                selected ? 'bg-ink text-white' : 'bg-black/[0.05] text-ink-500'
              )}>
              
                {tab.count}
              </span>
            }
          </button>);

      })}
    </div>);

}