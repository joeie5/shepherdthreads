import React from 'react';
import { cn } from '../../utils/cn';

interface FieldProps {
  label: string;
  htmlFor?: string;
  hint?: string;
  error?: string;
  optional?: boolean;
  aside?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

export function Field({ label, htmlFor, hint, error, optional, aside, children, className }: FieldProps) {
  return (
    <div className={cn('space-y-1.5', className)}>
      <div className="flex items-center justify-between gap-2">
        <label htmlFor={htmlFor} className="text-[13px] font-medium text-ink">
          {label}
          {optional && <span className="ml-1 font-normal text-ink-500">(optional)</span>}
        </label>
        {aside}
      </div>
      {children}
      {error ?
      <p className="text-xs text-danger">{error}</p> :
      hint ?
      <p className="text-xs text-ink-500">{hint}</p> :
      null}
    </div>);

}