import React from 'react';
import { ChevronDownIcon } from 'lucide-react';
import { cn } from '../../utils/cn';
import { inputBase } from '../../utils/styles';

export interface SelectOption {
  value: string;
  label: string;
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  options: SelectOption[];
  compact?: boolean;
}

export const Select = React.forwardRef<HTMLSelectElement, SelectProps>(function Select(
{ options, compact, className, ...rest },
ref)
{
  return (
    <div className="relative">
      <select
        ref={ref}
        className={cn(
          inputBase,
          'cursor-pointer appearance-none pl-3 pr-8',
          compact ? 'h-8 text-[13px]' : 'h-9',
          className
        )}
        {...rest}>
        
        {options.map((o) =>
        <option key={o.value} value={o.value}>
            {o.label}
          </option>
        )}
      </select>
      <ChevronDownIcon className="pointer-events-none absolute right-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-500" />
    </div>);

});