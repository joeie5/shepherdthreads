import React from 'react';
import { cn } from '../../utils/cn';

interface PanelProps {
  title?: string;
  description?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  bodyClassName?: string;
  padded?: boolean;
}

export function Panel({ title, description, actions, children, className, bodyClassName, padded = true }: PanelProps) {
  return (
    <section className={cn('rounded-lg border border-line bg-white', className)}>
      {(title || actions) &&
      <header className="flex items-start justify-between gap-4 border-b border-line px-5 py-3.5">
          <div className="min-w-0">
            {title && <h2 className="text-sm font-semibold text-ink">{title}</h2>}
            {description && <p className="mt-0.5 text-[13px] text-ink-500">{description}</p>}
          </div>
          {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
        </header>
      }
      <div className={cn(padded && 'p-5', bodyClassName)}>{children}</div>
    </section>);

}