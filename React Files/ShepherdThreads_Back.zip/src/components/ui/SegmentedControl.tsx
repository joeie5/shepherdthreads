import React from "react";
import { cn } from "../../utils/cn";
import { BoxIcon } from "lucide-react";
interface SegmentOption<T extends string> {
  value: T;
  label: string;
  icon?: BoxIcon;
  iconOnly?: boolean;
}
interface SegmentedControlProps<T extends string> {
  options: SegmentOption<T>[];
  value: T;
  onChange: (value: T) => void;
  ariaLabel: string;
  className?: string;
}
export function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
  ariaLabel,
  className
}: SegmentedControlProps<T>) {
  return <div role="radiogroup" aria-label={ariaLabel} className={cn('inline-flex rounded-md border border-line bg-canvas p-0.5', className)}>
      {options.map((o) => {
      const active = o.value === value;
      const Icon = o.icon;
      return <button key={o.value} type="button" role="radio" aria-checked={active} aria-label={o.iconOnly ? o.label : undefined} title={o.iconOnly ? o.label : undefined} onClick={() => onChange(o.value)} className={cn('inline-flex h-7 items-center gap-1.5 whitespace-nowrap rounded px-2.5 text-[13px] font-medium transition-colors duration-150', active ? 'bg-white text-ink shadow-sm' : 'text-ink-500 hover:text-ink')}>
            {Icon && <Icon className="h-3.5 w-3.5" aria-hidden />}
            {!o.iconOnly && o.label}
          </button>;
    })}
    </div>;
}