import React from 'react';
import { cn } from '../../utils/cn';

interface RadioOption {
  value: string;
  label: string;
  description?: string;
}

interface RadioGroupProps {
  name: string;
  options: RadioOption[];
  value: string;
  onChange: (value: string) => void;
  ariaLabel: string;
  className?: string;
}

export function RadioGroup({ name, options, value, onChange, ariaLabel, className }: RadioGroupProps) {
  return (
    <div role="radiogroup" aria-label={ariaLabel} className={cn('space-y-2.5', className)}>
      {options.map((o) =>
      <label key={o.value} className="flex cursor-pointer items-start gap-2.5">
          <input
          type="radio"
          name={name}
          value={o.value}
          checked={value === o.value}
          onChange={() => onChange(o.value)}
          className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer accent-ink" />
        
          <span>
            <span className="block text-sm text-ink">{o.label}</span>
            {o.description && <span className="block text-xs text-ink-500">{o.description}</span>}
          </span>
        </label>
      )}
    </div>);

}