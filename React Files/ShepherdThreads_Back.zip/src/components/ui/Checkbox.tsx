import React, { useEffect, useRef } from 'react';
import { cn } from '../../utils/cn';

interface CheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  indeterminate?: boolean;
  label?: string;
}

export function Checkbox({ indeterminate = false, label, className, ...rest }: CheckboxProps) {
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.indeterminate = indeterminate;
  }, [indeterminate]);

  const input =
  <input
    ref={ref}
    type="checkbox"
    className={cn('h-4 w-4 shrink-0 cursor-pointer rounded border-line-strong accent-ink', className)}
    onClick={(e) => e.stopPropagation()}
    {...rest} />;



  if (!label) return input;
  return (
    <label className="inline-flex cursor-pointer items-center gap-2.5 text-sm text-ink">
      {input}
      {label}
    </label>);

}