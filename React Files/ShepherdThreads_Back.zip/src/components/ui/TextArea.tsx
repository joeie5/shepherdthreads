import React from 'react';
import { cn } from '../../utils/cn';
import { inputBase } from '../../utils/styles';

type TextAreaProps = React.TextareaHTMLAttributes<HTMLTextAreaElement>;

export const TextArea = React.forwardRef<HTMLTextAreaElement, TextAreaProps>(function TextArea(
{ className, rows = 4, ...rest },
ref)
{
  return <textarea ref={ref} rows={rows} className={cn(inputBase, 'px-3 py-2 leading-relaxed', className)} {...rest} />;
});