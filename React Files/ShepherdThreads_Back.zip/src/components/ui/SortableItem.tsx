import React from 'react';
import { Reorder, useDragControls } from 'framer-motion';

interface SortableItemProps<T> {
  value: T;
  className?: string;
  children: (startDrag: (e: React.PointerEvent) => void) => React.ReactNode;
}

export function SortableItem<T>({ value, className, children }: SortableItemProps<T>) {
  const controls = useDragControls();
  return (
    <Reorder.Item
      value={value}
      dragListener={false}
      dragControls={controls}
      className={className}
      style={{ position: 'relative' }}
      whileDrag={{ scale: 1.01, boxShadow: '0 14px 30px -14px rgba(10,10,10,0.3)', zIndex: 20 }}
      transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}>
      
      {children((e) => controls.start(e))}
    </Reorder.Item>);

}