import React, { useState } from 'react';
import { UploadIcon } from 'lucide-react';
import { cn } from '../../utils/cn';

interface ImageDropzoneProps {
  onFiles: (urls: string[]) => void;
  multiple?: boolean;
  label?: string;
  hint?: string;
  compact?: boolean;
  className?: string;
}

export function ImageDropzone({
  onFiles,
  multiple = true,
  label = 'Drop images here or browse',
  hint = 'PNG, JPG or WebP · up to 10MB',
  compact = false,
  className
}: ImageDropzoneProps) {
  const [dragging, setDragging] = useState(false);

  const handle = (files: FileList | null) => {
    if (!files) return;
    const urls = Array.from(files).
    filter((f) => f.type.startsWith('image/')).
    map((f) => URL.createObjectURL(f));
    if (urls.length) onFiles(multiple ? urls : urls.slice(0, 1));
  };

  return (
    <label
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        handle(e.dataTransfer.files);
      }}
      className={cn(
        'flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-lg border border-dashed text-center transition-colors duration-150',
        dragging ? 'border-brass bg-brass-soft' : 'border-line-strong bg-canvas hover:border-stone hover:bg-white',
        compact ? 'p-4' : 'p-8',
        className
      )}>
      
      <input
        type="file"
        accept="image/*"
        multiple={multiple}
        className="sr-only"
        onChange={(e) => handle(e.target.files)} />
      
      <span className="flex h-9 w-9 items-center justify-center rounded-full border border-line bg-white">
        <UploadIcon className="h-4 w-4 text-ink-600" aria-hidden />
      </span>
      <span className="text-[13px] font-medium text-ink">{label}</span>
      {!compact && <span className="text-xs text-ink-500">{hint}</span>}
    </label>);

}