import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRightIcon } from 'lucide-react';

export interface Crumb {
  label: string;
  to?: string;
}

export function Breadcrumbs({ items }: {items: Crumb[];}) {
  return (
    <nav aria-label="Breadcrumb" className="mb-2">
      <ol className="flex flex-wrap items-center gap-1 text-[13px] text-ink-500">
        {items.map((item, i) =>
        <li key={item.label} className="flex items-center gap-1">
            {i > 0 && <ChevronRightIcon className="h-3.5 w-3.5 text-stone" aria-hidden />}
            {item.to ?
          <Link to={item.to} className="transition-colors duration-150 hover:text-ink">
                {item.label}
              </Link> :

          <span aria-current="page" className="text-ink-600">
                {item.label}
              </span>
          }
          </li>
        )}
      </ol>
    </nav>);

}