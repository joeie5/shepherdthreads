import React, { useCallback, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "../../utils/cn";
import { useClickOutside } from "../../hooks/useClickOutside";
import { BoxIcon } from "lucide-react";
export interface MenuItem {
  label: string;
  icon?: BoxIcon;
  onClick: () => void;
  danger?: boolean;
  divider?: boolean;
}
interface MenuProps {
  trigger: React.ReactNode;
  items: MenuItem[];
  ariaLabel: string;
  align?: 'left' | 'right';
  triggerClassName?: string;
}
export function Menu({
  trigger,
  items,
  ariaLabel,
  align = 'right',
  triggerClassName
}: MenuProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const close = useCallback(() => setOpen(false), []);
  useClickOutside(ref, close, open);
  return <div ref={ref} className="relative inline-block">
      <button type="button" aria-haspopup="menu" aria-expanded={open} aria-label={ariaLabel} onClick={(e) => {
      e.stopPropagation();
      setOpen((o) => !o);
    }} className={triggerClassName}>
        {trigger}
      </button>
      <AnimatePresence>
        {open && <motion.div role="menu" initial={{
        opacity: 0,
        scale: 0.96,
        y: -4
      }} animate={{
        opacity: 1,
        scale: 1,
        y: 0
      }} exit={{
        opacity: 0,
        scale: 0.96
      }} transition={{
        duration: 0.15,
        ease: [0.23, 1, 0.32, 1]
      }} className={cn('absolute z-40 mt-1.5 min-w-[190px] rounded-lg border border-line bg-white p-1 shadow-pop', align === 'left' ? 'left-0 origin-top-left' : 'right-0 origin-top-right')}>
            {items.map((item) => {
          const Icon = item.icon;
          return <React.Fragment key={item.label}>
                  {item.divider && <div className="my-1 h-px bg-line" />}
                  <button type="button" role="menuitem" onClick={(e) => {
              e.stopPropagation();
              item.onClick();
              setOpen(false);
            }} className={cn('flex w-full items-center gap-2.5 whitespace-nowrap rounded-md px-2.5 py-1.5 text-left text-[13px] transition-colors duration-100', item.danger ? 'text-danger hover:bg-danger-soft' : 'text-ink-800 hover:bg-canvas')}>
                    {Icon && <Icon className="h-4 w-4 opacity-70" aria-hidden />}
                    {item.label}
                  </button>
                </React.Fragment>;
        })}
          </motion.div>}
      </AnimatePresence>
    </div>;
}