import React from "react";
import { cn } from "../../utils/cn";
import { BoxIcon } from "lucide-react";
type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
type Size = 'sm' | 'md';
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  icon?: BoxIcon;
  iconRight?: BoxIcon;
}
const variants: Record<Variant, string> = {
  primary: 'bg-ink text-white border border-ink hover:bg-ink-800',
  secondary: 'bg-white text-ink border border-line-strong hover:bg-canvas hover:border-stone/60',
  ghost: 'text-ink-600 border border-transparent hover:bg-black/[0.04] hover:text-ink',
  danger: 'bg-white text-danger border border-line-strong hover:bg-danger-soft hover:border-danger/30'
};
const sizes: Record<Size, string> = {
  sm: 'h-8 px-2.5 text-[13px] gap-1.5',
  md: 'h-9 px-3.5 text-sm gap-2'
};
export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(function Button({
  variant = 'secondary',
  size = 'md',
  icon: Icon,
  iconRight: IconRight,
  className,
  children,
  type = 'button',
  ...rest
}, ref) {
  const iconOnly = !children;
  return <button ref={ref} type={type} className={cn('inline-flex shrink-0 items-center justify-center whitespace-nowrap rounded-md font-medium', 'transition-[background-color,border-color,color,transform] duration-150 ease-out active:scale-[0.97]', 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass/50 focus-visible:ring-offset-1', 'disabled:pointer-events-none disabled:opacity-50', variants[variant], sizes[size], iconOnly && (size === 'sm' ? 'w-8 px-0' : 'w-9 px-0'), className)} {...rest}>
      {Icon && <Icon className={size === 'sm' ? 'h-3.5 w-3.5' : 'h-4 w-4'} aria-hidden />}
      {children}
      {IconRight && <IconRight className={size === 'sm' ? 'h-3.5 w-3.5' : 'h-4 w-4'} aria-hidden />}
    </button>;
});