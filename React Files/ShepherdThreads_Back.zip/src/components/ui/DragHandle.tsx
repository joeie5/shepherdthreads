import React from 'react';
import { GripVerticalIcon } from 'lucide-react';
import { cn } from '../../utils/cn';

interface DragHandleProps {
  onPointerDown: (e: React.PointerEvent) => void;
  label?: string;
  className?: string;
}

export function DragHandle({ onPointerDown, label = 'Drag to reorder', className }: DragHandleProps) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onPointerDown={(e) => {
        e.preventDefault();
        onPointerDown(e);
      }}
      onClick={(e) => e.stopPropagation()}
      className={cn(
        'flex h-8 w-6 shrink-0 cursor-grab touch-none items-center justify-center rounded text-stone transition-colors duration-150 hover:bg-black/[0.04] hover:text-ink-600 active:cursor-grabbing',
        className
      )}>
      
      <GripVerticalIcon className="h-4 w-4" />
    </button>);

}