import React from 'react';
import { cn } from '../../utils/cn';

interface ToggleProps {
  checked: boolean;
  onChange: (value: boolean) => void;
  label?: string;
  description?: string;
  srLabel?: string;
  disabled?: boolean;
  className?: string;
}

export function Toggle({ checked, onChange, label, description, srLabel, disabled, className }: ToggleProps) {
  const control =
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    aria-label={srLabel ?? label}
    disabled={disabled}
    onClick={(e) => {
      e.stopPropagation();
      onChange(!checked);
    }}
    className={cn(
      'relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full transition-colors duration-150 ease-out',
      'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brass/50 focus-visible:ring-offset-1 disabled:opacity-50',
      checked ? 'bg-ink' : 'bg-line-strong'
    )}>
    
      <span
      className={cn(
        'h-4 w-4 rounded-full bg-white shadow-sm transition-transform duration-150 ease-out',
        checked ? 'translate-x-[18px]' : 'translate-x-0.5'
      )} />
    
    </button>;


  if (!label) return <span className={className}>{control}</span>;

  return (
    <div className={cn('flex items-start justify-between gap-4', className)}>
      <div className="min-w-0">
        <p className="text-sm font-medium text-ink">{label}</p>
        {description && <p className="mt-0.5 text-[13px] text-ink-500">{description}</p>}
      </div>
      {control}
    </div>);

}