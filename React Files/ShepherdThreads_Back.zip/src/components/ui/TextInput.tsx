import React from 'react';
import { cn } from '../../utils/cn';
import { inputBase } from '../../utils/styles';

interface TextInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  leading?: React.ReactNode;
  trailing?: React.ReactNode;
  invalid?: boolean;
}

export const TextInput = React.forwardRef<HTMLInputElement, TextInputProps>(function TextInput(
{ leading, trailing, invalid, className, ...rest },
ref)
{
  return (
    <div className="relative">
      {leading &&
      <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-sm text-ink-500">
          {leading}
        </span>
      }
      <input
        ref={ref}
        className={cn(
          inputBase,
          'h-9 px-3',
          leading ? 'pl-7' : '',
          trailing ? 'pr-12' : '',
          invalid && 'border-danger focus:border-danger',
          className
        )}
        {...rest} />
      
      {trailing &&
      <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-sm text-ink-500">
          {trailing}
        </span>
      }
    </div>);

});