import React from 'react';
import { Link } from 'react-router-dom';
import { PanelsTopLeftIcon, PenLineIcon, PlusIcon, TicketPercentIcon } from 'lucide-react';

const actions = [
{ label: 'Add product', to: '/products/new', icon: PlusIcon },
{ label: 'Create discount', to: '/discounts/new', icon: TicketPercentIcon },
{ label: 'Edit homepage', to: '/content/home', icon: PanelsTopLeftIcon },
{ label: 'Write journal post', to: '/journal/new', icon: PenLineIcon }];


export function QuickActions() {
  return (
    <section className="rounded-lg border border-line bg-white p-4">
      <h2 className="mb-3 px-1 text-sm font-semibold text-ink">Quick actions</h2>
      <div className="grid grid-cols-2 gap-2">
        {actions.map((a) => {
          const Icon = a.icon;
          return (
            <Link
              key={a.to}
              to={a.to}
              className="flex items-center gap-2.5 rounded-md border border-line px-3 py-2.5 text-[13px] font-medium text-ink transition-colors duration-150 hover:border-line-strong hover:bg-canvas">
              
              <Icon className="h-4 w-4 shrink-0 text-brass-text" aria-hidden />
              <span className="truncate">{a.label}</span>
            </Link>);

        })}
      </div>
    </section>);

}