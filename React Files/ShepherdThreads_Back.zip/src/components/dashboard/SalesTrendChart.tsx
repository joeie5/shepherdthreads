import React, { useState } from 'react';
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { salesTrend } from '../../data/analytics';
import { Panel } from '../ui/Panel';
import { SegmentedControl } from '../ui/SegmentedControl';
import { ChartTooltip } from '../charts/ChartTooltip';
import { formatCurrency, formatNumber } from '../../utils/format';

type Metric = 'revenue' | 'orders';
type Range = '7' | '30';

export function SalesTrendChart() {
  const [metric, setMetric] = useState<Metric>('revenue');
  const [range, setRange] = useState<Range>('30');
  const data = range === '7' ? salesTrend.slice(-7) : salesTrend;
  const total = data.reduce((sum, d) => sum + d[metric], 0);
  const totalLabel = metric === 'revenue' ? formatCurrency(total, false) : `${formatNumber(total)} orders`;

  return (
    <Panel
      title="Sales trend"
      description={`${totalLabel} over the last ${range} days`}
      actions={
      <div className="flex flex-wrap justify-end gap-2">
          <SegmentedControl<Metric>
          ariaLabel="Metric"
          value={metric}
          onChange={setMetric}
          options={[
          { value: 'revenue', label: 'Revenue' },
          { value: 'orders', label: 'Orders' }]
          } />
        
          <SegmentedControl<Range>
          ariaLabel="Date range"
          value={range}
          onChange={setRange}
          options={[
          { value: '7', label: '7d' },
          { value: '30', label: '30d' }]
          } />
        
        </div>
      }>
      
      <div className="h-[260px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 8, right: 4, left: -8, bottom: 0 }}>
            <CartesianGrid vertical={false} stroke="#EEECE7" />
            <XAxis
              dataKey="date"
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 11, fill: '#696864' }}
              interval={range === '7' ? 0 : 4} />
            
            <YAxis
              tickLine={false}
              axisLine={false}
              width={44}
              tick={{ fontSize: 11, fill: '#696864' }}
              tickFormatter={(v: number) => metric === 'revenue' ? `$${(v / 1000).toFixed(1)}k` : String(v)} />
            
            <Tooltip
              cursor={{ fill: 'rgba(10,10,10,0.04)' }}
              content={<ChartTooltip formatter={(v) => metric === 'revenue' ? formatCurrency(v) : `${v} orders`} />} />
            
            <Bar dataKey={metric} radius={[3, 3, 0, 0]} maxBarSize={28}>
              {data.map((d, i) =>
              <Cell key={d.date} fill={i === data.length - 1 ? '#B08D57' : '#0A0A0A'} />
              )}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <p className="mt-3 flex items-center gap-2 text-xs text-ink-500">
        <span className="h-2 w-2 rounded-sm bg-brass" aria-hidden /> Today (in progress)
      </p>
    </Panel>);

}