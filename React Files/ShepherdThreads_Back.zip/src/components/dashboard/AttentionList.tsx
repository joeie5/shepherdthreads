import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRightIcon } from 'lucide-react';
import { orders } from '../../data/orders';
import { inventory } from '../../data/inventory';
import { posts } from '../../data/posts';

export function AttentionList() {
  const toFulfill = orders.filter((o) => o.fulfillment === 'unfulfilled' && o.payment === 'paid').length;
  const failed = orders.filter((o) => o.payment === 'failed' || o.payment === 'pending').length;
  const lowStock = inventory.filter((i) => i.stock <= i.threshold).length;
  const drafts = posts.filter((p) => p.status === 'draft').length;

  const items = [
  { count: toFulfill, label: 'orders ready to fulfill', to: '/orders?status=unfulfilled' },
  { count: failed, label: 'payments pending or failed', to: '/orders?status=payment' },
  { count: lowStock, label: 'variants at or below threshold', to: '/inventory?filter=low' },
  { count: drafts, label: 'journal draft waiting for review', to: '/journal' }];


  return (
    <section className="rounded-lg border border-line bg-white">
      <h2 className="border-b border-line px-5 py-3.5 text-sm font-semibold text-ink">Needs your attention</h2>
      <ul>
        {items.map((item) =>
        <li key={item.label} className="border-b border-line last:border-b-0">
            <Link
            to={item.to}
            className="group flex items-center gap-3 px-5 py-3 transition-colors duration-150 hover:bg-canvas">
            
              <span className="w-8 text-xl font-semibold tabular-nums text-ink">{item.count}</span>
              <span className="flex-1 text-[13px] text-ink-600">{item.label}</span>
              <ChevronRightIcon className="h-4 w-4 text-stone transition-transform duration-150 group-hover:translate-x-0.5" />
            </Link>
          </li>
        )}
      </ul>
    </section>);

}