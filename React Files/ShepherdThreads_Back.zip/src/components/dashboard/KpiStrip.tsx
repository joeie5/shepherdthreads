import React from 'react';
import { ArrowDownRightIcon, ArrowUpRightIcon } from 'lucide-react';
import { kpis } from '../../data/analytics';
import { cn } from '../../utils/cn';
import { formatCurrency, formatNumber } from '../../utils/format';

const borderByIndex = ['', 'border-l', 'border-t lg:border-t-0 lg:border-l', 'border-l border-t lg:border-t-0'];

export function KpiStrip() {
  const items = [
  { label: "Today's revenue", value: formatCurrency(kpis.revenueToday), current: kpis.revenueToday, prev: kpis.revenueYesterday, primary: true },
  { label: 'Orders', value: formatNumber(kpis.ordersToday), current: kpis.ordersToday, prev: kpis.ordersYesterday },
  { label: 'Visitors', value: formatNumber(kpis.visitorsToday), current: kpis.visitorsToday, prev: kpis.visitorsYesterday },
  { label: 'Conversion rate', value: `${kpis.conversionToday}%`, current: kpis.conversionToday, prev: kpis.conversionYesterday }];


  return (
    <section
      aria-label="Today at a glance"
      className="grid grid-cols-2 overflow-hidden rounded-lg border border-line bg-white lg:grid-cols-[1.5fr_1fr_1fr_1fr]">
      
      {items.map((item, i) => {
        const change = (item.current - item.prev) / item.prev * 100;
        const up = change >= 0;
        return (
          <div key={item.label} className={cn('border-line p-5', borderByIndex[i])}>
            <p className="text-[13px] text-ink-500">{item.label}</p>
            <p
              className={cn(
                'mt-2 font-semibold leading-none tracking-tight tabular-nums text-ink',
                item.primary ? 'text-[30px] lg:text-[34px]' : 'text-2xl'
              )}>
              
              {item.value}
            </p>
            <p className="mt-2.5 flex flex-wrap items-center gap-1 text-xs">
              <span className={cn('inline-flex items-center font-medium tabular-nums', up ? 'text-success' : 'text-danger')}>
                {up ? <ArrowUpRightIcon className="h-3.5 w-3.5" /> : <ArrowDownRightIcon className="h-3.5 w-3.5" />}
                {Math.abs(change).toFixed(1)}%
              </span>
              <span className="text-ink-500">vs. yesterday</span>
            </p>
          </div>);

      })}
    </section>);

}