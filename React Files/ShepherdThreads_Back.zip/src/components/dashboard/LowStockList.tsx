import React from 'react';
import { Link } from 'react-router-dom';
import { inventory } from '../../data/inventory';
import { Panel } from '../ui/Panel';
import { cn } from '../../utils/cn';

export function LowStockList() {
  const low = inventory.
  filter((i) => i.stock <= i.threshold).
  sort((a, b) => a.stock - b.stock).
  slice(0, 6);

  return (
    <Panel
      title="Low-stock alerts"
      description={`${inventory.filter((i) => i.stock <= i.threshold).length} variants need restocking`}
      padded={false}
      actions={
      <Link to="/inventory?filter=low" className="text-[13px] font-medium text-ink-600 hover:text-ink">
          Manage
        </Link>
      }>
      
      <ul>
        {low.map((item) =>
        <li key={item.sku} className="flex items-center gap-3 border-b border-line px-5 py-2.5 last:border-b-0">
            <img src={item.image} alt="" className="h-9 w-9 rounded object-cover" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-medium text-ink">{item.product}</p>
              <p className="text-xs text-ink-500">
                {item.color} · {item.size}
              </p>
            </div>
            <span
            className={cn(
              'text-right text-[13px] font-semibold tabular-nums',
              item.stock === 0 ? 'text-danger' : 'text-warning'
            )}>
            
              {item.stock === 0 ? 'Out' : `${item.stock} left`}
            </span>
          </li>
        )}
      </ul>
    </Panel>);

}