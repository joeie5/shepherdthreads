import React from 'react';
import { Reorder } from 'framer-motion';
import { CopyIcon, EllipsisIcon, EyeIcon, EyeOffIcon, PencilIcon, PlusIcon, Trash2Icon } from 'lucide-react';
import type { BlockType, PageBlock } from '../../types/content';
import { DragHandle } from '../ui/DragHandle';
import { SortableItem } from '../ui/SortableItem';
import { Menu } from '../ui/Menu';
import { blockMeta, blockSummary } from '../../utils/blocks';
import { cn } from '../../utils/cn';

interface BlockListProps {
  blocks: PageBlock[];
  selectedId: string | null;
  onReorder: (blocks: PageBlock[]) => void;
  onEdit: (id: string) => void;
  onToggle: (id: string) => void;
  onDuplicate: (id: string) => void;
  onDelete: (id: string) => void;
  onAdd: (type: BlockType) => void;
}

export function BlockList({ blocks, selectedId, onReorder, onEdit, onToggle, onDuplicate, onDelete, onAdd }: BlockListProps) {
  return (
    <div className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-semibold text-ink">Page sections</h2>
          <p className="text-xs text-ink-500">Drag to reorder · click to edit</p>
        </div>
      </div>

      <Reorder.Group axis="y" values={blocks} onReorder={onReorder} className="space-y-1.5">
        {blocks.map((block) => {
          const meta = blockMeta[block.type];
          const Icon = meta.icon;
          return (
            <SortableItem key={block.id} value={block} className="rounded-md">
              {(startDrag) =>
              <div
                className={cn(
                  'group flex items-center gap-1.5 rounded-md border bg-white py-1.5 pl-1 pr-1.5 transition-colors duration-150',
                  selectedId === block.id ? 'border-brass ring-1 ring-brass' : 'border-line hover:border-line-strong'
                )}>
                
                  <DragHandle onPointerDown={startDrag} label={`Reorder ${meta.label}`} />
                  <button type="button" onClick={() => onEdit(block.id)} className="flex min-w-0 flex-1 items-center gap-2.5 py-0.5 text-left">
                    <span className={cn('flex h-8 w-8 shrink-0 items-center justify-center rounded bg-cream', !block.visible && 'opacity-50')}>
                      <Icon className="h-4 w-4 text-ink-600" aria-hidden />
                    </span>
                    <span className={cn('min-w-0', !block.visible && 'opacity-50')}>
                      <span className="block truncate text-[13px] font-medium text-ink">{meta.label}</span>
                      <span className="block truncate text-xs text-ink-500">{blockSummary(block)}</span>
                    </span>
                  </button>
                  <button
                  type="button"
                  onClick={() => onToggle(block.id)}
                  aria-label={block.visible ? `Hide ${meta.label}` : `Show ${meta.label}`}
                  title={block.visible ? 'Hide section' : 'Show section'}
                  className="flex h-7 w-7 items-center justify-center rounded text-ink-500 hover:bg-black/[0.05] hover:text-ink">
                  
                    {block.visible ? <EyeIcon className="h-4 w-4" /> : <EyeOffIcon className="h-4 w-4" />}
                  </button>
                  <Menu
                  ariaLabel={`More actions for ${meta.label}`}
                  triggerClassName="flex h-7 w-7 items-center justify-center rounded text-ink-500 hover:bg-black/[0.05] hover:text-ink"
                  trigger={<EllipsisIcon className="h-4 w-4" />}
                  items={[
                  { label: 'Edit', icon: PencilIcon, onClick: () => onEdit(block.id) },
                  { label: 'Duplicate', icon: CopyIcon, onClick: () => onDuplicate(block.id) },
                  { label: 'Delete', icon: Trash2Icon, danger: true, divider: true, onClick: () => onDelete(block.id) }]
                  } />
                
                </div>
              }
            </SortableItem>);

        })}
      </Reorder.Group>

      <div className="mt-3">
        <Menu
          ariaLabel="Add section"
          align="left"
          triggerClassName="flex h-10 w-full items-center justify-center gap-2 rounded-md border border-dashed border-line-strong text-[13px] font-medium text-ink-600 transition-colors duration-150 hover:border-stone hover:bg-canvas hover:text-ink"
          trigger={
          <>
              <PlusIcon className="h-4 w-4" />
              Add section
            </>
          }
          items={(Object.keys(blockMeta) as BlockType[]).map((t) => ({ label: blockMeta[t].label, icon: blockMeta[t].icon, onClick: () => onAdd(t) }))} />
        
      </div>
    </div>);

}