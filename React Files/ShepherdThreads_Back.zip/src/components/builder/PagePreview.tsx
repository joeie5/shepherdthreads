import React from 'react';
import { MenuIcon, SearchIcon, ShoppingBagIcon } from 'lucide-react';
import type { PageBlock } from '../../types/content';
import { BlockPreview } from './BlockPreview';
import { blockMeta } from '../../utils/blocks';
import { cn } from '../../utils/cn';

interface PagePreviewProps {
  blocks: PageBlock[];
  device: 'desktop' | 'mobile';
  selectedId: string | null;
  onSelect: (id: string) => void;
  path: string;
}

export function PagePreview({ blocks, device, selectedId, onSelect, path }: PagePreviewProps) {
  const mobile = device === 'mobile';
  const visible = blocks.filter((b) => b.visible);

  return (
    <div
      className={cn(
        'mx-auto overflow-hidden bg-white shadow-pop transition-[max-width] duration-300 ease-out',
        mobile ? 'max-w-[390px] rounded-[28px] border-[8px] border-ink' : 'max-w-[1120px] rounded-lg border border-line'
      )}>
      
      {!mobile &&
      <div className="flex items-center gap-3 border-b border-line bg-canvas px-4 py-2">
          <div className="flex gap-1.5" aria-hidden>
            <span className="h-2.5 w-2.5 rounded-full bg-line-strong" />
            <span className="h-2.5 w-2.5 rounded-full bg-line-strong" />
            <span className="h-2.5 w-2.5 rounded-full bg-line-strong" />
          </div>
          <div className="flex-1 rounded bg-white px-3 py-1 text-center text-xs text-ink-500">shepherdsthread.co{path}</div>
        </div>
      }

      <header className={cn('flex items-center justify-between border-b border-line bg-white', mobile ? 'px-4 py-3' : 'px-12 py-4')}>
        {mobile ? <MenuIcon className="h-5 w-5 text-ink" /> :
        <nav className="flex gap-6 text-xs font-medium uppercase tracking-[0.12em] text-ink">
            <span>Shop</span>
            <span>Collections</span>
            <span>Journal</span>
          </nav>
        }
        <span className="font-serif text-lg font-semibold tracking-[0.18em] text-ink">SHEPHERDS THREAD</span>
        <div className="flex gap-4 text-ink">
          {!mobile && <SearchIcon className="h-4 w-4" />}
          <ShoppingBagIcon className="h-4 w-4" />
        </div>
      </header>

      {visible.length === 0 ?
      <p className="px-6 py-24 text-center text-sm text-ink-500">All sections are hidden. Turn one on to see it here.</p> :

      visible.map((block) =>
      <div
        key={block.id}
        role="button"
        tabIndex={0}
        aria-label={`Edit ${blockMeta[block.type].label}`}
        onClick={() => onSelect(block.id)}
        onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && onSelect(block.id)}
        className={cn(
          'group relative cursor-pointer outline-none',
          selectedId === block.id ? 'ring-2 ring-inset ring-brass' : 'hover:ring-2 hover:ring-inset hover:ring-brass/50 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brass'
        )}>
        
            <span
          className={cn(
            'pointer-events-none absolute left-2 top-2 z-10 rounded bg-brass px-2 py-0.5 text-[11px] font-medium text-white transition-opacity duration-150',
            selectedId === block.id ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
          )}>
          
              {blockMeta[block.type].label}
            </span>
            <BlockPreview block={block} mobile={mobile} />
          </div>
      )
      }

      <footer className={cn('bg-ink text-white/70', mobile ? 'px-5 py-8' : 'px-12 py-10')}>
        <p className="font-serif text-base italic text-white/90">“I am the good shepherd.” — John 10:11</p>
        <p className="mt-3 text-xs">© 2026 Shepherds Thread</p>
      </footer>
    </div>);

}