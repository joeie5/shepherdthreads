import React from 'react';
import { ArrowLeftIcon, PlusIcon, Trash2Icon } from 'lucide-react';
import type { PageBlock } from '../../types/content';
import { Field } from '../ui/Field';
import { TextInput } from '../ui/TextInput';
import { TextArea } from '../ui/TextArea';
import { Select } from '../ui/Select';
import { Toggle } from '../ui/Toggle';
import { SegmentedControl } from '../ui/SegmentedControl';
import { Button } from '../ui/Button';
import { ImageField } from './ImageField';
import { collections } from '../../data/collections';
import { images } from '../../data/images';
import { blockMeta } from '../../utils/blocks';

interface BlockEditorProps {
  block: PageBlock;
  onChange: (block: PageBlock) => void;
  onBack: () => void;
}

const linkHint = 'Use a page path like /shop or /collections/best-sellers';

function Fields({ block, onChange }: Omit<BlockEditorProps, 'onBack'>) {
  switch (block.type) {
    case 'hero':{
        const d = block.data;
        const set = (p: Partial<typeof d>) => onChange({ ...block, data: { ...d, ...p } });
        return (
          <>
          <ImageField label="Background image" value={d.image} onChange={(image) => set({ image })} />
          <Field label="Headline" htmlFor="h-head">
            <TextInput id="h-head" value={d.headline} onChange={(e) => set({ headline: e.target.value })} />
          </Field>
          <Field label="Subheadline" htmlFor="h-sub">
            <TextArea id="h-sub" rows={2} value={d.subheadline} onChange={(e) => set({ subheadline: e.target.value })} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Button label" htmlFor="h-cta">
              <TextInput id="h-cta" value={d.ctaLabel} onChange={(e) => set({ ctaLabel: e.target.value })} />
            </Field>
            <Field label="Button link" htmlFor="h-link">
              <TextInput id="h-link" value={d.ctaLink} onChange={(e) => set({ ctaLink: e.target.value })} />
            </Field>
          </div>
          <div>
            <p className="mb-1.5 text-[13px] font-medium text-ink">Text alignment</p>
            <SegmentedControl ariaLabel="Text alignment" value={d.align} onChange={(align) => set({ align })} options={[{ value: 'left', label: 'Left' }, { value: 'center', label: 'Center' }]} />
          </div>
        </>);

      }
    case 'productRow':{
        const d = block.data;
        const set = (p: Partial<typeof d>) => onChange({ ...block, data: { ...d, ...p } });
        return (
          <>
          <Field label="Title" htmlFor="p-title">
            <TextInput id="p-title" value={d.title} onChange={(e) => set({ title: e.target.value })} />
          </Field>
          <Field label="Subtitle" htmlFor="p-sub" optional>
            <TextInput id="p-sub" value={d.subtitle} onChange={(e) => set({ subtitle: e.target.value })} />
          </Field>
          <Field label="Collection" htmlFor="p-col" hint="Products appear in the collection’s order.">
            <Select id="p-col" value={d.collection} onChange={(e) => set({ collection: e.target.value })} options={collections.map((c) => ({ value: c.id, label: c.name }))} />
          </Field>
          <Field label="Products to show" htmlFor="p-count">
            <Select id="p-count" value={String(d.count)} onChange={(e) => set({ count: Number(e.target.value) })} options={['2', '3', '4', '6', '8'].map((n) => ({ value: n, label: `${n} products` }))} />
          </Field>
          <Toggle label="Show prices" checked={d.showPrices} onChange={(showPrices) => set({ showPrices })} />
        </>);

      }
    case 'story':{
        const d = block.data;
        const set = (p: Partial<typeof d>) => onChange({ ...block, data: { ...d, ...p } });
        return (
          <>
          <ImageField label="Image" value={d.image} onChange={(image) => set({ image })} aspect="aspect-[4/3]" />
          <div>
            <p className="mb-1.5 text-[13px] font-medium text-ink">Image position</p>
            <SegmentedControl ariaLabel="Image position" value={d.imageSide} onChange={(imageSide) => set({ imageSide })} options={[{ value: 'left', label: 'Left' }, { value: 'right', label: 'Right' }]} />
          </div>
          <Field label="Small label above title" htmlFor="s-eye" optional>
            <TextInput id="s-eye" value={d.eyebrow} onChange={(e) => set({ eyebrow: e.target.value })} />
          </Field>
          <Field label="Title" htmlFor="s-title">
            <TextInput id="s-title" value={d.title} onChange={(e) => set({ title: e.target.value })} />
          </Field>
          <Field label="Story" htmlFor="s-body">
            <TextArea id="s-body" rows={4} value={d.body} onChange={(e) => set({ body: e.target.value })} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Link label" htmlFor="s-cta">
              <TextInput id="s-cta" value={d.ctaLabel} onChange={(e) => set({ ctaLabel: e.target.value })} />
            </Field>
            <Field label="Link" htmlFor="s-link">
              <TextInput id="s-link" value={d.ctaLink} onChange={(e) => set({ ctaLink: e.target.value })} />
            </Field>
          </div>
        </>);

      }
    case 'testimonials':{
        const d = block.data;
        const setItems = (items: typeof d.items) => onChange({ ...block, data: { ...d, items } });
        return (
          <>
          <Field label="Section title" htmlFor="t-title">
            <TextInput id="t-title" value={d.title} onChange={(e) => onChange({ ...block, data: { ...d, title: e.target.value } })} />
          </Field>
          <div className="space-y-3">
            {d.items.map((item, i) => {
                const setItem = (p: Partial<typeof item>) => setItems(d.items.map((x, j) => j === i ? { ...x, ...p } : x));
                return (
                  <div key={i} className="space-y-3 rounded-md border border-line bg-canvas p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-medium text-ink-500">Quote {i + 1}</p>
                    <Button variant="ghost" size="sm" icon={Trash2Icon} aria-label={`Remove quote ${i + 1}`} onClick={() => setItems(d.items.filter((_, j) => j !== i))} />
                  </div>
                  <TextArea rows={3} aria-label={`Quote ${i + 1}`} value={item.quote} onChange={(e) => setItem({ quote: e.target.value })} />
                  <div className="grid grid-cols-2 gap-2">
                    <TextInput aria-label="Name" placeholder="Name" value={item.name} onChange={(e) => setItem({ name: e.target.value })} />
                    <TextInput aria-label="Detail" placeholder="City or role" value={item.detail} onChange={(e) => setItem({ detail: e.target.value })} />
                  </div>
                  <ImageField label="Photo" value={item.image} onChange={(image) => setItem({ image })} aspect="aspect-square max-h-32" />
                </div>);

              })}
          </div>
          <Button size="sm" icon={PlusIcon} onClick={() => setItems([...d.items, { quote: '', name: '', detail: '', image: images.ugc }])}>
            Add quote
          </Button>
        </>);

      }
    case 'newsletter':{
        const d = block.data;
        const set = (p: Partial<typeof d>) => onChange({ ...block, data: { ...d, ...p } });
        return (
          <>
          <Field label="Headline" htmlFor="n-head">
            <TextInput id="n-head" value={d.headline} onChange={(e) => set({ headline: e.target.value })} />
          </Field>
          <Field label="Body" htmlFor="n-body">
            <TextArea id="n-body" rows={2} value={d.body} onChange={(e) => set({ body: e.target.value })} />
          </Field>
          <Field label="Button label" htmlFor="n-btn">
            <TextInput id="n-btn" value={d.buttonLabel} onChange={(e) => set({ buttonLabel: e.target.value })} />
          </Field>
          <div>
            <p className="mb-1.5 text-[13px] font-medium text-ink">Background</p>
            <SegmentedControl ariaLabel="Background" value={d.theme} onChange={(theme) => set({ theme })} options={[{ value: 'black', label: 'Black' }, { value: 'cream', label: 'Cream' }]} />
          </div>
        </>);

      }
    case 'text':{
        const d = block.data;
        const set = (p: Partial<typeof d>) => onChange({ ...block, data: { ...d, ...p } });
        return (
          <>
          <Field label="Heading" htmlFor="x-head">
            <TextInput id="x-head" value={d.heading} onChange={(e) => set({ heading: e.target.value })} />
          </Field>
          <Field label="Body" htmlFor="x-body">
            <TextArea id="x-body" rows={5} value={d.body} onChange={(e) => set({ body: e.target.value })} />
          </Field>
          <div>
            <p className="mb-1.5 text-[13px] font-medium text-ink">Alignment</p>
            <SegmentedControl ariaLabel="Alignment" value={d.align} onChange={(align) => set({ align })} options={[{ value: 'left', label: 'Left' }, { value: 'center', label: 'Center' }]} />
          </div>
        </>);

      }
  }
}

export function BlockEditor({ block, onChange, onBack }: BlockEditorProps) {
  const meta = blockMeta[block.type];
  return (
    <div>
      <div className="sticky top-0 z-10 flex items-center gap-2 border-b border-line bg-white px-3 py-2.5">
        <Button variant="ghost" size="sm" icon={ArrowLeftIcon} aria-label="Back to sections" onClick={onBack} />
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-ink">{meta.label}</p>
          <p className="truncate text-xs text-ink-500">{meta.description}</p>
        </div>
      </div>
      <div className="space-y-4 p-4">
        <Toggle
          label="Show on page"
          description={block.visible ? 'Visible to customers' : 'Hidden — only you can see it here'}
          checked={block.visible}
          onChange={(visible) => onChange({ ...block, visible })} />
        
        <div className="space-y-4 border-t border-line pt-4">
          <Fields block={block} onChange={onChange} />
        </div>
        <p className="text-xs text-ink-500">{linkHint}</p>
      </div>
    </div>);

}