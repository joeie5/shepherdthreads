import React from 'react';
import { RefreshCwIcon } from 'lucide-react';
import { ImageDropzone } from '../ui/ImageDropzone';

interface ImageFieldProps {
  label: string;
  value: string;
  onChange: (url: string) => void;
  aspect?: string;
}

export function ImageField({ label, value, onChange, aspect = 'aspect-[16/9]' }: ImageFieldProps) {
  return (
    <div className="space-y-1.5">
      <p className="text-[13px] font-medium text-ink">{label}</p>
      {value ?
      <div className="group relative overflow-hidden rounded-md border border-line">
          <img src={value} alt="" className={`${aspect} w-full object-cover`} />
          <label className="absolute bottom-2 right-2 inline-flex h-7 cursor-pointer items-center gap-1.5 rounded-md bg-white/95 px-2.5 text-xs font-medium text-ink shadow-sm hover:bg-white">
            <RefreshCwIcon className="h-3 w-3" />
            Replace
            <input
            type="file"
            accept="image/*"
            className="sr-only"
            onChange={(e) => e.target.files?.[0] && onChange(URL.createObjectURL(e.target.files[0]))} />
          
          </label>
        </div> :

      <ImageDropzone compact multiple={false} label="Upload image" onFiles={(urls) => onChange(urls[0])} />
      }
    </div>);

}