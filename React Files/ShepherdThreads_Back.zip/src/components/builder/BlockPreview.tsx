import React from 'react';
import type { PageBlock } from '../../types/content';
import { collections } from '../../data/collections';
import { products } from '../../data/products';
import { cn } from '../../utils/cn';
import { formatCurrency } from '../../utils/format';

const desktopCols: Record<number, string> = { 1: 'grid-cols-1', 2: 'grid-cols-2', 3: 'grid-cols-3', 4: 'grid-cols-4' };

interface BlockPreviewProps {
  block: PageBlock;
  mobile: boolean;
}

export function BlockPreview({ block, mobile }: BlockPreviewProps) {
  switch (block.type) {
    case 'hero':{
        const d = block.data;
        return (
          <section className={cn('relative overflow-hidden bg-ink', mobile ? 'h-[460px]' : 'h-[440px]')}>
          <img src={d.image} alt="" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-ink/35" />
          <div
              className={cn(
                'relative flex h-full flex-col justify-end',
                mobile ? 'p-6' : 'p-12',
                d.align === 'center' && 'items-center justify-center text-center'
              )}>
              
            <h2 className={cn('max-w-xl font-serif font-semibold leading-[1.05] text-white', mobile ? 'text-4xl' : 'text-6xl')}>{d.headline}</h2>
            <p className={cn('mt-3 max-w-md text-white/90', mobile ? 'text-sm' : 'text-base')}>{d.subheadline}</p>
            {d.ctaLabel && <span className="mt-6 inline-block w-fit bg-white px-6 py-3 text-xs font-semibold uppercase tracking-[0.14em] text-ink">{d.ctaLabel}</span>}
          </div>
        </section>);

      }
    case 'productRow':{
        const d = block.data;
        const col = collections.find((c) => c.id === d.collection);
        const list = (col?.productIds ?? []).
        map((id) => products.find((p) => p.id === id)).
        filter((p): p is (typeof products)[number] => !!p).
        slice(0, d.count);
        return (
          <section className={cn('bg-white', mobile ? 'px-5 py-10' : 'px-12 py-16')}>
          <div className="mb-6 flex items-end justify-between gap-4">
            <div>
              <h2 className={cn('font-serif font-semibold text-ink', mobile ? 'text-2xl' : 'text-4xl')}>{d.title}</h2>
              {d.subtitle && <p className="mt-1 text-sm text-ink-500">{d.subtitle}</p>}
            </div>
            <span className="whitespace-nowrap text-xs font-medium uppercase tracking-[0.12em] text-ink underline underline-offset-4">View all</span>
          </div>
          {list.length === 0 ?
            <p className="rounded border border-dashed border-line-strong py-10 text-center text-sm text-ink-500">This collection has no products yet.</p> :

            <div className={cn('grid gap-4', mobile ? 'grid-cols-2' : desktopCols[Math.min(list.length, 4)])}>
              {list.map((p) =>
              <div key={p.id}>
                  <div className="aspect-[4/5] overflow-hidden bg-cream">
                    <img src={p.image} alt="" className="h-full w-full object-cover" />
                  </div>
                  <p className="mt-2.5 text-sm text-ink">{p.name}</p>
                  {d.showPrices && <p className="text-sm text-ink-500">{formatCurrency(p.price, false)}</p>}
                </div>
              )}
            </div>
            }
        </section>);

      }
    case 'story':{
        const d = block.data;
        return (
          <section className={cn('grid bg-cream', mobile ? 'grid-cols-1' : 'grid-cols-2')}>
          <img
              src={d.image}
              alt=""
              className={cn('h-full w-full object-cover', mobile ? 'aspect-[4/3]' : 'min-h-[380px]', !mobile && d.imageSide === 'right' && 'order-2')} />
            
          <div className={cn('flex flex-col justify-center', mobile ? 'p-6' : 'p-14')}>
            {d.eyebrow && <p className="text-xs font-medium uppercase tracking-[0.16em] text-brass-text">{d.eyebrow}</p>}
            <h2 className={cn('mt-3 font-serif font-semibold leading-tight text-ink', mobile ? 'text-3xl' : 'text-4xl')}>{d.title}</h2>
            <p className="mt-4 text-[15px] leading-relaxed text-ink-600">{d.body}</p>
            {d.ctaLabel && <span className="mt-6 w-fit border-b border-ink pb-0.5 text-sm font-medium text-ink">{d.ctaLabel}</span>}
          </div>
        </section>);

      }
    case 'testimonials':{
        const d = block.data;
        return (
          <section className={cn('bg-white', mobile ? 'px-5 py-10' : 'px-12 py-16')}>
          <h2 className={cn('mb-8 text-center font-serif font-semibold text-ink', mobile ? 'text-2xl' : 'text-4xl')}>{d.title}</h2>
          <div className={cn('grid gap-5', mobile ? 'grid-cols-1' : 'grid-cols-3')}>
            {d.items.map((t, i) =>
              <figure key={i} className="flex flex-col border border-line bg-white">
                <img src={t.image} alt="" className="aspect-square w-full object-cover" />
                <blockquote className="flex-1 p-5 font-serif text-lg leading-snug text-ink">“{t.quote || 'Quote'}”</blockquote>
                <figcaption className="px-5 pb-5 text-xs text-ink-500">
                  <span className="font-medium text-ink">{t.name}</span> · {t.detail}
                </figcaption>
              </figure>
              )}
          </div>
        </section>);

      }
    case 'newsletter':{
        const d = block.data;
        const dark = d.theme === 'black';
        return (
          <section className={cn('text-center', dark ? 'bg-ink text-white' : 'bg-cream text-ink', mobile ? 'px-6 py-12' : 'px-12 py-16')}>
          <h2 className={cn('font-serif font-semibold', mobile ? 'text-3xl' : 'text-4xl')}>{d.headline}</h2>
          <p className={cn('mx-auto mt-3 max-w-md text-sm', dark ? 'text-white/75' : 'text-ink-600')}>{d.body}</p>
          <div className={cn('mx-auto mt-6 flex max-w-md', mobile && 'flex-col gap-2')}>
            <span className={cn('flex h-11 flex-1 items-center px-4 text-left text-sm', dark ? 'border border-white/30 text-white/50' : 'border border-line-strong bg-white text-ink-500')}>
              Email address
            </span>
            <span className={cn('flex h-11 items-center justify-center px-6 text-xs font-semibold uppercase tracking-[0.14em]', dark ? 'bg-white text-ink' : 'bg-ink text-white')}>
              {d.buttonLabel}
            </span>
          </div>
        </section>);

      }
    case 'text':{
        const d = block.data;
        return (
          <section className={cn('bg-white', mobile ? 'px-6 py-10' : 'px-12 py-16', d.align === 'center' && 'text-center')}>
          <div className={cn('max-w-2xl', d.align === 'center' && 'mx-auto')}>
            <h2 className={cn('font-serif font-semibold text-ink', mobile ? 'text-2xl' : 'text-4xl')}>{d.heading}</h2>
            <p className="mt-4 whitespace-pre-line text-[15px] leading-relaxed text-ink-600">{d.body}</p>
          </div>
        </section>);

      }
  }
}