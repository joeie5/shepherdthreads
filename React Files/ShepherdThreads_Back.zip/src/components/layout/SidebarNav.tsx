import React from 'react';
import { NavLink } from 'react-router-dom';
import { ExternalLinkIcon, PanelLeftCloseIcon, PanelLeftOpenIcon } from 'lucide-react';
import { adminNav } from '../../data/adminNav';
import { cn } from '../../utils/cn';

interface SidebarNavProps {
  collapsed: boolean;
  onToggleCollapse?: () => void;
}

export function SidebarNav({ collapsed, onToggleCollapse }: SidebarNavProps) {
  return (
    <div className="flex h-full flex-col">
      <div className={cn('flex h-14 shrink-0 items-center gap-2.5 border-b border-line', collapsed ? 'justify-center' : 'px-4')}>
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-ink font-serif text-[15px] font-semibold text-cream">
          ST
        </span>
        {!collapsed &&
        <div className="min-w-0 leading-tight">
            <p className="truncate text-sm font-semibold text-ink">Shepherds Thread</p>
            <p className="text-[11px] text-ink-500">Store admin</p>
          </div>
        }
      </div>

      <nav aria-label="Main" className="flex-1 space-y-5 overflow-y-auto px-3 py-4">
        {adminNav.map((group, gi) =>
        <div key={group.label}>
            {collapsed ?
          gi > 0 && <div className="mx-auto mb-3 h-px w-6 bg-line" /> :

          <p className="mb-1 px-2.5 text-[11px] font-medium text-ink-500">{group.label}</p>
          }
            <ul className="space-y-0.5">
              {group.items.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.to}>
                    <NavLink
                    to={item.to}
                    end={item.to === '/'}
                    title={collapsed ? item.label : undefined}
                    className={({ isActive }) =>
                    cn(
                      'group relative flex h-9 items-center gap-3 rounded-md text-[13.5px] font-medium transition-colors duration-150',
                      collapsed ? 'justify-center' : 'px-2.5',
                      isActive ? 'bg-cream text-ink' : 'text-ink-600 hover:bg-canvas hover:text-ink'
                    )
                    }>
                    
                      {({ isActive }) =>
                    <>
                          {isActive && <span className="absolute inset-y-1.5 left-0 w-[3px] rounded-r-full bg-brass" />}
                          <Icon
                        className={cn(
                          'h-[18px] w-[18px] shrink-0',
                          isActive ? 'text-brass-text' : 'text-stone group-hover:text-ink-600'
                        )}
                        aria-hidden />
                      
                          {!collapsed && <span className="truncate">{item.label}</span>}
                          {item.badge !== undefined && (
                      collapsed ?
                      <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-brass" /> :

                      <span className="ml-auto rounded-full bg-ink px-1.5 text-[11px] font-medium tabular-nums text-white">
                                {item.badge}
                              </span>)
                      }
                        </>
                    }
                    </NavLink>
                  </li>);

            })}
            </ul>
          </div>
        )}
      </nav>

      <div className="space-y-0.5 border-t border-line p-3">
        <a
          href="https://shepherdsthread.co"
          target="_blank"
          rel="noreferrer"
          title={collapsed ? 'View storefront' : undefined}
          className={cn(
            'flex h-9 items-center gap-3 rounded-md text-[13px] text-ink-600 transition-colors duration-150 hover:bg-canvas hover:text-ink',
            collapsed ? 'justify-center' : 'px-2.5'
          )}>
          
          <ExternalLinkIcon className="h-4 w-4 text-stone" aria-hidden />
          {!collapsed && 'View storefront'}
        </a>
        {onToggleCollapse &&
        <button
          type="button"
          onClick={onToggleCollapse}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          title={collapsed ? 'Expand sidebar' : undefined}
          className={cn(
            'flex h-9 w-full items-center gap-3 rounded-md text-[13px] text-ink-600 transition-colors duration-150 hover:bg-canvas hover:text-ink',
            collapsed ? 'justify-center' : 'px-2.5'
          )}>
          
            {collapsed ?
          <PanelLeftOpenIcon className="h-4 w-4 text-stone" aria-hidden /> :

          <PanelLeftCloseIcon className="h-4 w-4 text-stone" aria-hidden />
          }
            {!collapsed && 'Collapse'}
          </button>
        }
      </div>
    </div>);

}