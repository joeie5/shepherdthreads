import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { SearchIcon, ShoppingBagIcon, UserIcon } from 'lucide-react';
import { products } from '../../data/products';
import { orders } from '../../data/orders';
import { customers } from '../../data/customers';
import { useClickOutside } from '../../hooks/useClickOutside';
import { cn } from '../../utils/cn';
import { formatCurrency } from '../../utils/format';
import { inputBase } from '../../utils/styles';

interface ResultItem {
  id: string;
  label: string;
  meta: string;
  to: string;
  image?: string;
}

interface ResultGroup {
  group: string;
  icon: typeof UserIcon;
  items: ResultItem[];
}

export function GlobalSearch() {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const close = useCallback(() => setOpen(false), []);
  useClickOutside(ref, close, open);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        inputRef.current?.focus();
        setOpen(true);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  const term = query.trim().toLowerCase();

  const results = useMemo<ResultGroup[]>(() => {
    if (!term) return [];
    const groups: ResultGroup[] = [
    {
      group: 'Products',
      icon: ShoppingBagIcon,
      items: products.
      filter((p) => p.name.toLowerCase().includes(term) || p.sku.toLowerCase().includes(term)).
      slice(0, 4).
      map((p) => ({ id: p.id, label: p.name, meta: `${p.category} · ${formatCurrency(p.price)}`, to: `/products/${p.id}`, image: p.image }))
    },
    {
      group: 'Orders',
      icon: ShoppingBagIcon,
      items: orders.
      filter((o) => o.number.toLowerCase().includes(term) || o.customerName.toLowerCase().includes(term)).
      slice(0, 4).
      map((o) => ({ id: o.id, label: o.number, meta: `${o.customerName} · ${formatCurrency(o.total)}`, to: `/orders/${o.id}` }))
    },
    {
      group: 'Customers',
      icon: UserIcon,
      items: customers.
      filter((c) => c.name.toLowerCase().includes(term) || c.email.toLowerCase().includes(term)).
      slice(0, 4).
      map((c) => ({ id: c.id, label: c.name, meta: c.email, to: `/customers/${c.id}` }))
    }];

    return groups.filter((g) => g.items.length > 0);
  }, [term]);

  const go = (to: string) => {
    navigate(to);
    setOpen(false);
    setQuery('');
    inputRef.current?.blur();
  };

  return (
    <div ref={ref} className="relative w-full max-w-md">
      <SearchIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone" />
      <input
        ref={inputRef}
        type="text"
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        placeholder="Search products, orders, customers"
        aria-label="Search the admin"
        className={cn(inputBase, 'h-9 bg-canvas pl-9 pr-12')} />
      
      <kbd className="pointer-events-none absolute right-2.5 top-1/2 hidden -translate-y-1/2 rounded border border-line bg-white px-1.5 font-sans text-[11px] text-ink-500 sm:inline-block">
        ⌘K
      </kbd>
      <AnimatePresence>
        {open && term &&
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15, ease: [0.23, 1, 0.32, 1] }}
          className="absolute left-0 right-0 top-full z-40 mt-1.5 max-h-[420px] overflow-y-auto rounded-lg border border-line bg-white p-1.5 shadow-pop">
          
            {results.length === 0 ?
          <p className="px-3 py-6 text-center text-[13px] text-ink-500">No results for “{query}”</p> :

          results.map((g) => {
            const Icon = g.icon;
            return (
              <div key={g.group}>
                    <p className="px-2.5 pb-1 pt-2 text-[11px] font-medium text-ink-500">{g.group}</p>
                    {g.items.map((item) =>
                <button
                  key={item.id}
                  type="button"
                  onClick={() => go(item.to)}
                  className="flex w-full items-center gap-3 rounded-md px-2.5 py-2 text-left transition-colors duration-100 hover:bg-canvas">
                  
                        {item.image ?
                  <img src={item.image} alt="" className="h-8 w-8 rounded object-cover" /> :

                  <span className="flex h-8 w-8 items-center justify-center rounded bg-cream">
                            <Icon className="h-4 w-4 text-ink-500" aria-hidden />
                          </span>
                  }
                        <span className="min-w-0">
                          <span className="block truncate text-[13px] font-medium text-ink">{item.label}</span>
                          <span className="block truncate text-xs text-ink-500">{item.meta}</span>
                        </span>
                      </button>
                )}
                  </div>);

          })
          }
          </motion.div>
        }
      </AnimatePresence>
    </div>);

}