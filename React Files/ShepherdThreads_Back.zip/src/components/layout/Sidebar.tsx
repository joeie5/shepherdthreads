import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { SidebarNav } from './SidebarNav';
import { cn } from '../../utils/cn';

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onMobileClose: () => void;
}

export function Sidebar({ collapsed, onToggleCollapse, mobileOpen, onMobileClose }: SidebarProps) {
  return (
    <>
      <aside
        className={cn(
          'hidden shrink-0 border-r border-line bg-white transition-[width] duration-200 ease-out lg:block',
          collapsed ? 'w-[68px]' : 'w-60'
        )}>
        
        <SidebarNav collapsed={collapsed} onToggleCollapse={onToggleCollapse} />
      </aside>

      <AnimatePresence>
        {mobileOpen &&
        <>
            <motion.div
            className="fixed inset-0 z-40 bg-ink/30 lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onMobileClose} />
          
            <motion.aside
            className="fixed inset-y-0 left-0 z-50 w-64 border-r border-line bg-white lg:hidden"
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ duration: 0.24, ease: [0.32, 0.72, 0, 1] }}>
            
              <SidebarNav collapsed={false} />
            </motion.aside>
          </>
        }
      </AnimatePresence>
    </>);

}