import React from 'react';
import { MenuIcon } from 'lucide-react';
import { GlobalSearch } from './GlobalSearch';
import { NotificationsMenu } from './NotificationsMenu';
import { ProfileMenu } from './ProfileMenu';

export function Topbar({ onOpenMenu }: {onOpenMenu: () => void;}) {
  return (
    <header className="z-30 flex h-14 shrink-0 items-center gap-3 border-b border-line bg-white px-4 lg:px-6">
      <button
        type="button"
        onClick={onOpenMenu}
        aria-label="Open navigation"
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md text-ink-600 hover:bg-black/[0.04] lg:hidden">
        
        <MenuIcon className="h-5 w-5" />
      </button>
      <GlobalSearch />
      <div className="ml-auto flex items-center gap-1.5">
        <NotificationsMenu />
        <div className="mx-1 hidden h-6 w-px bg-line sm:block" />
        <ProfileMenu />
      </div>
    </header>);

}