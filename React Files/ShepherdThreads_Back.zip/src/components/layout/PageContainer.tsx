import React from 'react';
import { cn } from '../../utils/cn';

interface PageContainerProps {
  children: React.ReactNode;
  className?: string;
  narrow?: boolean;
}

export function PageContainer({ children, className, narrow }: PageContainerProps) {
  return (
    <div className={cn('mx-auto w-full px-4 py-6 lg:px-8 lg:py-8', narrow ? 'max-w-[1120px]' : 'max-w-[1440px]', className)}>
      {children}
    </div>);

}