import React from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { ChevronDownIcon, LogOutIcon, SettingsIcon, UserIcon, BoxIcon } from "lucide-react";
import { Menu } from "../ui/Menu";
import { Avatar } from "../ui/Avatar";
export function ProfileMenu() {
  const navigate = useNavigate();
  return <Menu ariaLabel="Account menu" triggerClassName="flex items-center gap-2 rounded-md py-1 pl-1 pr-2 transition-colors duration-150 hover:bg-black/[0.04]" trigger={<>
          <Avatar name="Hannah Brooks" size="sm" />
          <span className="hidden text-left leading-tight sm:block">
            <span className="block text-[13px] font-medium text-ink">Hannah Brooks</span>
            <span className="block text-[11px] text-ink-500">Owner · Admin</span>
          </span>
          <ChevronDownIcon className="hidden h-3.5 w-3.5 text-ink-500 sm:block" />
        </>} items={[{
    label: 'Your profile',
    icon: UserIcon,
    onClick: () => navigate('/staff')
  }, {
    label: 'Store settings',
    icon: SettingsIcon,
    onClick: () => navigate('/settings/general')
  }, {
    label: 'Help & guides',
    icon: BoxIcon,
    onClick: () => toast('Help center opens in a new tab')
  }, {
    label: 'Sign out',
    icon: LogOutIcon,
    onClick: () => toast('Signed out (demo)'),
    divider: true
  }]} />;
}