import React, { useCallback, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { BellIcon, CalendarClockIcon, ShoppingBagIcon, StarIcon, TriangleAlertIcon } from 'lucide-react';
import { notifications as initial } from '../../data/notifications';
import type { AdminNotification } from '../../types/admin';
import { useClickOutside } from '../../hooks/useClickOutside';
import { cn } from '../../utils/cn';

const typeIcon: Record<AdminNotification['type'], typeof BellIcon> = {
  order: ShoppingBagIcon,
  stock: TriangleAlertIcon,
  review: StarIcon,
  system: CalendarClockIcon
};

export function NotificationsMenu() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<AdminNotification[]>(initial);
  const ref = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const close = useCallback(() => setOpen(false), []);
  useClickOutside(ref, close, open);
  const unread = items.filter((n) => !n.read).length;

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`}
        aria-expanded={open}
        className="relative flex h-9 w-9 items-center justify-center rounded-md text-ink-600 transition-colors duration-150 hover:bg-black/[0.04] hover:text-ink">
        
        <BellIcon className="h-[18px] w-[18px]" />
        {unread > 0 && <span className="absolute right-2 top-2 h-2 w-2 rounded-full border-2 border-white bg-brass" />}
      </button>
      <AnimatePresence>
        {open &&
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: -4 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96 }}
          transition={{ duration: 0.15, ease: [0.23, 1, 0.32, 1] }}
          className="absolute right-0 z-40 mt-1.5 w-[min(360px,calc(100vw-2rem))] origin-top-right rounded-lg border border-line bg-white shadow-pop">
          
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <p className="text-sm font-semibold text-ink">Notifications</p>
              <button
              type="button"
              disabled={!unread}
              onClick={() => setItems((prev) => prev.map((n) => ({ ...n, read: true })))}
              className="text-[13px] text-ink-500 transition-colors duration-150 hover:text-ink disabled:opacity-40">
              
                Mark all read
              </button>
            </div>
            <ul className="max-h-[380px] overflow-y-auto py-1">
              {items.map((n) => {
              const Icon = typeIcon[n.type];
              return (
                <li key={n.id}>
                    <button
                    type="button"
                    onClick={() => {
                      setItems((prev) => prev.map((x) => x.id === n.id ? { ...x, read: true } : x));
                      setOpen(false);
                      navigate(n.to);
                    }}
                    className="flex w-full gap-3 px-4 py-2.5 text-left transition-colors duration-100 hover:bg-canvas">
                    
                      <span
                      className={cn(
                        'mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full',
                        n.type === 'stock' ? 'bg-warning-soft text-warning' : 'bg-cream text-ink-600'
                      )}>
                      
                        <Icon className="h-4 w-4" aria-hidden />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className={cn('block text-[13px] text-ink', !n.read && 'font-semibold')}>{n.title}</span>
                        <span className="block truncate text-xs text-ink-500">{n.body}</span>
                        <span className="mt-0.5 block text-[11px] text-ink-500">{n.time}</span>
                      </span>
                      {!n.read && <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-brass" aria-label="Unread" />}
                    </button>
                  </li>);

            })}
            </ul>
          </motion.div>
        }
      </AnimatePresence>
    </div>);

}