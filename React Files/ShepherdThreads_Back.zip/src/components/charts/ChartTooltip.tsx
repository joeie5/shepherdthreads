import React from 'react';

interface ChartTooltipProps {
  active?: boolean;
  payload?: Array<{value: number;name: string;color?: string;}>;
  label?: string;
  formatter?: (value: number, name: string) => string;
}

export function ChartTooltip({ active, payload, label, formatter }: ChartTooltipProps) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-md border border-line bg-white px-3 py-2 shadow-pop">
      {label && <p className="mb-1 text-[11px] text-ink-500">{label}</p>}
      {payload.map((p) =>
      <p key={p.name} className="text-[13px] font-semibold tabular-nums text-ink">
          {formatter ? formatter(p.value, p.name) : p.value}
        </p>
      )}
    </div>);

}